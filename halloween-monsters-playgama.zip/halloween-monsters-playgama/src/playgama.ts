// Playgama Bridge SDK v2 Integration
// This module wraps all SDK calls for the game

import { Language } from './i18n';

// Type declarations for Playgama Bridge SDK v2
declare global {
  interface Window {
    bridge: any;
  }
}

// Playgama Bridge SDK v2 interface (for internal use)
interface PlaygamaBridge {
  initialize: () => Promise<void>;
  platform: {
    id: string;
    language: string;
    payload: string;
    sendMessage: (message: string) => void;
    on: (event: string, callback: (...args: any[]) => void) => void;
    off: (event: string, callback: (...args: any[]) => void) => void;
    isAudioEnabled: () => boolean;
  };
  storage: {
    get: (key: string, type?: string) => Promise<any>;
    set: (key: string, value: any, type?: string) => Promise<void>;
    delete: (key: string, type?: string) => Promise<void>;
    isAvailable?: (type: string) => boolean;
  };
  advertisement: {
    showInterstitial: () => Promise<void>;
    showRewarded: (placementId?: string) => Promise<void>;
    on: (event: string, callback: (...args: any[]) => void) => void;
    off: (event: string, callback: (...args: any[]) => void) => void;
    isAdBlockEnabled: () => Promise<boolean>;
  };
  player: {
    id: string;
    name: string;
    avatar: string;
    isAuthorized: boolean;
  };
  device: {
    type: string;
    os: string;
  };
  analytics: {
    onGameplayStart: () => void;
    onGameplayStop: () => void;
    onLevelComplete: (levelId: string, score?: number) => void;
    onLevelFail: (levelId: string) => void;
    onInAppPurchaseStart: (sku: string, price: string, currency: string) => void;
    onInAppPurchaseComplete: (sku: string, price: string, currency: string, success: boolean) => void;
  };
  leaderboard: {
    setScore: (leaderboardId: string, score: number, extraData?: string) => Promise<void>;
    getEntries: (leaderboardId: string, limit?: number, includeCurrentUser?: boolean) => Promise<any[]>;
  };
  achievement: {
    unlock: (achievementId: string) => Promise<void>;
    getAchievements: () => Promise<any[]>;
  };
  dailyReward: {
    isReady: () => Promise<boolean>;
    claim: () => Promise<any>;
  };
  social: {
    share: (options: { image?: string; text?: string }) => Promise<void>;
    inviteFriends: (options: { text?: string }) => Promise<void>;
    joinCommunity: (url: string) => Promise<void>;
    addToFavorites: () => Promise<void>;
    rateGame: () => Promise<void>;
  };
  events: {
    REWARDED_STATE_CHANGED: string;
    INTERSTITIAL_STATE_CHANGED: string;
    BANNER_STATE_CHANGED: string;
    PAUSE: string;
    RESUME: string;
    AUDIO_ENABLED: string;
    AUDIO_DISABLED: string;
  };
}

let isInitialized = false;
let platformLanguage: Language = 'en';
let isPaused = false;
let isAudioEnabled = true;

// Callbacks
let onPauseCallback: (() => void) | null = null;
let onResumeCallback: (() => void) | null = null;
let onAudioChangedCallback: ((enabled: boolean) => void) | null = null;

/**
 * Attende che lo script CDN di Playgama Bridge esponga window.bridge.
 * Lo script nel <head> e' bloccante, quindi in genere e' gia' pronto;
 * il polling copre caricamenti lenti o differiti (max ~5 secondi).
 */
function waitForBridge(timeoutMs: number = 5000): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window !== 'undefined' && window.bridge) {
      resolve(true);
      return;
    }
    const start = Date.now();
    const timer = setInterval(() => {
      if (typeof window !== 'undefined' && window.bridge) {
        clearInterval(timer);
        resolve(true);
      } else if (Date.now() - start >= timeoutMs) {
        clearInterval(timer);
        resolve(false);
      }
    }, 100);
  });
}

/**
 * Initialize Playgama Bridge SDK v2
 * Must be called before any other SDK method.
 * Funziona anche fuori dalle piattaforme supportate: Bridge usa una
 * "mock platform" con valori sicuri, quindi initialize() va sempre invocato.
 */
export async function initializePlaygama(): Promise<void> {
  try {
    const bridgeAvailable = await waitForBridge();

    if (typeof window !== 'undefined' && window.bridge && bridgeAvailable) {
      await window.bridge.initialize();
      isInitialized = true;

      // Get platform language
      const lang = window.bridge.platform?.language || 'en';
      platformLanguage = mapPlatformLanguage(lang);

      // Each SDK capability is optional and version-dependent:
      // every step is isolated so a missing method never aborts the rest.
      const safe = (fn: () => void) => { try { fn(); } catch (e) { console.warn('[Playgama] step skipped:', e); } };

      // Subscribe to pause/resume events
      if (typeof window.bridge.platform?.on === 'function') {
        safe(() => window.bridge.platform.on('pause', () => {
          isPaused = true;
          if (onPauseCallback) onPauseCallback();
        }));

        safe(() => window.bridge.platform.on('resume', () => {
          isPaused = false;
          if (onResumeCallback) onResumeCallback();
        }));

        safe(() => window.bridge.platform.on('audio_enabled', () => {
          isAudioEnabled = true;
          if (onAudioChangedCallback) onAudioChangedCallback(true);
        }));

        safe(() => window.bridge.platform.on('audio_disabled', () => {
          isAudioEnabled = false;
          if (onAudioChangedCallback) onAudioChangedCallback(false);
        }));
      }

      // Check initial audio state
      if (typeof window.bridge.platform?.isAudioEnabled === 'function') {
        safe(() => { isAudioEnabled = window.bridge.platform.isAudioEnabled(); });
      }

      // Send game_ready message
      if (typeof window.bridge.platform?.sendMessage === 'function') {
        safe(() => window.bridge.platform.sendMessage('game_ready'));
      }

      console.log('[Playgama] SDK initialized successfully');
      console.log('[Playgama] Platform:', window.bridge.platform?.id || 'unknown');
      console.log('[Playgama] Language:', platformLanguage);
    } else {
      console.log('[Playgama] SDK not available, using mock platform');
    }
  } catch (error) {
    console.error('[Playgama] Initialization error:', error);
  }
}

/**
 * Map platform language code to game language
 */
function mapPlatformLanguage(platformLang: string): Language {
  const langMap: Record<string, Language> = {
    'en': 'en',
    'it': 'it',
    'fr': 'fr',
    'es': 'es',
    'tr': 'tr',
  };
  
  // Try exact match first
  if (langMap[platformLang]) return langMap[platformLang];
  
  // Try language prefix (e.g., 'en-US' -> 'en')
  const prefix = platformLang.split('-')[0].toLowerCase();
  if (langMap[prefix]) return langMap[prefix];
  
  // Default to English
  return 'en';
}

/**
 * Get the platform language
 */
export function getPlatformLanguage(): Language {
  return platformLanguage;
}

/**
 * Check if SDK is initialized
 */
export function isPlaygamaReady(): boolean {
  return isInitialized;
}

/**
 * Check if game is paused
 */
export function getIsPaused(): boolean {
  return isPaused;
}

/**
 * Check if audio is enabled
 */
export function getIsAudioEnabled(): boolean {
  return isAudioEnabled;
}

/**
 * Set pause callback
 */
export function onPause(callback: () => void) {
  onPauseCallback = callback;
}

/**
 * Set resume callback
 */
export function onResume(callback: () => void) {
  onResumeCallback = callback;
}

/**
 * Set audio changed callback
 */
export function onAudioChanged(callback: (enabled: boolean) => void) {
  onAudioChangedCallback = callback;
}

// ============================================================
// STORAGE - Use Playgama storage instead of localStorage
// ============================================================

// Store timestamped copies locally and in Playgama when available. Older
// Playgama values that predate the envelope are still accepted on read.
type StorageType = 'local_storage' | 'platform_internal';
const LOCAL_PREFIX = 'hm_save_';
const unreadableKeys = new Set<string>();

function parseEnvelope(raw: any): { savedAt: number; data: any } | null {
  if (raw === null || raw === undefined) return null;
  let value = raw;
  if (typeof value === 'string') {
    try {
      value = JSON.parse(value);
    } catch {
      return null;
    }
  }
  if (value && typeof value === 'object' && value.v === 1 && 'data' in value) {
    return { savedAt: Number(value.savedAt) || 0, data: value.data };
  }
  if (value && typeof value === 'object') return { savedAt: 1, data: value };
  return null;
}

function bridgeStorageTypes(): (StorageType | undefined)[] {
  const types: (StorageType | undefined)[] = [undefined];
  try {
    const storage = window.bridge?.storage;
    if (storage && typeof storage.isAvailable === 'function') {
      if (storage.isAvailable('platform_internal')) types.push('platform_internal');
      if (storage.isAvailable('local_storage')) types.push('local_storage');
    }
  } catch {
    // Older Bridge versions may not expose isAvailable.
  }
  return types;
}

/**
 * Save timestamped data locally and to each available Playgama storage.
 */
export async function saveData(key: string, value: any): Promise<void> {
  if (unreadableKeys.has(key)) {
    console.warn('[Storage] Read failed for', key, '- save blocked to protect existing progress');
    return;
  }

  const payload = JSON.stringify({ v: 1, savedAt: Date.now(), data: value });
  try {
    window.localStorage.setItem(LOCAL_PREFIX + key, payload);
  } catch {
    // Local storage may be blocked in embedded browsers.
  }

  if (!isInitialized || typeof window.bridge?.storage?.set !== 'function') return;
  const results = await Promise.allSettled(
    bridgeStorageTypes().map(type =>
      type
        ? window.bridge.storage.set(key, payload, type)
        : window.bridge.storage.set(key, payload)
    )
  );
  results.forEach(result => {
    if (result.status === 'rejected') console.warn('[Storage] set failed:', result.reason);
  });
}

/**
 * Read all available copies and return the most recently saved value.
 */
export async function loadData<T>(key: string, defaultValue: T): Promise<T> {
  const candidates: { savedAt: number; data: any }[] = [];
  let anyError = false;
  let anySourceOk = false;

  try {
    const local = window.localStorage.getItem(LOCAL_PREFIX + key);
    anySourceOk = true;
    const parsed = parseEnvelope(local);
    if (parsed) candidates.push(parsed);
  } catch {
    // Continue with Playgama storage.
  }

  if (isInitialized && typeof window.bridge?.storage?.get === 'function') {
    const reads = await Promise.allSettled(
      bridgeStorageTypes().map(type =>
        type
          ? window.bridge.storage.get(key, type)
          : window.bridge.storage.get(key)
      )
    );
    reads.forEach(result => {
      if (result.status === 'fulfilled') {
        anySourceOk = true;
        const parsed = parseEnvelope(result.value);
        if (parsed) candidates.push(parsed);
      } else {
        anyError = true;
        console.warn('[Storage] get failed:', result.reason);
      }
    });
  }

  if (candidates.length > 0) {
    unreadableKeys.delete(key);
    candidates.sort((a, b) => b.savedAt - a.savedAt);
    return candidates[0].data as T;
  }

  // If every read failed, don't overwrite possibly recoverable cloud progress.
  if (anyError || !anySourceOk) unreadableKeys.add(key);
  return defaultValue;
}

/**
 * Delete local and Playgama copies.
 */
export async function deleteData(key: string): Promise<void> {
  unreadableKeys.delete(key);
  try {
    window.localStorage.removeItem(LOCAL_PREFIX + key);
  } catch {
    // Ignore blocked local storage.
  }

  try {
    if (isInitialized && typeof window.bridge?.storage?.delete === 'function') {
      await Promise.allSettled(
        bridgeStorageTypes().map(type =>
          type
            ? window.bridge.storage.delete(key, type)
            : window.bridge.storage.delete(key)
        )
      );
    }
  } catch (error) {
    console.error('[Playgama] Delete error:', error);
  }
}

// ============================================================
// ADVERTISEMENTS
// ============================================================

/**
 * Show interstitial ad (at natural pauses like level transitions)
 * Only works with Playgama SDK - does nothing if SDK is not available
 * Logs the outcome so ad issues are visible in the console
 */
// Bug fix: il listener di log degli interstitial viene registrato UNA sola
// volta (prima si accumulava un handler a ogni pubblicita' mostrata)
let interstitialListenerRegistered = false;

export async function showInterstitialAd(): Promise<boolean> {
  try {
    if (isInitialized && typeof window.bridge?.advertisement?.showInterstitial === 'function') {
      if (!interstitialListenerRegistered && typeof window.bridge.advertisement?.on === 'function') {
        interstitialListenerRegistered = true;
        window.bridge.advertisement.on('interstitial_state_changed', (state: string) => {
          console.log('[Playgama] Interstitial state:', state);
        });
      }
      await window.bridge.advertisement.showInterstitial();
      console.log('[Playgama] Interstitial shown');
      return true;
    }
    console.log('[Playgama] Interstitial skipped: SDK not initialized or ad module unavailable');
    return false;
  } catch (error) {
    console.error('[Playgama] Interstitial ad error:', error);
    return false;
  }
}

/**
 * Show rewarded ad (for in-game rewards)
 * Returns:
 *  - 'rewarded'    -> l'utente ha GUADAGNATO la ricompensa (stato 'rewarded')
 *  - 'closed'      -> l'utente ha chiuso l'ad prima della fine: niente premio
 *  - 'failed'      -> l'ad non e' partita (nessun fill, placement rifiutato,
 *                     piattaforma mock): il chiamante puo' usare un fallback
 *  - 'unavailable' -> SDK assente: il chiamante puo' usare un fallback
 */
export type RewardedAdResult = 'rewarded' | 'closed' | 'failed' | 'unavailable';

export function showRewardedAd(placementId?: string): Promise<RewardedAdResult> {
  return new Promise((resolve) => {
    try {
      if (isInitialized && typeof window.bridge?.advertisement?.showRewarded === 'function' && typeof window.bridge?.advertisement?.on === 'function') {
        let resolved = false;

        const finish = (result: RewardedAdResult) => {
          if (resolved) return;
          resolved = true;
          try {
            window.bridge.advertisement.off('rewarded_state_changed', handler);
          } catch (e) { /* off non supportato: ignora */ }
          resolve(result);
        };

        const handler = (state: string) => {
          console.log('[Playgama] Rewarded state:', state);
          if (state === 'rewarded') {
            finish('rewarded');
          } else if (state === 'failed') {
            // Bug fix: 'failed' NON e' una chiusura volontaria: l'ad non e'
            // mai partita, quindi il chiamante puo' attivare il fallback
            finish('failed');
          } else if (state === 'closed') {
            finish('closed');
          }
        };

        window.bridge.advertisement.on('rewarded_state_changed', handler);

        // Bug fix: se il placement specifico non esiste nella config, il SDK
        // puo' rifiutare la richiesta. Si riprova senza placement (usa il
        // placementFallback della config) prima di dichiarare fallimento.
        const request = typeof placementId === 'string' && placementId.length > 0
          ? window.bridge.advertisement.showRewarded(placementId)
          : window.bridge.advertisement.showRewarded();

        Promise.resolve(request).catch(() => {
          if (resolved) return;
          if (placementId) {
            console.warn('[Playgama] Rewarded con placement fallita, riprovo con fallback');
            try {
              Promise.resolve(window.bridge.advertisement.showRewarded()).catch(() => finish('failed'));
            } catch (e) {
              finish('failed');
            }
          } else {
            finish('failed');
          }
        });

        // Timeout di sicurezza: se non arriva mai uno stato finale
        setTimeout(() => finish('failed'), 60000);
      } else {
        // SDK not available
        resolve('unavailable');
      }
    } catch (error) {
      console.error('[Playgama] Rewarded ad error:', error);
      resolve('failed');
    }
  });
}

// ============================================================
// ANALYTICS
// ============================================================

/**
 * Report gameplay start
 */
export function reportGameplayStart(): void {
  try {
    if (isInitialized && typeof window.bridge?.analytics?.onGameplayStart === 'function') {
      window.bridge.analytics.onGameplayStart();
    }
  } catch (error) {
    console.error('[Playgama] Analytics error:', error);
  }
}

/**
 * Report gameplay stop
 */
export function reportGameplayStop(): void {
  try {
    if (isInitialized && typeof window.bridge?.analytics?.onGameplayStop === 'function') {
      window.bridge.analytics.onGameplayStop();
    }
  } catch (error) {
    console.error('[Playgama] Analytics error:', error);
  }
}

/**
 * Report level complete
 */
export function reportLevelComplete(levelId: string, score?: number): void {
  try {
    if (isInitialized && typeof window.bridge?.analytics?.onLevelComplete === 'function') {
      window.bridge.analytics.onLevelComplete(levelId, score);
    }
  } catch (error) {
    console.error('[Playgama] Analytics error:', error);
  }
}

/**
 * Report level fail
 */
export function reportLevelFail(levelId: string): void {
  try {
    if (isInitialized && typeof window.bridge?.analytics?.onLevelFail === 'function') {
      window.bridge.analytics.onLevelFail(levelId);
    }
  } catch (error) {
    console.error('[Playgama] Analytics error:', error);
  }
}

// ============================================================
// LEADERBOARDS
// ============================================================

/**
 * Set score on leaderboard
 */
export async function setLeaderboardScore(leaderboardId: string, score: number, extraData?: string): Promise<void> {
  try {
    if (isInitialized && typeof window.bridge?.leaderboard?.setScore === 'function') {
      await window.bridge.leaderboard.setScore(leaderboardId, score, extraData);
    }
  } catch (error) {
    console.error('[Playgama] Leaderboard error:', error);
  }
}

/**
 * Get leaderboard entries
 */
export async function getLeaderboardEntries(leaderboardId: string, limit: number = 10, includeCurrentUser: boolean = true): Promise<any[]> {
  try {
    if (isInitialized && typeof window.bridge?.leaderboard?.getEntries === 'function') {
      return await window.bridge.leaderboard.getEntries(leaderboardId, limit, includeCurrentUser);
    }
    return [];
  } catch (error) {
    console.error('[Playgama] Leaderboard error:', error);
    return [];
  }
}

// ============================================================
// ACHIEVEMENTS
// ============================================================

/**
 * Unlock achievement
 */
export async function unlockAchievement(achievementId: string): Promise<void> {
  try {
    if (isInitialized && typeof window.bridge?.achievement?.unlock === 'function') {
      await window.bridge.achievement.unlock(achievementId);
    }
  } catch (error) {
    console.error('[Playgama] Achievement error:', error);
  }
}

// ============================================================
// DAILY REWARDS
// ============================================================

/**
 * Check if daily reward is ready
 */
export async function isDailyRewardReady(): Promise<boolean> {
  try {
    if (isInitialized && typeof window.bridge?.dailyReward?.isReady === 'function') {
      return await window.bridge.dailyReward.isReady();
    }
    return false;
  } catch (error) {
    console.error('[Playgama] Daily reward error:', error);
    return false;
  }
}

/**
 * Claim daily reward
 */
export async function claimDailyReward(): Promise<any> {
  try {
    if (isInitialized && typeof window.bridge?.dailyReward?.claim === 'function') {
      return await window.bridge.dailyReward.claim();
    }
    return null;
  } catch (error) {
    console.error('[Playgama] Daily reward error:', error);
    return null;
  }
}

// ============================================================
// SOCIAL
// ============================================================

/**
 * Share game
 */
export async function shareGame(text?: string): Promise<void> {
  try {
    if (isInitialized && typeof window.bridge?.social?.share === 'function') {
      await window.bridge.social.share({ text: text || 'Play Halloween Monsters!' });
    }
  } catch (error) {
    console.error('[Playgama] Social share error:', error);
  }
}

/**
 * Invite friends
 */
export async function inviteFriends(text?: string): Promise<void> {
  try {
    if (isInitialized && typeof window.bridge?.social?.inviteFriends === 'function') {
      await window.bridge.social.inviteFriends({ text: text || 'Come play Halloween Monsters with me!' });
    }
  } catch (error) {
    console.error('[Playgama] Social invite error:', error);
  }
}

/**
 * Rate game
 */
export async function rateGame(): Promise<void> {
  try {
    if (isInitialized && typeof window.bridge?.social?.rateGame === 'function') {
      await window.bridge.social.rateGame();
    }
  } catch (error) {
    console.error('[Playgama] Rate game error:', error);
  }
}

/**
 * Add to favorites
 */
export async function addToFavorites(): Promise<void> {
  try {
    if (isInitialized && typeof window.bridge?.social?.addToFavorites === 'function') {
      await window.bridge.social.addToFavorites();
    }
  } catch (error) {
    console.error('[Playgama] Add to favorites error:', error);
  }
}
