// Accesso sicuro a localStorage.
// Dentro gli iframe delle piattaforme (Playgama, Safari privato, cookie di terze
// parti bloccati) localStorage puo' lanciare SecurityError: senza try/catch il
// gioco va in schermata bianca. Qui cadiamo su una memoria temporanea.
const memory = new Map<string, string>();

export function safeGetItem(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return memory.has(key) ? (memory.get(key) as string) : null;
  }
}

export function safeSetItem(key: string, value: string): void {
  memory.set(key, value);
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* storage non disponibile: resta in memoria */
  }
}

export function safeRemoveItem(key: string): void {
  memory.delete(key);
  try {
    window.localStorage.removeItem(key);
  } catch {
    /* ignora */
  }
}

/** Legge un booleano salvato come JSON ("true"/"false"); valore di default se assente o corrotto. */
export function safeGetBool(key: string, fallback: boolean): boolean {
  const raw = safeGetItem(key);
  if (raw === null) return fallback;
  try {
    const v = JSON.parse(raw);
    return typeof v === 'boolean' ? v : fallback;
  } catch {
    return fallback;
  }
}
