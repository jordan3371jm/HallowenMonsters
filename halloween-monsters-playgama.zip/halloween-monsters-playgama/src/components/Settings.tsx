import { useState, useEffect } from 'react';
import { Language, languageNames } from '../i18n';
import { loadData, saveData } from '../playgama';

interface SettingsProps {
  lang: Language;
  onLangChange: (lang: Language) => void;
  onBack: () => void;
}

export default function Settings({ lang, onLangChange, onBack }: SettingsProps) {
  const [battleEffects, setBattleEffects] = useState(true);
  const [screenShake, setScreenShake] = useState(true);
  const [animations, setAnimations] = useState(true);
  const [loaded, setLoaded] = useState(false);

  // Load settings from Playgama storage on mount
  useEffect(() => {
    const loadSettings = async () => {
      const effects = await loadData<boolean>('battleEffects', true);
      const shake = await loadData<boolean>('screenShake', true);
      const anims = await loadData<boolean>('animations', true);
      setBattleEffects(effects);
      setScreenShake(shake);
      setAnimations(anims);
      setLoaded(true);
    };
    loadSettings();
  }, []);

  useEffect(() => {
    if (loaded) {
      saveData('battleEffects', battleEffects);
    }
  }, [battleEffects, loaded]);

  useEffect(() => {
    if (loaded) {
      saveData('screenShake', screenShake);
    }
  }, [screenShake, loaded]);

  useEffect(() => {
    if (loaded) {
      saveData('animations', animations);
    }
  }, [animations, loaded]);

  const handleLangChange = (newLang: Language) => {
    onLangChange(newLang);
    saveData('halloween_monsters_lang', newLang);
  };

  const translations = {
    en: {
      title: 'Settings',
      back: 'Back',
      language: 'Language',
      graphics: 'Graphics',
      battleEffects: 'Battle Effects',
      battleEffectsDesc: 'Show visual effects during attacks',
      screenShake: 'Screen Shake',
      screenShakeDesc: 'Screen shake on powerful attacks',
      animations: 'Animations',
      animationsDesc: 'Enable UI animations',
      enabled: 'Enabled',
      disabled: 'Disabled',
    },
    it: {
      title: 'Impostazioni',
      back: 'Indietro',
      language: 'Lingua',
      graphics: 'Grafica',
      battleEffects: 'Effetti di Battaglia',
      battleEffectsDesc: 'Mostra effetti visivi durante gli attacchi',
      screenShake: 'Scuotimento Schermo',
      screenShakeDesc: 'Scuotimento schermo su attacchi potenti',
      animations: 'Animazioni',
      animationsDesc: 'Abilita animazioni UI',
      enabled: 'Abilitato',
      disabled: 'Disabilitato',
    },
    fr: {
      title: 'Paramètres',
      back: 'Retour',
      language: 'Langue',
      graphics: 'Graphismes',
      battleEffects: 'Effets de Combat',
      battleEffectsDesc: 'Afficher les effets visuels pendant les attaques',
      screenShake: 'Tremblement d\'Écran',
      screenShakeDesc: 'Tremblement d\'écran sur les attaques puissantes',
      animations: 'Animations',
      animationsDesc: 'Activer les animations UI',
      enabled: 'Activé',
      disabled: 'Désactivé',
    },
    es: {
      title: 'Configuración',
      back: 'Volver',
      language: 'Idioma',
      graphics: 'Gráficos',
      battleEffects: 'Efectos de Batalla',
      battleEffectsDesc: 'Mostrar efectos visuales durante los ataques',
      screenShake: 'Vibración de Pantalla',
      screenShakeDesc: 'Vibración de pantalla en ataques potentes',
      animations: 'Animaciones',
      animationsDesc: 'Habilitar animaciones UI',
      enabled: 'Habilitado',
      disabled: 'Deshabilitado',
    },
    tr: {
      title: 'Ayarlar',
      back: 'Geri',
      language: 'Dil',
      graphics: 'Grafikler',
      battleEffects: 'Savaş Efektleri',
      battleEffectsDesc: 'Saldırılar sırasında görsel efektleri göster',
      screenShake: 'Ekran Sarsıntısı',
      screenShakeDesc: 'Güçlü saldırılarda ekran sarsıntısı',
      animations: 'Animasyonlar',
      animationsDesc: 'UI animasyonlarını etkinleştir',
      enabled: 'Etkin',
      disabled: 'Devre Dışı',
    },
  };

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-950 via-gray-900 to-black p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-black/60 rounded-xl p-6 border-2 border-purple-600 mb-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-purple-400">
              ⚙️ {t.title}
            </h1>
            <button
              onClick={onBack}
              className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors font-bold"
            >
              ← {t.back}
            </button>
          </div>

          {/* Language Section */}
          <div className="mb-8">
            <h2 className="text-xl font-bold text-orange-400 mb-4">
              🌍 {t.language}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(languageNames).map(([code, name]) => (
                <button
                  key={code}
                  onClick={() => handleLangChange(code as Language)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    lang === code
                      ? 'bg-purple-600 border-purple-400 text-white font-bold scale-105'
                      : 'bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>

          {/* Graphics Section */}
          <div>
            <h2 className="text-xl font-bold text-orange-400 mb-4">
              🎨 {t.graphics}
            </h2>
            
            {/* Battle Effects Toggle */}
            <div className="bg-gray-800 rounded-lg p-4 mb-3 border border-gray-700">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-white font-bold text-lg">{t.battleEffects}</h3>
                  <p className="text-gray-400 text-sm">{t.battleEffectsDesc}</p>
                </div>
                <button
                  onClick={() => setBattleEffects(!battleEffects)}
                  className={`px-6 py-3 rounded-lg font-bold transition-all ${
                    battleEffects
                      ? 'bg-green-600 hover:bg-green-700 text-white'
                      : 'bg-red-600 hover:bg-red-700 text-white'
                  }`}
                >
                  {battleEffects ? t.enabled : t.disabled}
                </button>
              </div>
            </div>

            {/* Screen Shake Toggle */}
            <div className="bg-gray-800 rounded-lg p-4 mb-3 border border-gray-700">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-white font-bold text-lg">{t.screenShake}</h3>
                  <p className="text-gray-400 text-sm">{t.screenShakeDesc}</p>
                </div>
                <button
                  onClick={() => setScreenShake(!screenShake)}
                  className={`px-6 py-3 rounded-lg font-bold transition-all ${
                    screenShake
                      ? 'bg-green-600 hover:bg-green-700 text-white'
                      : 'bg-red-600 hover:bg-red-700 text-white'
                  }`}
                >
                  {screenShake ? t.enabled : t.disabled}
                </button>
              </div>
            </div>

            {/* Animations Toggle */}
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-white font-bold text-lg">{t.animations}</h3>
                  <p className="text-gray-400 text-sm">{t.animationsDesc}</p>
                </div>
                <button
                  onClick={() => setAnimations(!animations)}
                  className={`px-6 py-3 rounded-lg font-bold transition-all ${
                    animations
                      ? 'bg-green-600 hover:bg-green-700 text-white'
                      : 'bg-red-600 hover:bg-red-700 text-white'
                  }`}
                >
                  {animations ? t.enabled : t.disabled}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
