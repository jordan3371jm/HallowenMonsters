import { useState, useCallback, useEffect, useRef } from 'react';
import { GameState, GamePhase, Monster, ItemType, MapNode, MapNodeType, StatusEffect, PersistentData, MetaUpgrade } from './types';
import { starters, wildMonsters, rareMonsters, generateEnemyMonster, generateRareMonster, generateLegendaryMonster, generateMythicalMonster, generateGymLeaderMonsters, trainerTeams, calculateDamage, typeEmojis, typeColors, allMoves } from './data/monsters';
import { Language, languageNames, t, tMonster, tMove, tItem, tItemDesc, tType, tStatus } from './i18n';
import {
  tAbilityName, tAbilityDesc, getAbilityDamageMultiplier, getAbilityDefenseMultiplier,
  getDodgeChance, getLifesteal, getCounter, getAttackerAccuracyMod, getOnHitStatus,
  getTurnRegen, getModifiedEffectChance, isStatusImmune, trySurviveKO,
} from './abilities';
import { defaultUpgrades, calculateCursedCoinsReward, canPurchaseUpgrade, getUpgradeCost } from './metaShop';
import MetaShop from './MetaShop';
import {
  advanceObjectives, generateDailyObjectives, generateMonthlyObjectives, generateWeeklyObjectives,
  getDailyPeriodKey, getLoginReward, getMonthlyPeriodKey, getWeeklyPeriodKey, initializeAchievements,
  checkAchievements, migrateObjectives,
} from './rewards';
import { dailyObjectiveTranslations, achievementTranslations } from './rewardTranslations';
import MonsterIcon from './components/MonsterIcons';
import { CoinIcon, ShopIcon, TargetIcon, TrophyIcon, ChartIcon, GearIcon, PlayIcon, FilmIcon } from './components/UIIcons';
import { getMonsterIconPath } from './data/monsterPNGIcons';

import { showToast } from './toast';
import Statistics from './components/Statistics';
import Settings from './components/Settings';
import BattleAnimation, { useScreenShake, ScreenTransition } from './components/BattleAnimations';
import {
  initializePlaygama,
  getPlatformLanguage,
  saveData,
  loadData,
  showInterstitialAd,
  showRewardedAd,
  reportGameplayStart,
  reportGameplayStop,
  reportLevelComplete,
  reportLevelFail,
  onPause,
  onResume,
} from './playgama';

type Weather = 'normale' | 'luna_piena' | 'nebbia' | 'notte_halloween';
type ChallengePeriod = 'daily' | 'weekly' | 'monthly';

function getRandomWeather(): Weather {
  const roll = Math.random();
  if (roll < 0.15) return 'luna_piena';
  if (roll < 0.25) return 'nebbia';
  if (roll < 0.35) return 'notte_halloween';
  return 'normale';
}

const weatherInfo: Record<Weather, { nameKey: string; emoji: string; descKey: string }> = {
  normale: { nameKey: '', emoji: '🌙', descKey: '' },
  luna_piena: { nameKey: 'weather.luna_piena', emoji: '🌕', descKey: 'weather.spettro_boost' },
  nebbia: { nameKey: 'weather.nebbia', emoji: '🌫️', descKey: 'weather.precision_down' },
  notte_halloween: { nameKey: 'weather.notte_halloween', emoji: '🎃', descKey: 'weather.buio_spettro_boost' },
};

function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

function generateMap(wave: number): MapNode[] {
  const nodes: MapNode[] = [];
  
  // Genera tipi di nodi basati sulla wave
  // Ogni mappa ha il capopalestra all'ultimo nodo
  const types: MapNodeType[] = [];
  for (let i = 0; i < 10; i++) {
    if (i === 9) {
      // Ultimo nodo: sempre gym leader
      types.push('gym_leader');
    } else if (i === 3 || i === 7) {
      // Nodi 3 e 7: sempre shop
      types.push('shop');
    } else if (i === 5) {
      // Nodo 5: sempre evento
      types.push('event');
    } else {
      // Altri nodi: wild o trainer (più trainer con wave alte)
      const trainerChance = Math.min(0.6, 0.2 + wave * 0.01);
      types.push(Math.random() < trainerChance ? 'trainer' : 'wild');
    }
  }
  
  for (let i = 0; i < 10; i++) {
    const connections: number[] = [];
    if (i < 9) {
      connections.push(i + 1);
      // Più connessioni alternative con wave alte per più scelta
      const extraConnectionChance = Math.min(0.7, 0.3 + wave * 0.02);
      if (i + 2 < 10 && Math.random() < extraConnectionChance) {
        connections.push(i + 2);
      }
      // Connessioni saltate per wave molto alte
      if (wave > 20 && i + 3 < 10 && Math.random() < 0.2) {
        connections.push(i + 3);
      }
    }
    nodes.push({
      id: i,
      type: types[i],
      completed: false,
      connections,
    });
  }
  return nodes;
}

const defaultItems: ItemType[] = [
  { id: 'pozione_sangue', name: 'Pozione Sangue di Zucca', description: 'Ripristina 30 HP', quantity: 2, category: 'potion', power: 30, emoji: '🧪' },
  { id: 'super_pozione', name: 'Super Pozione di Sangue', description: 'Ripristina 50 HP', quantity: 1, category: 'potion', power: 50, emoji: '🧪' },
  { id: 'iper_pozione', name: 'Iper Pozione Maledetta', description: 'Ripristina 120 HP', quantity: 0, category: 'potion', power: 120, emoji: '🧪' },
  { id: 'elisir_spettrale', name: 'Elisir Spettrale', description: 'Cura tutti gli status alterati', quantity: 1, category: 'potion', power: 0, emoji: '⚗️' },
  { id: 'candela_protettiva', name: 'Candela Protettiva', description: 'Cura status + 10 HP', quantity: 0, category: 'tool', power: 10, emoji: '🕯️' },
  { id: 'lacrime_banshee', name: 'Lacrime di Banshee', description: 'Resuscita un mostro a metà HP', quantity: 0, category: 'tool', power: 0, emoji: '💧' },
  { id: 'frammento_luna', name: 'Frammento di Luna', description: 'Recupera 30 HP a tutta la squadra', quantity: 0, category: 'potion', power: 30, emoji: '🌙' },
  { id: 'nettare_zucca', name: 'Nettare di Zucca', description: '+10 HP massimi permanenti (in-run)', quantity: 0, category: 'tool', power: 10, emoji: '🍯' },
  { id: 'pozione_non_morte', name: 'Pozione della Non-Morte', description: 'Evita un KO una volta per battaglia', quantity: 0, category: 'tool', power: 0, emoji: '💀' },
  { id: 'caramella_stregata', name: 'Caramella Stregata', description: 'Cattura mostri (1x)', quantity: 3, category: 'capture', power: 30, emoji: '🍬' },
  { id: 'zucca_vuota', name: 'Zucca Vuota', description: 'Cattura mostri (1.5x)', quantity: 1, category: 'capture', power: 50, emoji: '🎃' },
  { id: 'bara_antica', name: 'Bara Antica', description: 'Cattura mostri (2x)', quantity: 0, category: 'capture', power: 75, emoji: '⚰️' },
  { id: 'amuleto_maledetto', name: 'Amuleto Maledetto', description: 'Cattura mostri (3x)', quantity: 0, category: 'capture', power: 100, emoji: '🔮' },
  { id: 'rete_becchino', name: 'Rete del Becchino', description: 'Cattura automatica sotto 20% HP', quantity: 0, category: 'capture', power: 999, emoji: '🕸️' },
  { id: 'sfera_re_zucche', name: 'Sfera del Re delle Zucche', description: 'Cattura garantita su mostri non boss', quantity: 0, category: 'capture', power: 9999, emoji: '👑' },
  { id: 'cristallo_pp', name: 'Cristallo PP', description: 'Ripristina 10 PP a una mossa', quantity: 1, category: 'tool', power: 10, emoji: '💎' },
  { id: 'cristallo_pp_totale', name: 'Cristallo PP Totale', description: 'Ripristina tutti i PP di tutte le mosse', quantity: 0, category: 'tool', power: 999, emoji: '💠' },
];

function getUpgradeLevel(upgrades: MetaUpgrade[], upgradeId: string): number {
  const upgrade = upgrades.find(item => item.id === upgradeId);
  return Math.max(0, upgrade?.currentLevel || (upgrade?.purchased ? 1 : 0));
}

function hasUpgrade(upgrades: MetaUpgrade[], upgradeId: string): boolean {
  return getUpgradeLevel(upgrades, upgradeId) > 0;
}

function applyMetaBonusesToMonster(monster: Monster, upgrades: MetaUpgrade[]): Monster {
  const result = deepClone(monster);
  if (hasUpgrade(upgrades, 'held_item_bone')) result.stats.attack = Math.floor(result.stats.attack * 1.1);
  if (hasUpgrade(upgrades, 'held_item_mist')) result.stats.defense = Math.floor(result.stats.defense * 1.1);
  if (hasUpgrade(upgrades, 'held_item_feather')) result.stats.speed = Math.floor(result.stats.speed * 1.1);
  if (hasUpgrade(upgrades, 'held_item_heart')) {
    const oldMaxHp = result.stats.maxHp;
    result.stats.maxHp = Math.floor(oldMaxHp * 1.1);
    result.stats.hp = Math.min(result.stats.maxHp, Math.floor(result.stats.hp * result.stats.maxHp / oldMaxHp));
  }
  if (hasUpgrade(upgrades, 'held_item_eye')) {
    result.moves = result.moves.map(move => ({ ...move, accuracy: Math.min(100, Math.round(move.accuracy * 1.1)) }));
  }
  return result;
}

function grantBenchExperience(team: Monster[], activeIndex: number, activeExp: number, upgrades: MetaUpgrade[]) {
  const sharedRate = hasUpgrade(upgrades, 'exp_share_perfect')
    ? 1
    : hasUpgrade(upgrades, 'exp_share_total')
      ? 0.5
      : hasUpgrade(upgrades, 'exp_share_base')
        ? 0.25
        : 0;
  const shareRate = Math.min(1, sharedRate + getUpgradeLevel(upgrades, 'bench_training') * 0.01);
  if (shareRate <= 0) return;
  const learnLevels = new Set([7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40]);

  team.forEach((monster, index) => {
    if (index === activeIndex) return;
    monster.exp += Math.floor(activeExp * shareRate);
    while (monster.exp >= monster.expToNext) {
      const previousLevel = monster.level;
      monster.exp -= monster.expToNext;
      monster.level++;
      monster.expToNext = Math.floor(monster.expToNext * 1.3);
      monster.stats.maxHp += 3;
      monster.stats.hp += 3;
      monster.stats.attack += 2;
      monster.stats.defense += 1;
      monster.stats.speed += 1;

      const evolution = monster.evolutions?.find(item => previousLevel < item.level && monster.level >= item.level);
      if (evolution) {
        monster.id = evolution.id;
        monster.name = evolution.name;
        monster.emoji = evolution.emoji;
        const template = [...starters, ...wildMonsters, ...rareMonsters].find(item => item.id === evolution.id);
        if (template) {
          monster.type = template.type;
          monster.ability = template.ability;
          monster.abilityDesc = template.abilityDesc;
          monster.rarity = template.rarity;
          monster.tier = template.tier;
          monster.evolutions = template.evolutions;
        }
        monster.stats.maxHp += 15;
        monster.stats.hp += 15;
        monster.stats.attack += 8;
        monster.stats.defense += 5;
        monster.stats.speed += 4;
      }

      if (learnLevels.has(monster.level) && monster.moves.length < 4) {
        const options = allMoves.filter(move =>
          move.type === monster.type && !monster.moves.some(known => known.id === move.id)
        );
        if (options.length) monster.moves.push(deepClone(options[Math.floor(Math.random() * options.length)]));
      }
    }
  });
}

// Funzione per applicare gli upgrade del Meta Shop agli item iniziali
function applyUpgradesToItems(upgrades: MetaUpgrade[]): ItemType[] {
  const items = deepClone(defaultItems);
  
  upgrades.forEach(upgrade => {
    const level = getUpgradeLevel(upgrades, upgrade.id);
    if (level === 0) return;
    
    switch (upgrade.id) {
      case 'extra_potion': {
        const item = items.find(i => i.id === 'pozione_sangue');
        if (item) item.quantity += level;
        break;
      }
      case 'super_potion_extra': {
        const item = items.find(i => i.id === 'super_pozione');
        if (item) item.quantity += level;
        break;
      }
      case 'elisir_extra': {
        const item = items.find(i => i.id === 'elisir_spettrale');
        if (item) item.quantity += level;
        break;
      }
      case 'candy_stock': {
        const item = items.find(i => i.id === 'caramella_stregata');
        if (item) item.quantity += level;
        break;
      }
      case 'pumpkin_stock': {
        const item = items.find(i => i.id === 'zucca_vuota');
        if (item) item.quantity += level;
        break;
      }
      case 'coffin_stock': {
        const item = items.find(i => i.id === 'bara_antica');
        if (item) item.quantity += level;
        break;
      }
    }
  });
  
  return items;
}

function getItemStackCapacity(itemId: string, upgrades: MetaUpgrade[]): number {
  const defaultItem = defaultItems.find(item => item.id === itemId);
  const startingStockUpgrade: Record<string, string> = {
    pozione_sangue: 'extra_potion',
    super_pozione: 'super_potion_extra',
    elisir_spettrale: 'elisir_extra',
  };
  return Math.max(1, defaultItem?.quantity || 0)
    + getUpgradeLevel(upgrades, 'potion_bag')
    + getUpgradeLevel(upgrades, startingStockUpgrade[itemId] || '');
}

function getDefaultPersistentData(): PersistentData {
  return {
    cursedCoins: 0,
    totalRuns: 0,
    bestWave: 0,
    totalMedals: 0,
    upgrades: deepClone(defaultUpgrades),
    lastLoginDate: '',
    loginStreak: 0,
    dailyObjectives: [],
    dailyObjectivesDate: '',
    weeklyObjectives: [],
    weeklyObjectivesWeek: '',
    monthlyObjectives: [],
    monthlyObjectivesMonth: '',
    achievements: [],
    totalMonstersDefeated: 0,
    totalMonstersCaught: 0,
    totalGymLeadersDefeated: 0,
    // Statistiche dettagliate
    totalBattles: 0,
    totalWins: 0,
    totalLosses: 0,
    bestRunWave: 0,
    mostCatchesInRun: 0,
    totalPlayTime: 0,
    longestWinStreak: 0,
    currentWinStreak: 0,
    totalDamageDealt: 0,
    totalDamageTaken: 0,
    totalHealing: 0,
    favoriteMonster: '',
    monsterUsage: {},
    adCoinsDate: '',
    adCoinsWatched: 0,
  };
}

function migratePersistentData(data: any): PersistentData {
  data = data && typeof data === 'object' ? data : {};
  const migratedObjectives = migrateObjectives(Array.isArray(data.dailyObjectives) ? data.dailyObjectives : []);
  const migratedWeeklyObjectives = migrateObjectives(Array.isArray(data.weeklyObjectives) ? data.weeklyObjectives : []);
  const migratedMonthlyObjectives = migrateObjectives(Array.isArray(data.monthlyObjectives) ? data.monthlyObjectives : []);
  
  // Migra achievement per aggiungere il campo claimed
  const savedAchievements = Array.isArray(data.achievements) ? data.achievements : [];
  const migratedAchievements = initializeAchievements().map(defaultAchievement => {
    const savedAchievement = savedAchievements.find((ach: any) => ach.id === defaultAchievement.id);
    if (!savedAchievement) return defaultAchievement;
    return {
      ...defaultAchievement,
      ...savedAchievement,
      // I vecchi risultati sbloccati non devono poter pagare una seconda volta.
      claimed: savedAchievement.claimed !== undefined
        ? savedAchievement.claimed
        : Boolean(savedAchievement.unlocked),
    };
  });
  
  // Migra upgrade per aggiornare i prezzi con i nuovi valori e rimuovere upgrade obsoleti
  const savedUpgrades = Array.isArray(data.upgrades) ? data.upgrades : [];
  const migratedUpgrades = defaultUpgrades.map(defaultUpgrade => {
    // Trova l'upgrade corrispondente nei dati salvati
    const savedUpgrade = savedUpgrades.find((u: any) => u.id === defaultUpgrade.id);
    if (savedUpgrade) {
      // Mantieni lo stato di acquisto ma aggiorna il prezzo e i dettagli
      return {
        ...defaultUpgrade,
        purchased: savedUpgrade.purchased || false,
        currentLevel: savedUpgrade.currentLevel || 0,
      };
    }
    // Se non esiste nei dati salvati, usa il default
    return { ...defaultUpgrade };
  });
  
  return {
    cursedCoins: data.cursedCoins || 0,
    totalRuns: data.totalRuns || 0,
    bestWave: data.bestWave || 0,
    totalMedals: data.totalMedals || 0,
    upgrades: migratedUpgrades,
    lastLoginDate: data.lastLoginDate || '',
    loginStreak: data.loginStreak || 0,
    dailyObjectives: migratedObjectives,
    dailyObjectivesDate: data.dailyObjectivesDate || '',
    weeklyObjectives: migratedWeeklyObjectives,
    weeklyObjectivesWeek: data.weeklyObjectivesWeek || '',
    monthlyObjectives: migratedMonthlyObjectives,
    monthlyObjectivesMonth: data.monthlyObjectivesMonth || '',
    achievements: migratedAchievements,
    totalMonstersDefeated: data.totalMonstersDefeated || 0,
    totalMonstersCaught: data.totalMonstersCaught || 0,
    totalGymLeadersDefeated: data.totalGymLeadersDefeated || 0,
    // Statistiche dettagliate
    totalBattles: data.totalBattles || 0,
    totalWins: data.totalWins || 0,
    totalLosses: data.totalLosses || 0,
    bestRunWave: data.bestRunWave || data.bestWave || 0,
    mostCatchesInRun: data.mostCatchesInRun || 0,
    totalPlayTime: data.totalPlayTime || 0,
    longestWinStreak: data.longestWinStreak || 0,
    currentWinStreak: data.currentWinStreak || 0,
    totalDamageDealt: data.totalDamageDealt || 0,
    totalDamageTaken: data.totalDamageTaken || 0,
    totalHealing: data.totalHealing || 0,
    favoriteMonster: data.favoriteMonster || '',
    monsterUsage: data.monsterUsage || {},
    adCoinsDate: data.adCoinsDate || '',
    adCoinsWatched: data.adCoinsWatched || 0,
  };
}

// Ricompensa pubblicita' -> Monete Maledette
const AD_COINS_REWARD = 50;
const AD_COINS_DAILY_LIMIT = 10;

function getAdCoinsLeft(data: PersistentData): number {
  const today = new Date().toDateString();
  const watched = data.adCoinsDate === today ? data.adCoinsWatched : 0;
  return Math.max(0, AD_COINS_DAILY_LIMIT - watched);
}

async function loadPersistentData(): Promise<PersistentData> {
  try {
    const data = await loadData<PersistentData>('halloween_monsters_persistent', getDefaultPersistentData());
    return migratePersistentData(data);
  } catch (e) {
    console.error('Failed to load persistent data:', e);
  }
  return getDefaultPersistentData();
}

async function savePersistentData(data: PersistentData) {
  try {
    await saveData('halloween_monsters_persistent', data);
  } catch (e) {
    console.error('Failed to save persistent data:', e);
  }
}

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [persistentData, setPersistentData] = useState<PersistentData>(getDefaultPersistentData());
  // Bug fix: la ricompensa di login e gli obiettivi giornalieri partono solo
  // DOPO il caricamento asincrono dal Playgama storage, altrimenti il dato
  // cloud (con lastLoginDate di ieri) sovrascriveva quello appena aggiornato
  // e la ricompensa veniva accreditata due volte
  const [dataLoaded, setDataLoaded] = useState(false);
  
  const [gameState, setGameState] = useState<GameState>({
    phase: 'title',
    team: [],
    items: deepClone(defaultItems),
    candies: 50,
    cursedCoins: 0,
    medals: [],
    currentWave: 1,
    map: [],
    currentNode: -1,
    battleEnemies: [],
    activeEnemyIndex: 0,
    battleCatchable: false,
    battleLog: [],
    selectedMonsterIndex: 0,
    isPlayerTurn: true,
    battleOver: false,
    battleWon: false,
    healsUsed: 0,
    showAdModal: false,
    adType: null,
    adsToWatch: 0,
    adsWatched: 0,
    persistentData: getDefaultPersistentData(),
  });

  // Salvataggio con debounce: raggruppa piu' modifiche ravvicinate in una sola
  // scrittura (meno lavoro su localStorage e sullo storage di Playgama).
  const pendingSaveRef = useRef<PersistentData | null>(null);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flushSave = () => {
    if (saveTimerRef.current) { clearTimeout(saveTimerRef.current); saveTimerRef.current = null; }
    if (pendingSaveRef.current) {
      savePersistentData(pendingSaveRef.current);
      pendingSaveRef.current = null;
    }
  };
  useEffect(() => {
    if (dataLoaded) {
      pendingSaveRef.current = persistentData;
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      saveTimerRef.current = setTimeout(flushSave, 800);
    }
    setGameState(prev => ({ ...prev, persistentData }));
  }, [persistentData, dataLoaded]);
  // Salva subito quando la scheda viene nascosta/chiusa (nessuna perdita di progressi)
  useEffect(() => {
    const onHide = () => { if (document.hidden) flushSave(); };
    const onUnload = () => flushSave();
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', onUnload);
    window.addEventListener('beforeunload', onUnload);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', onUnload);
      window.removeEventListener('beforeunload', onUnload);
      flushSave();
    };
  }, []);

  // Ref sempre aggiornato allo stato: evita letture stale nelle callback
  // schedulate con setTimeout (es. executePlayerAttack dopo il turno nemico)
  const gameStateRef = useRef(gameState);
  useEffect(() => {
    gameStateRef.current = gameState;
  }, [gameState]);

  // Frequenza interstitial: istante dell'ultima pubblicità mostrata e avvio gioco
  const lastInterstitialRef = useRef(0);
  const gameStartRef = useRef(Date.now());

  // Auto-scroll del log di battaglia verso l'ultimo messaggio
  const battleLogRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (battleLogRef.current) {
      battleLogRef.current.scrollTop = battleLogRef.current.scrollHeight;
    }
  }, [gameState.battleLog]);

  // Interstitial al game over (pausa naturale consigliata da Playgama),
  // rispettando il delay minimo tra pubblicità
  useEffect(() => {
    if (gameState.phase !== 'game_over') return;
    const now = Date.now();
    if (
      now - lastInterstitialRef.current >= 60000 &&
      now - gameStartRef.current >= 30000
    ) {
      lastInterstitialRef.current = now;
      showInterstitialAd().catch(() => {});
    }
  }, [gameState.phase]);

  // Initialize Playgama SDK and set platform language
  useEffect(() => {
    const initGame = async () => {
      // Initialize Playgama SDK
      await initializePlaygama();
      
      // Load saved language preference from Playgama storage
      const savedLang = await loadData<Language | null>('halloween_monsters_lang', null);
      
      if (savedLang) {
        // User has previously chosen a language, use it
        setLang(savedLang);
      } else {
        // No saved preference, always default to English
        setLang('en');
      }
      
      // Load data from Playgama storage (async)
      const data = await loadData<PersistentData>('halloween_monsters_persistent', getDefaultPersistentData());
      // Anche un salvataggio senza run completate può contenere monete,
      // potenziamenti o sfide: non scartarlo in base a totalRuns.
      setPersistentData(migratePersistentData(data));
      
      // Da questo momento gli effetti giornalieri possono partire
      setDataLoaded(true);
      
      // Setup pause/resume handlers
      onPause(() => {
        console.log('[Game] Paused');
      });
      
      onResume(() => {
        console.log('[Game] Resumed');
      });
      
      // Wait for next frame to ensure game is fully rendered
      await new Promise(resolve => requestAnimationFrame(resolve));
      
      // Report gameplay start
      reportGameplayStart();
      
      // Send game_ready message to platform
      if (typeof window !== 'undefined' && window.bridge?.platform?.sendMessage) {
        window.bridge.platform.sendMessage('game_ready');
        console.log('[Playgama] game_ready message sent');
      }
    };
    
    initGame().catch(() => setDataLoaded(true));
    
    return () => {
      reportGameplayStop();
    };
  }, []);

  // Login giornaliero e inizializzazione obiettivi
  useEffect(() => {
    if (!dataLoaded) return;
    const today = getDailyPeriodKey();
    const thisWeek = getWeeklyPeriodKey();
    const thisMonth = getMonthlyPeriodKey();
    
    // Inizializza achievements se vuoti
    if (persistentData.achievements.length === 0) {
      setPersistentData(prev => ({
        ...prev,
        achievements: initializeAchievements(),
      }));
    }
    
    // Inizializza o rinnova le tre serie di sfide nel rispettivo periodo.
    setPersistentData(prev => ({
      ...prev,
      ...(prev.dailyObjectivesDate !== today
        ? { dailyObjectives: generateDailyObjectives(), dailyObjectivesDate: today }
        : {}),
      ...(prev.weeklyObjectivesWeek !== thisWeek
        ? { weeklyObjectives: generateWeeklyObjectives(), weeklyObjectivesWeek: thisWeek }
        : {}),
      ...(prev.monthlyObjectivesMonth !== thisMonth
        ? { monthlyObjectives: generateMonthlyObjectives(), monthlyObjectivesMonth: thisMonth }
        : {}),
    }));
    
    // Controlla login giornaliero
    if (persistentData.lastLoginDate !== today) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const isConsecutive = persistentData.lastLoginDate === yesterday.toDateString();
      
      const newStreak = isConsecutive ? persistentData.loginStreak + 1 : 1;
      const loginReward = getLoginReward(newStreak);
      
      setPersistentData(prev => ({
        ...prev,
        lastLoginDate: today,
        loginStreak: newStreak,
        cursedCoins: prev.cursedCoins + loginReward,
      }));
      
      // Mostra notifica ricompensa login
      setTimeout(() => {
        showToast(t('alert.login_daily', lang).replace('{streak}', String(newStreak)).replace('{reward}', String(loginReward)));
      }, 500);
    }
  }, [dataLoaded]);

  // Rinnova le sfide se il gioco resta aperto oltre il cambio di giorno,
  // settimana o mese, e quando il giocatore torna alla scheda.
  useEffect(() => {
    if (!dataLoaded) return;
    const refreshPeriods = () => {
      const today = getDailyPeriodKey();
      const thisWeek = getWeeklyPeriodKey();
      const thisMonth = getMonthlyPeriodKey();
      setPersistentData(prev => {
        if (
          prev.dailyObjectivesDate === today &&
          prev.weeklyObjectivesWeek === thisWeek &&
          prev.monthlyObjectivesMonth === thisMonth
        ) return prev;
        return {
          ...prev,
          ...(prev.dailyObjectivesDate !== today
            ? { dailyObjectives: generateDailyObjectives(), dailyObjectivesDate: today }
            : {}),
          ...(prev.weeklyObjectivesWeek !== thisWeek
            ? { weeklyObjectives: generateWeeklyObjectives(), weeklyObjectivesWeek: thisWeek }
            : {}),
          ...(prev.monthlyObjectivesMonth !== thisMonth
            ? { monthlyObjectives: generateMonthlyObjectives(), monthlyObjectivesMonth: thisMonth }
            : {}),
        };
      });
    };
    const onFocus = () => refreshPeriods();
    const timer = setInterval(refreshPeriods, 60_000);
    window.addEventListener('focus', onFocus);
    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', onFocus);
    };
  }, [dataLoaded]);

  // Tracking tempo di gioco
  useEffect(() => {
    // Prima ogni secondo: ogni tick ridisegnava tutta l'app e riscriveva il
    // salvataggio (localStorage + Playgama). Ora accumula a blocchi di 10s e
    // solo mentre la pagina e' visibile.
    const TICK_S = 10;
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setPersistentData(prev => ({
        ...prev,
        totalPlayTime: prev.totalPlayTime + TICK_S,
      }));
    }, TICK_S * 1000);
    return () => clearInterval(interval);
  }, []);

  const purchaseUpgrade = (upgradeId: string) => {
    // Controlla costo, requisiti e livello sullo stato più recente: evita
    // acquisti doppi e saldo negativo se il giocatore clicca rapidamente.
    setPersistentData(prev => {
      const upgrade = prev.upgrades.find(u => u.id === upgradeId);
      if (!upgrade || !canPurchaseUpgrade(upgrade, prev.upgrades, prev.cursedCoins)) return prev;
      const cost = getUpgradeCost(upgrade);
      return {
        ...prev,
        cursedCoins: prev.cursedCoins - cost,
        upgrades: prev.upgrades.map(u => u.id === upgradeId
          ? { ...u, currentLevel: u.maxLevel ? (u.currentLevel || 0) + 1 : u.currentLevel, purchased: true }
          : u),
      };
    });
  };

  const addCursedCoins = (amount: number) => {
    setPersistentData(prev => ({
      ...prev,
      cursedCoins: prev.cursedCoins + amount,
    }));
  };

  const updateChallengeProgress = (trackId: string, amount = 1, mode: 'add' | 'max' = 'add') => {
    const today = getDailyPeriodKey();
    const thisWeek = getWeeklyPeriodKey();
    const thisMonth = getMonthlyPeriodKey();
    setPersistentData(prev => {
      const daily = prev.dailyObjectivesDate === today
        ? prev.dailyObjectives
        : generateDailyObjectives();
      const weekly = prev.weeklyObjectivesWeek === thisWeek
        ? prev.weeklyObjectives
        : generateWeeklyObjectives();
      const monthly = prev.monthlyObjectivesMonth === thisMonth
        ? prev.monthlyObjectives
        : generateMonthlyObjectives();
      return {
        ...prev,
        dailyObjectives: advanceObjectives(daily, trackId, amount, mode),
        dailyObjectivesDate: today,
        weeklyObjectives: advanceObjectives(weekly, trackId, amount, mode),
        weeklyObjectivesWeek: thisWeek,
        monthlyObjectives: advanceObjectives(monthly, trackId, amount, mode),
        monthlyObjectivesMonth: thisMonth,
      };
    });
  };

  // Gli obiettivi di ondata misurano il record raggiunto, non sommano il
  // numero dell'ondata a ogni passaggio.
  const objectiveTrackIds: Record<string, string> = {
    defeat_5_monsters: 'defeat_monster',
    catch_2_monsters: 'catch_monster',
    win_3_battles: 'win_battle',
    use_10_moves: 'use_move',
    reach_wave_5: 'reach_wave',
  };

  const updateDailyObjective = (objectiveId: string, increment = 1) => {
    updateChallengeProgress(
      objectiveTrackIds[objectiveId] || objectiveId,
      increment,
      objectiveId === 'reach_wave_5' ? 'max' : 'add',
    );
  };

  const claimChallengeReward = (period: ChallengePeriod, objectiveId: string) => {
    const periodKey = period === 'daily'
      ? getDailyPeriodKey()
      : period === 'weekly'
        ? getWeeklyPeriodKey()
        : getMonthlyPeriodKey();
    setPersistentData(prev => {
      const objectives = period === 'daily'
        ? prev.dailyObjectives
        : period === 'weekly'
          ? prev.weeklyObjectives
          : prev.monthlyObjectives;
      const savedPeriodKey = period === 'daily'
        ? prev.dailyObjectivesDate
        : period === 'weekly'
          ? prev.weeklyObjectivesWeek
          : prev.monthlyObjectivesMonth;
      const objective = objectives.find(item => item.id === objectiveId);
      if (savedPeriodKey !== periodKey || !objective?.completed || objective.claimed) return prev;
      const updated = objectives.map(item => item.id === objectiveId ? { ...item, claimed: true } : item);
      return {
        ...prev,
        ...(period === 'daily'
          ? { dailyObjectives: updated }
          : period === 'weekly'
            ? { weeklyObjectives: updated }
            : { monthlyObjectives: updated }),
        cursedCoins: prev.cursedCoins + objective.reward,
      };
    });
  };

  const claimDailyObjectiveReward = (objectiveId: string) => {
    claimChallengeReward('daily', objectiveId);
  };

  // Controlla e sblocca achievement
  const checkAndUnlockAchievements = () => {
    setPersistentData(prev => {
      const stats = {
        totalRuns: prev.totalRuns,
        totalWins: prev.totalWins,
        bestWave: prev.bestWave,
        totalMonstersDefeated: prev.totalMonstersDefeated,
        totalMonstersCaught: prev.totalMonstersCaught,
        totalGymLeadersDefeated: prev.totalGymLeadersDefeated,
        longestWinStreak: prev.longestWinStreak,
      };
      
      const { newAchievements, updatedAchievements } = checkAchievements(prev.achievements, stats);
      
      if (newAchievements.length > 0) {
        // Segna come non riscossi
        const achievementsWithClaimed = updatedAchievements.map(ach => {
          if (newAchievements.includes(ach.id)) {
            return { ...ach, claimed: false };
          }
          return ach;
        });
        
        return {
          ...prev,
          achievements: achievementsWithClaimed,
        };
      }
      
      return {
        ...prev,
        achievements: updatedAchievements,
      };
    });
  };

  // Riscuoti ricompensa achievement
  const claimAchievementReward = (achievementId: string) => {
    setPersistentData(prev => {
      const achievement = prev.achievements.find(a => a.id === achievementId);
      if (!achievement?.unlocked || achievement.claimed) return prev;
      return {
        ...prev,
        achievements: prev.achievements.map(ach => ach.id === achievementId ? { ...ach, claimed: true } : ach),
        cursedCoins: prev.cursedCoins + achievement.reward,
      };
    });
  };

  const [challengeTab, setChallengeTab] = useState<ChallengePeriod>('daily');
  const [showMoveSelect, setShowMoveSelect] = useState(false);
  const [showItemSelect, setShowItemSelect] = useState(false);
  // Pozione della Non-Morte: protezione da un KO, una volta per battaglia
  const [undeathProtection, setUndeathProtection] = useState(false);
  const [amuletReviveUsed, setAmuletReviveUsed] = useState(false);
  const [showTeamSelect, setShowTeamSelect] = useState(false);
  const [catchAnimation, setCatchAnimation] = useState(false);
  const [weather, setWeather] = useState<Weather>('normale');
  const [showMoveChoice, setShowMoveChoice] = useState(false);
  const [pendingNewMove, setPendingNewMove] = useState<typeof allMoves[0] | null>(null);
  const [showPPMoveSelect, setShowPPMoveSelect] = useState(false);
  const [forceMonsterSelect, setForceMonsterSelect] = useState(false);
  const [selectedStarters, setSelectedStarters] = useState<Monster[]>([]);
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);
  const [showTeamOrder, setShowTeamOrder] = useState(false);
  
  // Settings states
  const [battleEffects, setBattleEffects] = useState(true);
  const [screenShakeEnabled, setScreenShakeEnabled] = useState(true);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  
  // Battle animation states
  const [playerAnimation, setPlayerAnimation] = useState<'idle' | 'attack' | 'hit' | 'death' | 'special' | 'heal' | 'status'>('idle');
  const [enemyAnimation, setEnemyAnimation] = useState<'idle' | 'attack' | 'hit' | 'death' | 'special' | 'heal' | 'status'>('idle');
  const [playerMoveType, setPlayerMoveType] = useState<any>(undefined);
  const [enemyMoveType, setEnemyMoveType] = useState<any>(undefined);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const { shake, intensity, triggerShake } = useScreenShake();
  
  // Bug fix: genera le posizioni delle particelle una volta sola per evitare sfarfallio
  const [particles] = useState(() => 
    Array.from({ length: 20 }, () => ({
      left: Math.random() * 100,
      top: Math.random() * 100,
      delay: Math.random() * 5,
      duration: 5 + Math.random() * 10,
    }))
  );

  const addLog = useCallback((msg: string) => {
    setGameState(prev => ({
      ...prev,
      battleLog: [...prev.battleLog.slice(-8), msg],
    }));
  }, []);

  const startNewGame = () => {
    // Seleziona 3 starter casuali dal pool
    const shuffled = [...starters].sort(() => Math.random() - 0.5);
    const randomStarters = shuffled.slice(0, 3);
    setSelectedStarters(randomStarters);
    setGameState(prev => ({ ...prev, phase: 'starter_select' }));
  };

  const selectStarter = (index: number) => {
    if (!selectedStarters[index]) return;
    setAmuletReviveUsed(false);
    const upgrades = persistentData.upgrades;
    const starter = applyMetaBonusesToMonster(deepClone(selectedStarters[index]), upgrades);
    const bonusLevels = getUpgradeLevel(upgrades, 'candy_level_up');
    for (let level = 0; level < bonusLevels; level++) {
      starter.level++;
      starter.stats.maxHp += 3;
      starter.stats.hp += 3;
      starter.stats.attack += 2;
      starter.stats.defense += 1;
      starter.stats.speed += 1;
    }
    const map = generateMap(1);
    // Traccia l'uso del mostro
    setPersistentData(prev => {
      const newMonsterUsage = { ...prev.monsterUsage };
      newMonsterUsage[starter.id] = (newMonsterUsage[starter.id] || 0) + 1;
      const favoriteMonster = Object.entries(newMonsterUsage)
        .sort(([,a]: [string, number], [,b]: [string, number]) => b - a)[0]?.[0] || '';
      return {
        ...prev,
        mostCatchesInRun: 0, // Reset per la nuova run
        monsterUsage: newMonsterUsage,
        favoriteMonster,
      };
    });
    setGameState(prev => ({
      ...prev,
      phase: 'map',
      team: [starter],
      map,
      currentNode: -1,
      currentWave: 1,
      items: applyUpgradesToItems(prev.persistentData.upgrades),
      candies: 50,
      cursedCoins: 0,
      medals: [],
      healsUsed: 0,
      persistentData: prev.persistentData,
    }));
  };

  const startBattle = (nodeType: MapNodeType, nodeId: number) => {
    let enemies: Monster[] = [];
    let catchable = false;
    const wave = gameState.currentWave;
    setUndeathProtection(false); // La Pozione della Non-Morte vale per una sola battaglia
    // Calcola la difficoltà basata sul numero totale di nodi completati
    const totalBattles = (wave - 1) * 10 + nodeId;

    switch (nodeType) {
      case 'wild': {
        const maxLvl = totalBattles <= 2 ? 3 : undefined;
        // 2% chance di incontrare un mostro MITICO dopo wave 30
        if (totalBattles >= 30 && Math.random() < 0.02) {
          enemies = [generateMythicalMonster(totalBattles)];
          addLog(`🌟 ${t('battle.legendary_encounter', lang)}`);
        }
        // 5% chance di incontrare un mostro leggendario dopo wave 20
        else if (totalBattles >= 20 && Math.random() < 0.05) {
          enemies = [generateLegendaryMonster(totalBattles)];
          addLog(`⭐ ${t('battle.legendary_encounter', lang)}`);
        } else if (totalBattles >= 5 && Math.random() < 0.2) {
          enemies = [generateRareMonster(totalBattles)];
          addLog(t('battle.rare_encounter', lang));
        } else if (totalBattles >= 8 && Math.random() < 0.15) {
          // Incontro doppio raro: solo dal nodo 8 in poi (le ondate 1 e 2 hanno sempre 1 solo mostro selvatico)
          enemies = [generateEnemyMonster(totalBattles, maxLvl), generateEnemyMonster(Math.max(1, totalBattles - 1), maxLvl)];
        } else {
          enemies = [generateEnemyMonster(totalBattles, maxLvl)];
        }
        catchable = true;
        break;
      }
      case 'trainer': {
        const teamIdx = Math.min(Math.floor(totalBattles / 3), trainerTeams.length - 1);
        const difficultyTier = Math.floor(totalBattles / 100);
        const levelScale = 0.18 + difficultyTier * 0.025;
        const hpScale = 0.25 + difficultyTier * 0.05;
        enemies = deepClone(trainerTeams[teamIdx]).map(m => ({
          ...m,
          level: m.level + Math.floor(totalBattles * levelScale),
          stats: {
            ...m.stats,
            hp: m.stats.maxHp + Math.floor(totalBattles * hpScale),
            maxHp: m.stats.maxHp + Math.floor(totalBattles * hpScale),
          }
        }));
        catchable = false;
        break;
      }
      case 'gym_leader': {
        const gymIdx = wave - 1;
        enemies = generateGymLeaderMonsters(gymIdx);
        catchable = false;
        break;
      }
      default:
        enemies = [generateEnemyMonster(totalBattles, totalBattles <= 2 ? 3 : undefined)];
        catchable = true;
    }

    // A ogni 10 ondate completate entra in vigore un nuovo livello di
    // difficoltà, valido per selvatici, allenatori e capipalestra.
    const difficultyTier = Math.floor((wave - 1) / 10);
    if (difficultyTier > 0) {
      const milestoneMultiplier = 1 + difficultyTier * 0.04;
      const levelBonus = Math.floor(difficultyTier * 2);
      enemies = enemies.map(enemy => ({
        ...enemy,
        level: enemy.level + levelBonus,
        stats: {
          ...enemy.stats,
          hp: Math.floor(enemy.stats.hp * milestoneMultiplier),
          maxHp: Math.floor(enemy.stats.maxHp * milestoneMultiplier),
          attack: Math.floor(enemy.stats.attack * milestoneMultiplier),
          defense: Math.floor(enemy.stats.defense * milestoneMultiplier),
          speed: Math.floor(enemy.stats.speed * milestoneMultiplier),
        },
      }));
    }

    const newWeather = getRandomWeather();
    setWeather(newWeather);
    const weatherMsg = newWeather !== 'normale' ? ` ${weatherInfo[newWeather].emoji} ${t(`weather.${newWeather}`, lang)}: ${t(`weather.${newWeather === 'luna_piena' ? 'spettro_boost' : newWeather === 'nebbia' ? 'precision_down' : 'buio_spettro_boost'}`, lang)}` : '';

    setGameState(prev => {
      // Trova il primo mostro vivo nella squadra
      const firstAliveIndex = prev.team.findIndex(m => m.stats.hp > 0);
      
      return {
        ...prev,
        phase: 'battle',
        battleEnemies: enemies,
        activeEnemyIndex: 0,
        battleCatchable: catchable,
        battleLog: [`${t('battle.battle_start', lang)} ${enemies.length} ${t(enemies.length > 1 ? 'battle.enemies_plural' : 'battle.enemy', lang)}${weatherMsg}`],
        selectedMonsterIndex: firstAliveIndex !== -1 ? firstAliveIndex : 0,
        isPlayerTurn: true,
        battleOver: false,
        battleWon: false,
      };
    });
    setShowMoveSelect(false);
    setShowItemSelect(false);
    setShowTeamSelect(false);
  };

  const handleNodeClick = (nodeId: number) => {
    const node = gameState.map[nodeId];
    if (node.completed) return;
    if (gameState.currentNode >= 0 && !gameState.map[gameState.currentNode].connections.includes(nodeId)) return;
    if (gameState.currentNode < 0 && nodeId !== 0) return;

    setGameState(prev => ({ ...prev, currentNode: nodeId }));

    if (node.type === 'shop') {
      setGameState(prev => ({ ...prev, phase: 'shop' }));
    } else if (node.type === 'event') {
      handleRandomEvent();
    } else {
      startBattle(node.type, nodeId);
    }
  };

  const handleRandomEvent = () => {
    const events = [
      // Eventi positivi - Ricompense
      { msg: `🎃 ${t('event.found_pumpkin', lang)}`, action: () => setGameState(prev => ({ ...prev, candies: prev.candies + 20 })) },
      { msg: `🧪 ${t('event.found_potion', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const pot = items.find(i => i.id === 'pozione_sangue');
        if (pot) pot.quantity += 2;
        return { ...prev, items };
      })},
      { msg: `🍬 ${t('event.found_candies', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const candy = items.find(i => i.id === 'caramella_stregata');
        if (candy) candy.quantity += 3;
        return { ...prev, items };
      })},
      { msg: `✨ ${t('event.ghost_heal', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ ...m, stats: { ...m.stats, hp: m.stats.maxHp }, status: [], sleepTurns: undefined }))
      }))},
      { msg: `💎 ${t('event.found_crystal', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const crystal = items.find(i => i.id === 'cristallo_pp');
        if (crystal) crystal.quantity += 1;
        return { ...prev, items };
      })},
      { msg: `💰 ${t('event.found_coins', lang)}`, action: () => setGameState(prev => ({ ...prev, candies: prev.candies + 35 })) },
      { msg: `⚰️ ${t('event.found_coffin', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const coffin = items.find(i => i.id === 'bara_antica');
        if (coffin) coffin.quantity += 1;
        return { ...prev, items };
      })},
      { msg: `🕯️ ${t('event.found_candle', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const candle = items.find(i => i.id === 'candela_protettiva');
        if (candle) candle.quantity += 2;
        return { ...prev, items };
      })},
      { msg: `🌙 ${t('event.moon_blessing', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ ...m, stats: { ...m.stats, hp: Math.min(m.stats.maxHp, m.stats.hp + 30) } }))
      }))},
      { msg: `🎁 ${t('event.mystery_gift', lang)}`, action: () => setGameState(prev => ({ ...prev, candies: prev.candies + 50 })) },
      // Eventi negativi - Penalità
      { msg: `💀 ${t('event.shadow_attack', lang)}`, action: () => setGameState(prev => ({ ...prev, candies: Math.max(0, prev.candies - 10) })) },
      { msg: `🌑 ${t('event.dark_curse', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ 
          ...m, 
          status: m.status.includes('maledetto') ? m.status : [...m.status, 'maledetto'] as StatusEffect[] 
        }))
      }))},
      { msg: `☠️ ${t('event.poison_trap', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ ...m, stats: { ...m.stats, hp: Math.max(1, m.stats.hp - 15) } }))
      }))},
      { msg: `👻 ${t('event.ghost_robber', lang)}`, action: () => setGameState(prev => ({ ...prev, candies: Math.max(0, prev.candies - 20) })) },
      { msg: `🕸️ ${t('event.spider_web', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ 
          ...m, 
          status: m.status.includes('paralizzato') ? m.status : [...m.status, 'paralizzato'] as StatusEffect[] 
        }))
      }))},
      // Eventi misti - Effetti vari
      { msg: `🔮 ${t('event.mysterious_orb', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const elixir = items.find(i => i.id === 'elisir_spettrale');
        if (elixir) elixir.quantity += 1;
        return { ...prev, items, candies: Math.max(0, prev.candies - 10) };
      })},
      { msg: `⚡ ${t('event.energy_surge', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ ...m, moves: m.moves.map(mv => ({ ...mv, pp: Math.min(mv.maxPp, mv.pp + 5) })) }))
      }))},
      { msg: `🌟 ${t('event.lucky_star', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        candies: prev.candies + 25,
        team: prev.team.map(m => ({ ...m, stats: { ...m.stats, hp: Math.min(m.stats.maxHp, m.stats.hp + 20) } }))
      }))},
      { msg: `🎭 ${t('event.trick_treat', lang)}`, action: () => setGameState(prev => {
        if (Math.random() > 0.5) {
          return { ...prev, candies: prev.candies + 30 };
        } else {
          return { ...prev, candies: Math.max(0, prev.candies - 15) };
        }
      })},
      { msg: `🦇 ${t('event.bat_swarm', lang)}`, action: () => setGameState(prev => ({
        ...prev,
        team: prev.team.map(m => ({ ...m, stats: { ...m.stats, hp: Math.max(1, m.stats.hp - 10) } }))
      }))},
      { msg: `🕷️ ${t('event.spider_nest', lang)}`, action: () => setGameState(prev => {
        const items = deepClone(prev.items);
        const web = items.find(i => i.id === 'rete_becchino');
        if (web) web.quantity += 1;
        return { ...prev, items };
      })},
      { msg: `💀 ${t('event.ancient_tomb', lang)}`, action: () => setGameState(prev => ({ ...prev, candies: prev.candies + 40 })) },
    ];
    const event = events[Math.floor(Math.random() * events.length)];
    event.action();
    setGameState(prev => ({ ...prev, phase: 'event', battleLog: [event.msg] }));
  };

  const attemptAutomaticNetCapture = (): boolean => {
    const current = gameStateRef.current;
    const target = current.battleEnemies[current.activeEnemyIndex];
    if (
      current.battleOver ||
      !current.battleCatchable ||
      current.team.length >= 6 ||
      !hasUpgrade(current.persistentData.upgrades, 'gravedigger_net') ||
      !target ||
      target.stats.hp <= 0 ||
      target.stats.hp / target.stats.maxHp > 0.1
    ) return false;
    tryCapture('rete_becchino', true);
    return true;
  };

  const useMove = (moveIndex: number) => {
    if (!gameState.isPlayerTurn || gameState.battleOver) return;
    
    const attacker = gameState.team?.[gameState.selectedMonsterIndex];
    if (!attacker || attacker.stats.hp <= 0) {
      addLog(`❌ ${t('battle.no_active_monster', lang)}`);
      return;
    }
    
    const move = attacker.moves?.[moveIndex];
    if (!move) {
      addLog(t('battle.invalid_move', lang));
      return;
    }
    
    if (move.pp <= 0) {
      addLog(`❌ ${tMove(move.id, lang)} ${t('battle.no_pp', lang)}`);
      return;
    }

    const targetIdx = gameState.activeEnemyIndex;
    const target = gameState.battleEnemies?.[targetIdx];
    
    if (!target || target.stats.hp <= 0) {
      addLog(`❌ ${t('battle.no_active_enemy', lang)}`);
      return;
    }

    // Controllo status del giocatore: sonnambulo
    if (attacker.status.includes('sonnambulo')) {
      // Controlla se si sveglia (20% di chance per turno)
      const wakeUpChance = Math.random() * 100;
      const sleepTurns = attacker.sleepTurns || 1;
      
      if (wakeUpChance < 20 || sleepTurns <= 1) {
        // Si sveglia!
        addLog(`😴 ${tMonster(attacker.id, lang)} ${t('battle.woke_up', lang)}`);
        setGameState(prev => {
          const team = deepClone(prev.team);
          team[prev.selectedMonsterIndex].status = team[prev.selectedMonsterIndex].status.filter(s => s !== 'sonnambulo');
          team[prev.selectedMonsterIndex].sleepTurns = undefined;
          return { ...prev, team };
        });
      } else {
        // Continua a dormire
        const newSleepTurns = sleepTurns - 1;
        addLog(`😴 ${tMonster(attacker.id, lang)} ${t('battle.sleeping', lang)} (${newSleepTurns} ${t('battle.turns_remaining', lang)})`);
        setGameState(prev => {
          const team = deepClone(prev.team);
          team[prev.selectedMonsterIndex].sleepTurns = newSleepTurns;
          return { ...prev, team, isPlayerTurn: false };
        });
        setTimeout(() => enemyTurn(), 800);
        return;
      }
    }

    // Controllo status del giocatore: paralizzato
    if (attacker.status.includes('paralizzato') && Math.random() > 0.6) {
      addLog(`⚡ ${tMonster(attacker.id, lang)} ${t('battle.paralyzed', lang)}`);
      setGameState(prev => ({ ...prev, isPlayerTurn: false }));
      setTimeout(() => enemyTurn(), 800);
      return;
    }

// Abilità con rigenerazione a inizio turno (Flusso Vitale, Radici Oscure, ...)
    const turnRegen = getTurnRegen(attacker.ability, attacker.stats.hp, attacker.stats.maxHp);
    if (turnRegen > 0) {
      setGameState(prev => {
        const team = deepClone(prev.team);
        const mon = team[prev.selectedMonsterIndex];
        mon.stats.hp = Math.min(mon.stats.maxHp, mon.stats.hp + turnRegen);
        return { ...prev, team };
      });
      addLog(`💧 ${tMonster(attacker.id, lang)} ${t('battle.recovers_hp', lang)} ${turnRegen} HP ${t('battle.with_ability', lang)} ${tAbilityName(attacker.ability, lang)}!`);
    }

    // Determina l'ordine di attacco basato sulla velocità
    // Status spaventato riduce la velocità del 10%
    let playerSpeed = attacker.stats.speed;
    if (attacker.status.includes('spaventato')) {
      playerSpeed = Math.floor(playerSpeed * 0.9);
    }
    
    let enemySpeed = target.stats.speed;
    if (target.status.includes('spaventato')) {
      enemySpeed = Math.floor(enemySpeed * 0.9);
    }
    
    const playerFirst = playerSpeed >= enemySpeed;

    if (playerFirst) {
      // Giocatore attacca per primo
      if (playerSpeed > enemySpeed) {
        addLog(`💨 ${tMonster(attacker.id, lang)} ${t('battle.is_faster', lang)}`);
      }
      setGameState(prev => ({ ...prev, isPlayerTurn: false }));
      executePlayerAttack(moveIndex);
      
      // Verifica se il nemico è stato ucciso prima di dare il turno al nemico
      setTimeout(() => {
        // Legge lo stato aggiornato dal ref (niente effetti dentro setState)
        const cur = gameStateRef.current;
        if (cur.battleOver) return;
        if (attemptAutomaticNetCapture()) return;
        // Se il turno è già del giocatore, non fare nulla
        if (cur.isPlayerTurn) return;
        // Altrimenti, il nemico attacca
        enemyTurn();
      }, 1000);
    } else {
      // Nemico attacca per primo
      addLog(`💨 ${tMonster(target.id, lang)} ${t('battle.is_faster', lang)}`);
      setGameState(prev => ({ ...prev, isPlayerTurn: false }));
      enemyTurn();
      setTimeout(() => {
        // Legge lo stato aggiornato dal ref (niente effetti dentro setState)
        if (!gameStateRef.current.battleOver) {
          // Esegui l'attacco del giocatore
          executePlayerAttack(moveIndex);
          // Dopo l'attacco del giocatore, verifica se il nemico è stato ucciso
          setTimeout(() => {
              if (attemptAutomaticNetCapture()) return;
            setGameState(p => {
              // Se la battaglia è finita o il turno è già del giocatore, non fare nulla
              if (p.battleOver || p.isPlayerTurn) {
                return p;
              }
              // Altrimenti, dai il turno al giocatore
              return { ...p, isPlayerTurn: true };
            });
          }, 1000);
        }
      }, 1000);
    }
  };

  const executePlayerAttack = (moveIndex: number) => {
    // Usa il ref: questa funzione viene spesso invocata via setTimeout dopo
    // il turno nemico, quindi la closure su gameState sarebbe stale
    const currentState = gameStateRef.current;
    const attacker = currentState.team[currentState.selectedMonsterIndex];
    
    // Bug fix: controlla se attacker e move sono validi
    if (!attacker || !attacker.moves || !attacker.moves[moveIndex]) {
      console.error('Invalid attacker or move in executePlayerAttack');
      return;
    }

    // Bug fix: un mostro esausto (0 HP) non può attaccare (es. nemico più veloce ha agito prima)
    if (attacker.stats.hp <= 0) {
      return;
    }
    
    const move = attacker.moves[moveIndex];
    const targetIdx = currentState.activeEnemyIndex;
    const target = currentState.battleEnemies[targetIdx];
    
    // Bug fix: controlla se target è valido
    if (!target) {
      console.error('Invalid target in executePlayerAttack');
      return;
    }

    // Aggiorna obiettivo "usa 10 mosse"
    updateDailyObjective('use_10_moves');

    // Effetto status "bruciato" per il giocatore: danno per turno
    if (attacker.status.includes('bruciato')) {
      const burnDamage = Math.floor(attacker.stats.maxHp * 0.05);
      const currentHp = attacker.stats.hp - burnDamage;
      
      addLog(`🔥 ${tMonster(attacker.id, lang)} ${t('battle.suffers_burn', lang)} ${burnDamage} ${t('battle.damage', lang)}`);
      
      if (currentHp <= 0) {
        // Bug fix: anche la sconfitta per bruciatura aggiorna le statistiche
        setPersistentData(prev => ({
          ...prev,
          totalRuns: prev.totalRuns + 1,
          bestWave: Math.max(prev.bestWave, gameState.currentWave),
          totalLosses: prev.totalLosses + 1,
          totalBattles: prev.totalBattles + 1,
          bestRunWave: Math.max(prev.bestRunWave || 0, gameState.currentWave),
          currentWinStreak: 0,
        }));
        setTimeout(() => checkAndUnlockAchievements(), 500);
        setGameState(prev => {
          const team = deepClone(prev.team);
          team[prev.selectedMonsterIndex].stats.hp = 0;
          const aliveMonsters = team.filter(m => m.stats.hp > 0);
          if (aliveMonsters.length === 0) {
            return { ...prev, team, battleOver: true, battleWon: false, phase: 'game_over' as GamePhase };
          } else {
            addLog(`🔄 ${t('battle.chooses_another', lang)}`);
            setForceMonsterSelect(true);
            return { ...prev, team, isPlayerTurn: true };
          }
        });
        return; // Ferma l'esecuzione dell'attacco
      } else {
        setGameState(prev => {
          const team = deepClone(prev.team);
          team[prev.selectedMonsterIndex].stats.hp = currentHp;
          return { ...prev, team };
        });
      }
    }
    
    // Effetto status "putrefatto" per il giocatore: danno per turno
    if (attacker.status.includes('putrefatto')) {
      const poisonDamage = Math.floor(attacker.stats.maxHp * 0.06);
      const currentMonster = currentState.team[currentState.selectedMonsterIndex];
      const currentHp = currentMonster.stats.hp - poisonDamage;
      
      addLog(`☠️ ${tMonster(attacker.id, lang)} ${t('battle.suffers', lang)} ${poisonDamage} ${t('battle.damage_putrefaction', lang)}`);
      
      if (currentHp <= 0) {
        // Bug fix: anche la sconfitta per putrefazione aggiorna le statistiche
        setPersistentData(prev => ({
          ...prev,
          totalRuns: prev.totalRuns + 1,
          bestWave: Math.max(prev.bestWave, gameState.currentWave),
          totalLosses: prev.totalLosses + 1,
          totalBattles: prev.totalBattles + 1,
          bestRunWave: Math.max(prev.bestRunWave || 0, gameState.currentWave),
          currentWinStreak: 0,
        }));
        setTimeout(() => checkAndUnlockAchievements(), 500);
        setGameState(prev => {
          const team = deepClone(prev.team);
          team[prev.selectedMonsterIndex].stats.hp = 0;
          const aliveMonsters = team.filter(m => m.stats.hp > 0);
          if (aliveMonsters.length === 0) {
            return { ...prev, team, battleOver: true, battleWon: false, phase: 'game_over' as GamePhase };
          } else {
            addLog(`🔄 ${t('battle.chooses_another', lang)}`);
            setForceMonsterSelect(true);
            return { ...prev, team, isPlayerTurn: true };
          }
        });
        return; // Ferma l'esecuzione dell'attacco
      } else {
        setGameState(prev => {
          const team = deepClone(prev.team);
          team[prev.selectedMonsterIndex].stats.hp = currentHp;
          return { ...prev, team };
        });
      }
    }

    // Effetto status "maledetto" per il giocatore: riduce attacco del 20%
    let attackMod = 0;
    if (attacker.status.includes('maledetto')) {
      attackMod = -0.2;
    }

    setGameState(prev => {
      const team = deepClone(prev.team);
      team[prev.selectedMonsterIndex].moves[moveIndex].pp--;
      return { ...prev, team };
    });

    const hitRoll = Math.random() * 100;
    // Inchiostro Nero del bersaglio riduce la precisione di chi lo attacca
    const targetAccMod = getAttackerAccuracyMod(target.ability);
    if (hitRoll > (move.accuracy + targetAccMod)) {
      addLog(`${attacker.emoji} ${tMonster(attacker.id, lang)} ${t('battle.uses', lang)} ${tMove(move.id, lang)}... ${t('battle.miss', lang)}`);
      return;
    }

    // Abilità di schivata del bersaglio (es. Corpo Etereo)
    const targetDodge = getDodgeChance(target.ability);
    if (targetDodge > 0 && Math.random() * 100 < targetDodge) {
      addLog(`👻 ${tMonster(target.id, lang)} ${t('battle.dodge_ethereal', lang)}`);
      return;
    }

    let { damage, effectiveness } = calculateDamage(attacker, target, move);
    
    // Applica modifica attacco da maledizione
    if (attackMod !== 0) {
      damage = Math.floor(damage * (1 + attackMod));
    }
    
    if (weather === 'luna_piena' && move.type === 'spettro') damage = Math.floor(damage * 1.2);
    if (weather === 'notte_halloween' && (move.type === 'buio' || move.type === 'spettro')) damage = Math.floor(damage * 1.2);

    // Bonus danno da abilità dell'attaccante (data-driven)
    const abilMult = getAbilityDamageMultiplier(attacker.ability, move.type, weather);
    if (abilMult !== 1 && damage > 0) {
      const bonus = Math.floor(damage * (abilMult - 1));
      damage += bonus;
      addLog(`✨ ${tAbilityName(attacker.ability, lang)}: +${bonus} ${t('battle.bonus_damage', lang)}!`);
    }
    // Riduzione danno da abilità del difensore (data-driven)
    const defMult = getAbilityDefenseMultiplier(target.ability, move.type, target.stats.hp / target.stats.maxHp);
    if (defMult < 1 && damage > 0) {
      const reduced = damage - Math.floor(damage * defMult);
      damage = Math.floor(damage * defMult);
      addLog(`🛡️ ${tAbilityName(target.ability, lang)}: -${reduced} ${t('battle.damage', lang)}`);
    }
    if (weather === 'nebbia' && Math.random() < 0.15) {
      addLog(`${attacker.emoji} ${tMonster(attacker.id, lang)} ${t('battle.uses', lang)} ${tMove(move.id, lang)}... ${t('battle.fog_distract', lang)}`);
      return;
    }
    
    let effMsg = '';
    if (effectiveness > 1) effMsg = ` ${t('battle.super_effective', lang)}`;
    else if (effectiveness < 1 && effectiveness > 0) effMsg = ` ${t('battle.not_effective', lang)}`;
    else if (effectiveness === 0) effMsg = ` ${t('battle.no_effect', lang)}`;

    // Log diverso per mosse di stato (power = 0) e mosse di attacco
    if (move.power === 0) {
      addLog(`${attacker.emoji} ${tMonster(attacker.id, lang)} ${t('battle.uses', lang)} ${tMove(move.id, lang)}!${effMsg}`);
    } else {
      addLog(`${attacker.emoji} ${tMonster(attacker.id, lang)} ${t('battle.uses', lang)} ${tMove(move.id, lang)}! (-${damage} HP)${effMsg}`);
    }

    // Trigger battle animations
    setPlayerMoveType(move.type);
    if (animationsEnabled) {
      setPlayerAnimation(move.power > 60 ? 'special' : move.power === 0 ? 'status' : 'attack');
    }
    
    // Only trigger screen shake and hit animation for damaging moves
    if (move.power > 0) {
      if (screenShakeEnabled) {
        triggerShake(effectiveness > 1 ? 'heavy' : effectiveness < 1 ? 'light' : 'medium');
      }
      
      // Enemy hit animation after delay
      if (battleEffects) {
        setTimeout(() => {
          setEnemyAnimation('hit');
          setTimeout(() => setEnemyAnimation('idle'), 400);
        }, 300);
      }
    }
    
    // Reset player animation
    if (animationsEnabled) {
      setTimeout(() => setPlayerAnimation('idle'), 600);
    }

    setGameState(prev => {
      const enemies = deepClone(prev.battleEnemies);
      const team = deepClone(prev.team);
      enemies[targetIdx].stats.hp = Math.max(0, enemies[targetIdx].stats.hp - damage);
      
      // Applica abilità passive del giocatore
      const playerMonster = team[prev.selectedMonsterIndex];
      
      // Rubavita: qualsiasi mostro con abilità succhia-vita (es. Succhia Vita)
      const lifestealPct = getLifesteal(playerMonster.ability)
        + (hasUpgrade(currentState.persistentData.upgrades, 'held_item_fang') ? 0.1 : 0);
      if (lifestealPct > 0) {
        const healAmount = Math.floor(damage * lifestealPct);
        if (healAmount > 0 && playerMonster.stats.hp < playerMonster.stats.maxHp) {
          team[prev.selectedMonsterIndex].stats.hp = Math.min(playerMonster.stats.maxHp, playerMonster.stats.hp + healAmount);
          addLog(`🧛 ${tMonster(playerMonster.id, lang)} ${t('battle.recovers_hp', lang)} ${healAmount} HP ${t('battle.with_ability', lang)} ${tAbilityName(playerMonster.ability, lang)}!`);
        }
      }
      
      // Applica effetto status al nemico (probabilità modificata dall'abilità dell'attaccante)
      const playerEffectChance = getModifiedEffectChance(attacker.ability, move.effect, move.effectChance || 0);
      if (move.effect && playerEffectChance > 0 && Math.random() * 100 < playerEffectChance) {
        if (!enemies[targetIdx].status.includes(move.effect)) {
          if (isStatusImmune(enemies[targetIdx].ability, move.effect)) {
            addLog(`✨ ${tMonster(enemies[targetIdx].id, lang)} ${t('battle.immune_to_status', lang)}`);
          } else {
          enemies[targetIdx].status.push(move.effect);
          
          // Se è sonnambulo, imposta la durata (1-6 turni)
          if (move.effect === 'sonnambulo') {
            enemies[targetIdx].sleepTurns = Math.floor(Math.random() * 6) + 1;
            addLog(`💫 ${tMonster(enemies[targetIdx].id, lang)} ${t('battle.is_now', lang)} ${getStatusName(move.effect)}! (${enemies[targetIdx].sleepTurns} ${t('battle.turns', lang)})`);
          } else {
            addLog(`💫 ${tMonster(enemies[targetIdx].id, lang)} ${t('battle.is_now', lang)} ${getStatusName(move.effect)}!`);
          }
          }
        }
      }

      // Status on-hit da abilità dell'attaccante (es. Pozione Mortale, Tela Appiccicosa)
      const onHit = getOnHitStatus(attacker.ability);
      if (onHit && enemies[targetIdx].stats.hp > 0 && Math.random() * 100 < onHit.chance) {
        if (!enemies[targetIdx].status.includes(onHit.status) && !isStatusImmune(enemies[targetIdx].ability, onHit.status)) {
          enemies[targetIdx].status.push(onHit.status);
          addLog(`💫 ${tMonster(enemies[targetIdx].id, lang)} ${t('battle.is_now', lang)} ${getStatusName(onHit.status)}!`);
        }
      }

      // Abilità di sopravvivenza KO (Sentinella Eterna, Sette Vite)
      if (enemies[targetIdx].stats.hp <= 0) {
        const surviveHp = trySurviveKO(enemies[targetIdx].ability, enemies[targetIdx].stats.maxHp, damage);
        if (surviveHp !== null) {
          enemies[targetIdx].stats.hp = surviveHp;
          addLog(`⚰️ ${t('battle.eternal_sentinel', lang)} ${tMonster(enemies[targetIdx].id, lang)} ${t('battle.resists_with', lang)} ${surviveHp} HP!`);
        }
      }
      
      if (enemies[targetIdx].stats.hp <= 0) {
        addLog(`${t('battle.fainted', lang)} ${tMonster(enemies[targetIdx].id, lang)}`);
        
        // Aggiorna statistiche e obiettivi
        updateDailyObjective('defeat_5_monsters');
        setPersistentData(prev => ({
          ...prev,
          totalMonstersDefeated: prev.totalMonstersDefeated + 1,
        }));
        
        // Bug fix: niente shadowing di `team` — la variabile esterna (riga ~1208)
        // contiene già le cure da Rubavita applicate in questo stesso attacco;
        // ri-clonare da prev.team qui le perderebbe.
        const expGain = Math.floor((enemies[targetIdx].level * 5 + 10) * (1 + getUpgradeLevel(persistentData.upgrades, 'fast_growth') * 0.01));
        team[prev.selectedMonsterIndex].exp += expGain;
        grantBenchExperience(team, prev.selectedMonsterIndex, expGain, persistentData.upgrades);
        addLog(`${t('battle.exp_gain', lang).replace('EXP', `${expGain} EXP`)}`);
        
        while (team[prev.selectedMonsterIndex].exp >= team[prev.selectedMonsterIndex].expToNext) {
          team[prev.selectedMonsterIndex].exp -= team[prev.selectedMonsterIndex].expToNext;
          team[prev.selectedMonsterIndex].level++;
          team[prev.selectedMonsterIndex].expToNext = Math.floor(team[prev.selectedMonsterIndex].expToNext * 1.3);
          team[prev.selectedMonsterIndex].stats.maxHp += 3;
          team[prev.selectedMonsterIndex].stats.hp += 3;
          team[prev.selectedMonsterIndex].stats.attack += 2;
          team[prev.selectedMonsterIndex].stats.defense += 1;
          team[prev.selectedMonsterIndex].stats.speed += 1;
          addLog(`${t('battle.level_up', lang)} ${team[prev.selectedMonsterIndex].level}!`);
          
          // Learn new moves at levels 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40
          const newMoveLevels = [7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40];
          if (newMoveLevels.includes(team[prev.selectedMonsterIndex].level)) {
            const mon = team[prev.selectedMonsterIndex];
            
            // 50% chance to learn a move of the same type (STAB), 50% chance for other types
            const learnSTAB = Math.random() < 0.5;
            let availableMoves: typeof allMoves;
            
            if (learnSTAB) {
              // Prefer moves of the same type
              availableMoves = allMoves.filter((m: typeof allMoves[0]) => 
                m.type === mon.type && !mon.moves.find(mm => mm.id === m.id)
              );
            } else {
              // Learn moves of different types for variety
              availableMoves = allMoves.filter((m: typeof allMoves[0]) => 
                m.type !== mon.type && !mon.moves.find(mm => mm.id === m.id)
              );
            }
            
            if (availableMoves.length > 0) {
              const newMove = availableMoves[Math.floor(Math.random() * availableMoves.length)];
              if (mon.moves.length < 4) {
                mon.moves.push(deepClone(newMove));
                addLog(`✨ ${tMonster(mon.id, lang)} ${t('battle.learns', lang)} ${tMove(newMove.id, lang)}!`);
              } else {
                // Show move choice modal
                setPendingNewMove(newMove);
                setShowMoveChoice(true);
                addLog(`✨ ${tMonster(mon.id, lang)} ${t('battle.wants_to_learn', lang)} ${tMove(newMove.id, lang)}!`);
              }
            }
          }
          
          // Evoluzione: controlla solo una volta quando raggiunge il livello esatto
          const mon = team[prev.selectedMonsterIndex];
          const prevLevel = mon.level - 1; // Livello precedente prima del level up
          
          // Sistema di evoluzioni multiple
          if (mon.evolutions && mon.evolutions.length > 0) {
            const nextEvo = mon.evolutions.find(evo => prevLevel < evo.level && mon.level >= evo.level);
            if (nextEvo) {
              mon.name = nextEvo.name;
              mon.emoji = nextEvo.emoji;
              mon.id = nextEvo.id;
              // Aggiorna abilità, tipo, rarità e catena evolutiva dalla forma evoluta
              const evoTemplate = [...starters, ...wildMonsters, ...rareMonsters].find(tpl => tpl.id === nextEvo.id);
              if (evoTemplate) {
                mon.ability = evoTemplate.ability;
                mon.abilityDesc = evoTemplate.abilityDesc;
                mon.type = evoTemplate.type;
                mon.rarity = evoTemplate.rarity;
                mon.tier = evoTemplate.tier;
                mon.evolutions = evoTemplate.evolutions;
              }
              mon.stats.maxHp += 15;
              mon.stats.hp += 15;
              mon.stats.attack += 8;
              mon.stats.defense += 5;
              mon.stats.speed += 4;
              const newMoves = allMoves.filter((m: typeof allMoves[0]) => m.type === mon.type && !mon.moves.find(mm => mm.id === m.id));
              if (newMoves.length > 0) {
                const newMove = newMoves[Math.floor(Math.random() * newMoves.length)];
                if (mon.moves.length < 4) {
                  mon.moves.push(deepClone(newMove));
                  addLog(`✨ ${tMonster(mon.id, lang)} ${t('battle.learns', lang)} ${tMove(newMove.id, lang)}!`);
                } else {
                  // Show move choice modal
                  setPendingNewMove(newMove);
                  setShowMoveChoice(true);
                  addLog(`✨ ${tMonster(mon.id, lang)} ${t('battle.wants_to_learn', lang)} ${tMove(newMove.id, lang)}!`);
                }
              }
              addLog(`${t('battle.evolution', lang)}`);
            }
          }
          // Il vecchio sistema di evoluzione singola (evoData con ID legacy)
          // è stato rimosso: tutti i mostri usano ora l'array evolutions.
        }

        if (enemies.every(e => e.stats.hp <= 0)) {
          const nodeType = gameState.map[gameState.currentNode]?.type || 'wild';
          const isGym = nodeType === 'gym_leader';
          const candyReward = isGym ? 100 : 20 + gameState.currentWave * 5;
          const map = deepClone(prev.map);
          map[prev.currentNode].completed = true;
          const newMedals = isGym ? [...prev.medals, `Medaglia ${prev.medals.length + 1}`] : prev.medals;
          
          // Calcola Monete Maledette
          const noKOs = team.every(m => m.stats.hp > 0);
          const cursedCoinsReward = calculateCursedCoinsReward(nodeType, gameState.currentWave, noKOs, false, isGym && !prev.medals.some(m => m.includes('Medaglia')));
          
          if (cursedCoinsReward > 0) {
            addCursedCoins(cursedCoinsReward);
            addLog(`💰 +${cursedCoinsReward} ${t('battle.cursed_coins_earned', lang)}`);
          }
          
          // Aggiorna obiettivi e statistiche
          updateDailyObjective('win_3_battles');
          if (isGym) updateChallengeProgress('defeat_gym');
          setPersistentData(prev => {
            const newStreak = (prev.currentWinStreak || 0) + 1;
            const newData = {
              ...prev,
              bestWave: Math.max(prev.bestWave, gameState.currentWave),
              totalWins: prev.totalWins + 1,
              totalBattles: prev.totalBattles + 1,
              currentWinStreak: newStreak,
              longestWinStreak: Math.max(prev.longestWinStreak || 0, newStreak),
              bestRunWave: Math.max(prev.bestRunWave || 0, gameState.currentWave),
            };
            
            if (isGym) {
              newData.totalGymLeadersDefeated = prev.totalGymLeadersDefeated + 1;
            }
            
            return newData;
          });
          
          // Controlla achievement dopo la battaglia
          setTimeout(() => checkAndUnlockAchievements(), 1000);
          
          return {
            ...prev,
            battleEnemies: enemies,
            team,
            battleOver: true,
            battleWon: true,
            candies: prev.candies + candyReward,
            medals: newMedals,
            map,
          };
        } else {
          const nextAlive = enemies.findIndex(e => e.stats.hp > 0);
          if (nextAlive !== -1) {
            addLog(`🔄 ${enemies[nextAlive].emoji} ${tMonster(enemies[nextAlive].id, lang)} ${t('battle.enters_field', lang)}`);
            return {
              ...prev,
              battleEnemies: enemies,
              team,
              activeEnemyIndex: nextAlive,
              isPlayerTurn: true, // Il turno torna al giocatore quando un nemico viene sconfitto
            };
          }
        }
      }

      return { ...prev, battleEnemies: enemies, team, isPlayerTurn: false };
    });
  };

  // Bug fix: statistiche/obiettivi/achievement per le vittorie ottenute con
  // danno nel tempo nel turno nemico (prima non venivano conteggiate)
  const applyDoTKillStats = () => {
    updateDailyObjective('defeat_5_monsters');
    setPersistentData(prevData => ({
      ...prevData,
      totalMonstersDefeated: prevData.totalMonstersDefeated + 1,
    }));
  };

  const applyVictoryStats = (isGym: boolean) => {
    updateDailyObjective('win_3_battles');
    if (isGym) updateChallengeProgress('defeat_gym');
    setPersistentData(prevData => {
      const newStreak = (prevData.currentWinStreak || 0) + 1;
      const newData = {
        ...prevData,
        bestWave: Math.max(prevData.bestWave, gameState.currentWave),
        totalWins: prevData.totalWins + 1,
        totalBattles: prevData.totalBattles + 1,
        currentWinStreak: newStreak,
        longestWinStreak: Math.max(prevData.longestWinStreak || 0, newStreak),
        bestRunWave: Math.max(prevData.bestRunWave || 0, gameState.currentWave),
      };
      if (isGym) {
        (newData as any).totalGymLeadersDefeated = prevData.totalGymLeadersDefeated + 1;
      }
      return newData;
    });
    setTimeout(() => checkAndUnlockAchievements(), 1000);
  };

  const enemyTurn = () => {
    setGameState(prev => {
      if (prev.battleOver) return prev;
      
      const enemies = deepClone(prev.battleEnemies);
      const team = deepClone(prev.team);
      const logs: string[] = [];
      
      const activeEnemy = enemies[prev.activeEnemyIndex];

      // Bug fix: se l'indice del nemico attivo non è valido (es. dopo una
      // cattura che ha ridotto l'array), riporta il turno al giocatore
      if (!activeEnemy) {
        const fallback = enemies.findIndex(e => e.stats.hp > 0);
        return {
          ...prev,
          battleEnemies: enemies,
          team,
          activeEnemyIndex: fallback !== -1 ? fallback : 0,
          isPlayerTurn: true,
        };
      }

      if (activeEnemy.stats.hp > 0) {
        if (activeEnemy.status.includes('putrefatto')) {
          const dot = Math.floor(activeEnemy.stats.maxHp * 0.06);
          activeEnemy.stats.hp = Math.max(0, activeEnemy.stats.hp - dot);
          logs.push(`☠️ ${tMonster(activeEnemy.id, lang)} ${t('battle.suffers', lang)} ${dot} ${t('battle.damage_putrefaction', lang)}`);
        }
        
        if (activeEnemy.stats.hp <= 0) {
          logs.push(`${t('battle.fainted', lang)} ${tMonster(activeEnemy.id, lang)}`);
          applyDoTKillStats();
          
          if (enemies.every(e => e.stats.hp <= 0)) {
            const nodeType = gameState.map[gameState.currentNode]?.type || 'wild';
            const isGym = nodeType === 'gym_leader';
            const candyReward = isGym ? 100 : 20 + gameState.currentWave * 5;
            const map = deepClone(prev.map);
            map[prev.currentNode].completed = true;
            const newMedals = isGym ? [...prev.medals, `Medaglia ${prev.medals.length + 1}`] : prev.medals;
            
            // Calcola Monete Maledette
            const noKOs = team.every(m => m.stats.hp > 0);
            const cursedCoinsReward = calculateCursedCoinsReward(nodeType, gameState.currentWave, noKOs, false, isGym && !prev.medals.some(m => m.includes('Medaglia')));
            
            if (cursedCoinsReward > 0) {
              addCursedCoins(cursedCoinsReward);
              logs.push(`💰 +${cursedCoinsReward} ${t('battle.cursed_coins_earned', lang)}`);
            }
            
            applyVictoryStats(isGym);
            return {
              ...prev,
              battleEnemies: enemies,
              team,
              battleOver: true,
              battleWon: true,
              candies: prev.candies + candyReward,
              medals: newMedals,
              map,
              battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
            };
          } else {
            const nextAlive = enemies.findIndex(e => e.stats.hp > 0);
            if (nextAlive !== -1) {
              logs.push(`🔄 ${enemies[nextAlive].emoji} ${tMonster(enemies[nextAlive].id, lang)} ${t('battle.enters_field', lang)}`);
              return {
                ...prev,
                battleEnemies: enemies,
                team,
                activeEnemyIndex: nextAlive,
                battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
                isPlayerTurn: true,
              };
            }
          }
        }
        
        if (activeEnemy.stats.hp > 0 && !activeEnemy.status.includes('sonnambulo') && !(activeEnemy.status.includes('paralizzato') && Math.random() > 0.6)) {
          // Effetto status "bruciato": danno per turno
          if (activeEnemy.status.includes('bruciato')) {
            const burnDamage = Math.floor(activeEnemy.stats.maxHp * 0.05);
            activeEnemy.stats.hp = Math.max(0, activeEnemy.stats.hp - burnDamage);
            logs.push(`🔥 ${tMonster(activeEnemy.id, lang)} ${t('battle.suffers_burn', lang)} ${burnDamage} ${t('battle.damage', lang)}`);
          }
          
          // Se il nemico è morto per il burn, gestisci la transizione
          if (activeEnemy.stats.hp <= 0) {
            logs.push(`${t('battle.fainted', lang)} ${tMonster(activeEnemy.id, lang)}`);
            applyDoTKillStats();
            
            // Controlla se tutti i nemici sono morti
            if (enemies.every(e => e.stats.hp <= 0)) {
              const nodeType = gameState.map[gameState.currentNode]?.type || 'wild';
              const isGym = nodeType === 'gym_leader';
              const candyReward = isGym ? 100 : 20 + gameState.currentWave * 5;
              const map = deepClone(prev.map);
              map[prev.currentNode].completed = true;
              const newMedals = isGym ? [...prev.medals, `Medaglia ${prev.medals.length + 1}`] : prev.medals;
              
              // Calcola Monete Maledette
              const noKOs = team.every(m => m.stats.hp > 0);
              const cursedCoinsReward = calculateCursedCoinsReward(nodeType, gameState.currentWave, noKOs, false, isGym && !prev.medals.some(m => m.includes('Medaglia')));
              
              if (cursedCoinsReward > 0) {
                addCursedCoins(cursedCoinsReward);
                logs.push(`💰 +${cursedCoinsReward} ${t('battle.cursed_coins_earned', lang)}`);
              }
              
              applyVictoryStats(isGym);
              return {
                ...prev,
                battleEnemies: enemies,
                team,
                battleOver: true,
                battleWon: true,
                candies: prev.candies + candyReward,
                medals: newMedals,
                map,
                battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
              };
            } else {
              // Trova il prossimo nemico vivo
              const nextAlive = enemies.findIndex(e => e.stats.hp > 0);
              if (nextAlive !== -1) {
                logs.push(`🔄 ${enemies[nextAlive].emoji} ${tMonster(enemies[nextAlive].id, lang)} ${t('battle.enters_field', lang)}`);
                return {
                  ...prev,
                  battleEnemies: enemies,
                  team,
                  activeEnemyIndex: nextAlive,
                  battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
                  isPlayerTurn: true,
                };
              }
            }
          } else {
          
          // Effetto status "maledetto": riduce attacco
          let attackMod = 0;
          if (activeEnemy.status.includes('maledetto')) {
            attackMod = -0.2; // -20% attacco
          }
          
          const targetIdx = prev.selectedMonsterIndex;
          const target = team[targetIdx];
          
          if (target.stats.hp > 0) {
            // Abilità di schivata del mostro del giocatore (es. Corpo Etereo)
            const targetDodgeChance = getDodgeChance(target.ability);
            if (targetDodgeChance > 0 && Math.random() * 100 < targetDodgeChance) {
              logs.push(`👻 ${tMonster(target.id, lang)} ${t('battle.dodge_ethereal', lang)}`);
            } else {
              const move = activeEnemy.moves[Math.floor(Math.random() * activeEnemy.moves.length)];
              
              // Inchiostro Nero del difensore riduce la precisione dell'attaccante
              const accuracyMod = getAttackerAccuracyMod(target.ability);
              
              const hitRoll = Math.random() * 100;
              if (hitRoll > (move.accuracy + accuracyMod)) {
                logs.push(`${activeEnemy.emoji} ${tMonster(activeEnemy.id, lang)} usa ${tMove(move.id, lang)}... ${t('battle.miss', lang)}`);
              } else {
                let { damage, effectiveness } = calculateDamage(activeEnemy, target, move);
                
                // Applica modifica attacco da maledizione
                if (attackMod !== 0) {
                  damage = Math.floor(damage * (1 + attackMod));
                }
                
                // Riduzioni danno da abilità del mostro del giocatore (data-driven)
                const playerDefMult = getAbilityDefenseMultiplier(target.ability, move.type, target.stats.hp / target.stats.maxHp);
                if (playerDefMult < 1 && damage > 0) {
                  const reducedDamage = damage - Math.floor(damage * playerDefMult);
                  damage = Math.floor(damage * playerDefMult);
                  logs.push(`🛡️ ${tAbilityName(target.ability, lang)}: ${t('battle.damage_reduced', lang)} ${reducedDamage}!`);
                }
                
                if (weather === 'luna_piena' && move.type === 'spettro') damage = Math.floor(damage * 1.2);
                if (weather === 'notte_halloween' && (move.type === 'buio' || move.type === 'spettro')) damage = Math.floor(damage * 1.2);
                if (weather === 'nebbia' && Math.random() < 0.15) {
                  logs.push(`${activeEnemy.emoji} ${tMonster(activeEnemy.id, lang)} prova ${tMove(move.id, lang)}... ${t('battle.fog_distract', lang)}`);
                } else {
                  let effMsg = '';
                  if (effectiveness > 1) effMsg = ` ${t('battle.super_effective', lang)}`;
                  else if (effectiveness < 1 && effectiveness > 0) effMsg = ` ${t('battle.not_effective', lang)}`;

                // Bonus danno da abilita' del nemico (data-driven)
                const enemyAbilMult = getAbilityDamageMultiplier(activeEnemy.ability, move.type, weather);
                if (enemyAbilMult !== 1 && damage > 0) {
                  const bonusDamage = Math.floor(damage * (enemyAbilMult - 1));
                  damage += bonusDamage;
                  logs.push(`✨ ${tAbilityName(activeEnemy.ability, lang)}: +${bonusDamage} ${t('battle.bonus_damage', lang)}!`);
                }
                
                // Log diverso per mosse di stato (power = 0) e mosse di attacco
                if (move.power === 0) {
                  logs.push(`${activeEnemy.emoji} ${tMonster(activeEnemy.id, lang)} ${t('battle.uses', lang)} ${tMove(move.id, lang)}!${effMsg}`);
                } else {
                  logs.push(`${activeEnemy.emoji} ${tMonster(activeEnemy.id, lang)} ${t('battle.uses', lang)} ${tMove(move.id, lang)}! (-${damage} HP)${effMsg}`);
                }
                team[targetIdx].stats.hp = Math.max(0, team[targetIdx].stats.hp - damage);
                
                // Abilità di sopravvivenza KO del giocatore + Pozione della Non-Morte
                if (team[targetIdx].stats.hp <= 0) {
                  const surviveHp = trySurviveKO(team[targetIdx].ability, team[targetIdx].stats.maxHp, damage);
                  if (surviveHp !== null) {
                    team[targetIdx].stats.hp = surviveHp;
                    logs.push(`⚰️ ${t('battle.eternal_sentinel', lang)} ${tMonster(team[targetIdx].id, lang)} ${t('battle.resists_with', lang)} ${surviveHp} HP!`);
                  } else if (undeathProtection) {
                    team[targetIdx].stats.hp = Math.max(1, Math.floor(team[targetIdx].stats.maxHp * 0.25));
                    logs.push(`💀 ${tItem('pozione_non_morte', lang)}: ${tMonster(team[targetIdx].id, lang)} ${t('battle.resists_with', lang)} ${team[targetIdx].stats.hp} HP!`);
                    setUndeathProtection(false);
                  }
                }
                
                // Trigger enemy attack animations
                setEnemyMoveType(move.type);
                if (animationsEnabled) {
                  setEnemyAnimation(move.power > 60 ? 'special' : move.power === 0 ? 'status' : 'attack');
                }
                
                // Only trigger screen shake and hit animation for damaging moves
                if (move.power > 0) {
                  if (screenShakeEnabled) {
                    triggerShake(effectiveness > 1 ? 'heavy' : effectiveness < 1 ? 'light' : 'medium');
                  }
                  
                  // Player hit animation after delay
                  if (battleEffects) {
                    setTimeout(() => {
                      setPlayerAnimation('hit');
                      setTimeout(() => setPlayerAnimation('idle'), 400);
                    }, 300);
                  }
                }
                
                // Reset enemy animation
                if (animationsEnabled) {
                  setTimeout(() => setEnemyAnimation('idle'), 600);
                }

                // Contrattacco da abilità del difensore (es. Fulmine Vivente, solo se sopravvive)
                const currentTarget = team[targetIdx];
                const counterPct = currentTarget ? getCounter(currentTarget.ability) : 0;
                if (currentTarget && counterPct > 0 && currentTarget.stats.hp > 0) {
                  const counterDamage = Math.floor(currentTarget.stats.attack * counterPct);
                  activeEnemy.stats.hp = Math.max(0, activeEnemy.stats.hp - counterDamage);
                  logs.push(`⚡ ${tMonster(currentTarget.id, lang)} ${t('battle.counterattacks_with', lang)} ${tAbilityName(currentTarget.ability, lang)}! (-${counterDamage} HP)`);
                }

                // Rubavita del nemico (es. Succhia Vita)
                const currentEnemy = enemies[prev.activeEnemyIndex];
                const enemyLifesteal = currentEnemy ? getLifesteal(currentEnemy.ability) : 0;
                if (currentEnemy && enemyLifesteal > 0 && currentEnemy.stats.hp < currentEnemy.stats.maxHp) {
                  const healAmount = Math.floor(damage * enemyLifesteal);
                  if (healAmount > 0) {
                    currentEnemy.stats.hp = Math.min(currentEnemy.stats.maxHp, currentEnemy.stats.hp + healAmount);
                    logs.push(`🧛 ${tMonster(currentEnemy.id, lang)} ${t('battle.recovers_hp_with', lang)} ${healAmount} ${t('battle.hp_with', lang)} ${tAbilityName(currentEnemy.ability, lang)}!`);
                  }
                }
                // Status on-hit da abilità del nemico (es. Pozione Mortale, Tela Appiccicosa)
                const enemyOnHit = getOnHitStatus(activeEnemy.ability);
                if (enemyOnHit && team[targetIdx].stats.hp > 0 && Math.random() * 100 < enemyOnHit.chance) {
                  if (!team[targetIdx].status.includes(enemyOnHit.status) && !isStatusImmune(team[targetIdx].ability, enemyOnHit.status)) {
                    team[targetIdx].status.push(enemyOnHit.status);
                    logs.push(`💫 ${tMonster(team[targetIdx].id, lang)} ${t('battle.is_now', lang)} ${getStatusName(enemyOnHit.status)}!`);
                  }
                }
                
                // Calcola effectChance modificato dalle abilità (data-driven)
                const modifiedEffectChance = getModifiedEffectChance(activeEnemy.ability, move.effect, move.effectChance || 0);
                
                if (move.effect && modifiedEffectChance > 0 && Math.random() * 100 < modifiedEffectChance) {
                  if (!team[targetIdx].status.includes(move.effect)) {
                    // Immunità agli status da abilità del difensore (Radici Profonde, Corona Maledetta...)
                    if (isStatusImmune(team[targetIdx].ability, move.effect)) {
                      logs.push(`✨ ${tMonster(team[targetIdx].id, lang)} ${t('battle.immune_to_status', lang)} (${tAbilityName(team[targetIdx].ability, lang)})`);
                    }
                    else {
                      team[targetIdx].status.push(move.effect);
                      
                      // Se è sonnambulo, imposta la durata (1-6 turni)
                      if (move.effect === 'sonnambulo') {
                        team[targetIdx].sleepTurns = Math.floor(Math.random() * 6) + 1;
                        logs.push(`💫 ${tMonster(team[targetIdx].id, lang)} ${t('battle.is_now', lang)} ${getStatusName(move.effect)}! (${team[targetIdx].sleepTurns} ${t('battle.turns', lang)})`);
                      } else {
                        logs.push(`💫 ${tMonster(team[targetIdx].id, lang)} ${t('battle.is_now', lang)} ${getStatusName(move.effect)}!`);
                      }
                    }
                  }
                }
                  if (team[targetIdx].stats.hp <= 0) {
                    logs.push(`${t('battle.fainted', lang)} ${tMonster(team[targetIdx].id, lang)}`);
                  }
                }
              }
            }
          }
} // Chiude il blocco else per il controllo burn death
        } else if (activeEnemy.status.includes('sonnambulo')) {
          // Controlla se si sveglia (20% di chance per turno)
          const wakeUpChance = Math.random() * 100;
          const sleepTurns = activeEnemy.sleepTurns || 1;
          
          if (wakeUpChance < 20 || sleepTurns <= 1) {
            // Si sveglia!
            logs.push(`😴 ${tMonster(activeEnemy.id, lang)} ${t('battle.woke_up', lang)}`);
            activeEnemy.status = activeEnemy.status.filter(s => s !== 'sonnambulo');
            activeEnemy.sleepTurns = undefined;
          } else {
            // Continua a dormire
            const newSleepTurns = sleepTurns - 1;
            logs.push(`😴 ${tMonster(activeEnemy.id, lang)} ${t('battle.sleeping', lang)} (${newSleepTurns} ${t('battle.turns_remaining', lang)})`);
            activeEnemy.sleepTurns = newSleepTurns;
          }
        } else if (activeEnemy.status.includes('paralizzato')) {
          logs.push(`⚡ ${tMonster(activeEnemy.id, lang)} ${t('battle.paralyzed', lang)}`);
        }
        
        // Rigenerazione a fine turno da abilità del nemico (es. Radici Oscure)
        const enemyRegen = getTurnRegen(activeEnemy.ability, activeEnemy.stats.hp, activeEnemy.stats.maxHp);
        if (enemyRegen > 0) {
          activeEnemy.stats.hp = Math.min(activeEnemy.stats.maxHp, activeEnemy.stats.hp + enemyRegen);
          logs.push(`🌑 ${tMonster(activeEnemy.id, lang)} ${t('battle.recovers_hp_with', lang)} ${enemyRegen} ${t('battle.hp_with', lang)} ${tAbilityName(activeEnemy.ability, lang)}!`);
        }
      }

      // Il putrefatto per il giocatore viene gestito in executePlayerAttack
      // Non duplicare il danno qui

      if (team[prev.selectedMonsterIndex].stats.hp <= 0) {
        const aliveMonsters = team.filter(m => m.stats.hp > 0);
        if (aliveMonsters.length === 0) {
          // Aggiorna statistiche persistenti
          setPersistentData(prev => ({
            ...prev,
            totalRuns: prev.totalRuns + 1,
            bestWave: Math.max(prev.bestWave, gameState.currentWave),
            totalLosses: prev.totalLosses + 1,
            totalBattles: prev.totalBattles + 1,
            bestRunWave: Math.max(prev.bestRunWave || 0, gameState.currentWave),
            currentWinStreak: 0,
          }));
          
          // Controlla achievement dopo la run
          setTimeout(() => checkAndUnlockAchievements(), 500);
          
          return {
            ...prev,
            team,
            battleEnemies: enemies,
            battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
            battleOver: true,
            battleWon: false,
            phase: 'game_over' as GamePhase,
          };
        } else {
          logs.push(`🔄 ${t('battle.chooses_another', lang)}`);
          setForceMonsterSelect(true);
          return {
            ...prev,
            team,
            battleEnemies: enemies,
            battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
            isPlayerTurn: true,
          };
        }
      }

      return {
        ...prev,
        team,
        battleEnemies: enemies,
        battleLog: [...prev.battleLog.slice(-8), ...logs.slice(-5)],
        isPlayerTurn: true,
      };
    });
  };

  const tryCapture = (itemId: string, free = false) => {
    const currentState = gameStateRef.current;
    if (!currentState.battleCatchable) {
      addLog(`❌ ${t('battle.cant_capture_trainer', lang)}`);
      return;
    }

    // Bug fix: squadra piena (6 mostri) => la cattura fallirebbe comunque,
    // evita di consumare lo strumento di cattura per nulla
    if (currentState.team.length >= 6) {
      addLog(`❌ ${t('battle.team_full', lang)}`);
      return;
    }

    const targetIdx = currentState.activeEnemyIndex;
    const target = currentState.battleEnemies[targetIdx];
    
    // Bug fix: controlla se il target è valido e vivo
    if (!target || target.stats.hp <= 0) {
      addLog(`❌ ${t('battle.no_active_enemy', lang)}`);
      return;
    }

    const itemIdx = free ? -1 : currentState.items.findIndex(i => i.id === itemId && i.quantity > 0);
    if (!free && itemIdx === -1) {
      addLog(`❌ ${t('battle.no_more_items', lang)}`);
      return;
    }

    const hpPercent = target.stats.hp / target.stats.maxHp;
    if (free && (!hasUpgrade(currentState.persistentData.upgrades, 'gravedigger_net') || hpPercent > 0.1)) return;

    const item = free ? null : currentState.items[itemIdx];
    const captureBonus = getUpgradeLevel(currentState.persistentData.upgrades, 'monster_charmer');
    
    // Formula: mostri di livello basso con HP bassi = facile catturare
    const levelFactor = Math.max(0.1, (100 - target.level) / 100);
    const hpFactor = Math.max(0.1, 1 - hpPercent);
    const catchRate = free
      ? 100
      : Math.min(100, Math.max(5, ((item?.power || 0) + captureBonus) * levelFactor * hpFactor * 4));
    const success = free || Math.random() * 100 < catchRate;

    if (!free) setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      return { ...prev, items };
    });

    setCatchAnimation(true);
    setTimeout(() => setCatchAnimation(false), 1500);

    if (success) {
      addLog(`${tMonster(target.id, lang)} ${t('battle.caught', lang)}`);
      
      // Aggiorna statistiche e obiettivi
      updateDailyObjective('catch_2_monsters');
      setPersistentData(prev => {
        const currentCatchesInRun = (prev.mostCatchesInRun || 0);
        const newMonsterUsage = { ...prev.monsterUsage };
        const monsterId = target.id;
        newMonsterUsage[monsterId] = (newMonsterUsage[monsterId] || 0) + 1;
        const favoriteMonster = Object.entries(newMonsterUsage)
          .sort(([,a]: [string, number], [,b]: [string, number]) => b - a)[0]?.[0] || '';
        return {
          ...prev,
          totalMonstersCaught: prev.totalMonstersCaught + 1,
          mostCatchesInRun: currentCatchesInRun + 1,
          monsterUsage: newMonsterUsage,
          favoriteMonster,
        };
      });

      const otherLivingEnemies = currentState.battleEnemies.some((enemy, index) =>
        index !== targetIdx && enemy.stats.hp > 0
      );
      const endsBattle = !otherLivingEnemies;
      if (endsBattle) {
        const nodeType = currentState.map[currentState.currentNode]?.type || 'wild';
        const cursedCoinsReward = calculateCursedCoinsReward(
          nodeType,
          currentState.currentWave,
          currentState.team.every(monster => monster.stats.hp > 0),
          false,
          false,
        );
        updateDailyObjective('win_3_battles');
        setPersistentData(prev => {
          const newStreak = (prev.currentWinStreak || 0) + 1;
          return {
            ...prev,
            cursedCoins: prev.cursedCoins + cursedCoinsReward,
            totalWins: prev.totalWins + 1,
            totalBattles: prev.totalBattles + 1,
            currentWinStreak: newStreak,
            longestWinStreak: Math.max(prev.longestWinStreak || 0, newStreak),
            bestWave: Math.max(prev.bestWave, currentState.currentWave),
            bestRunWave: Math.max(prev.bestRunWave || 0, currentState.currentWave),
          };
        });
        if (cursedCoinsReward > 0) addLog(`💰 +${cursedCoinsReward} ${t('battle.cursed_coins_earned', lang)}`);
        setTimeout(() => checkAndUnlockAchievements(), 500);
      }
      
      // Give EXP for capture
      const expGain = Math.floor((target.level * 5 + 10) * (1 + getUpgradeLevel(currentState.persistentData.upgrades, 'fast_growth') * 0.01));
      setGameState(prev => {
        const team = deepClone(prev.team);
        team[prev.selectedMonsterIndex].exp += expGain;
        grantBenchExperience(team, prev.selectedMonsterIndex, expGain, currentState.persistentData.upgrades);
        addLog(`${t('battle.exp_gain', lang).replace('EXP', `${expGain} EXP`)}`);
        
        // Level up logic
        while (team[prev.selectedMonsterIndex].exp >= team[prev.selectedMonsterIndex].expToNext) {
          team[prev.selectedMonsterIndex].exp -= team[prev.selectedMonsterIndex].expToNext;
          team[prev.selectedMonsterIndex].level++;
          team[prev.selectedMonsterIndex].expToNext = Math.floor(team[prev.selectedMonsterIndex].expToNext * 1.3);
          team[prev.selectedMonsterIndex].stats.maxHp += 3;
          team[prev.selectedMonsterIndex].stats.hp += 3;
          team[prev.selectedMonsterIndex].stats.attack += 2;
          team[prev.selectedMonsterIndex].stats.defense += 1;
          team[prev.selectedMonsterIndex].stats.speed += 1;
          addLog(`${t('battle.level_up', lang)} ${team[prev.selectedMonsterIndex].level}!`);
          
          // Learn new moves at levels 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40
          const newMoveLevels = [7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40];
          if (newMoveLevels.includes(team[prev.selectedMonsterIndex].level)) {
            const mon = team[prev.selectedMonsterIndex];
            
            // 50% chance to learn a move of the same type (STAB), 50% chance for other types
            const learnSTAB = Math.random() < 0.5;
            let availableMoves: typeof allMoves;
            
            if (learnSTAB) {
              // Prefer moves of the same type
              availableMoves = allMoves.filter((m: typeof allMoves[0]) => 
                m.type === mon.type && !mon.moves.find(mm => mm.id === m.id)
              );
            } else {
              // Learn moves of different types for variety
              availableMoves = allMoves.filter((m: typeof allMoves[0]) => 
                m.type !== mon.type && !mon.moves.find(mm => mm.id === m.id)
              );
            }
            
            if (availableMoves.length > 0) {
              const newMove = availableMoves[Math.floor(Math.random() * availableMoves.length)];
              if (mon.moves.length < 4) {
                mon.moves.push(deepClone(newMove));
                addLog(`✨ ${tMonster(mon.id, lang)} ${t('battle.learns', lang)} ${tMove(newMove.id, lang)}!`);
              } else {
                // Show move choice modal
                setPendingNewMove(newMove);
                setShowMoveChoice(true);
                addLog(`✨ ${tMonster(mon.id, lang)} ${t('battle.wants_to_learn', lang)} ${tMove(newMove.id, lang)}!`);
              }
            }
          }
        }
        
        if (prev.team.length < 6) {
          const captured = deepClone(target);
          captured.stats.hp = Math.floor(captured.stats.maxHp * 0.5);
          const upgradedCaptured = applyMetaBonusesToMonster(captured, currentState.persistentData.upgrades);
          return {
            ...prev,
            team: [...team, upgradedCaptured],
            battleEnemies: prev.battleEnemies.filter((_, i) => i !== targetIdx),
          };
        } else {
          addLog(t('battle.team_full', lang));
          return { ...prev, team };
        }
      });
      
      setGameState(prev => {
        const remaining = prev.battleEnemies.filter(e => e.stats.hp > 0);
        if (remaining.length === 0) {
          const map = deepClone(prev.map);
          if (map[prev.currentNode]) map[prev.currentNode].completed = true;
          return { ...prev, map, battleOver: true, battleWon: true };
        } else {
          // Bug fix: l'indice deve riferirsi a battleEnemies, non all'array filtrato
          const nextAlive = prev.battleEnemies.findIndex(e => e.stats.hp > 0);
          if (nextAlive !== -1) {
            addLog(`🔄 ${prev.battleEnemies[nextAlive].emoji} ${tMonster(prev.battleEnemies[nextAlive].id, lang)} ${t('battle.enters_field', lang)}`);
            // Bug fix: la cattura consuma il turno — dopo una cattura riuscita
            // con nemici ancora in campo, tocca al nemico (come dopo una cattura fallita)
            return { ...prev, activeEnemyIndex: nextAlive, isPlayerTurn: false };
          }
        }
        return prev;
      });

      // Se la battaglia continua, il nemico risponde dopo l'animazione di cattura
      setTimeout(() => {
        const cur = gameStateRef.current;
        if (!cur.battleOver && !cur.isPlayerTurn && cur.battleEnemies.some(e => e.stats.hp > 0)) {
          enemyTurn();
        }
      }, 1500);
    } else {
      addLog(`${tMonster(target.id, lang)} ${t('battle.escape_capture', lang)}`);
      setGameState(prev => ({ ...prev, isPlayerTurn: false }));
      // Controlla se la battaglia è finita prima di dare il turno al nemico
      setTimeout(() => {
        const cur = gameStateRef.current;
        if (!cur.battleOver && cur.battleEnemies.some(e => e.stats.hp > 0)) {
          enemyTurn();
        }
      }, 800);
    }
    setShowItemSelect(false);
  };

  const usePotion = (itemId: string) => {
    const itemIdx = gameState.items.findIndex(i => i.id === itemId && i.quantity > 0);
    if (itemIdx === -1) return;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    
    // Bug fix: controlla se il mostro è valido
    if (!monster) {
      addLog(t('battle.no_active_monster', lang));
      return;
    }
    
    if (monster.stats.hp <= 0) {
      addLog(t('battle.exhausted', lang));
      return;
    }

    const item = gameState.items[itemIdx];
    
    // Elisir Spettrale: cura tutti gli status alterati
    if (itemId === 'elisir_spettrale') {
      setGameState(prev => {
        const items = deepClone(prev.items);
        items[itemIdx].quantity--;
        const team = deepClone(prev.team);
        team[prev.selectedMonsterIndex].status = [];
        team[prev.selectedMonsterIndex].sleepTurns = undefined;
        return { ...prev, items, team, isPlayerTurn: false };
      });
      addLog(`⚗️ ${tMonster(monster.id, lang)} ${t('battle.all_status_cured', lang)}`);
      setShowItemSelect(false);
      setTimeout(() => enemyTurn(), 800);
      return;
    }
    
    // Frammento di Luna: cura 30 HP a tutta la squadra
    if (itemId === 'frammento_luna') {
      setGameState(prev => {
        const items = deepClone(prev.items);
        items[itemIdx].quantity--;
        const team = deepClone(prev.team);
        team.forEach((m, idx) => {
          if (m.stats.hp > 0) {
            const healed = Math.min(item.power, m.stats.maxHp - m.stats.hp);
            team[idx].stats.hp += healed;
          }
        });
        return { ...prev, items, team, isPlayerTurn: false };
      });
      addLog(`🌙 ${t('battle.team_healed', lang)} 30 ${t('battle.hp', lang)}!`);
      setShowItemSelect(false);
      setTimeout(() => enemyTurn(), 800);
      return;
    }
    
    // Pozioni normali: curano HP
    const healed = Math.min(item.power, monster.stats.maxHp - monster.stats.hp);

    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      const team = deepClone(prev.team);
      team[prev.selectedMonsterIndex].stats.hp += healed;
      return { ...prev, items, team, isPlayerTurn: false };
    });

    addLog(`${t('battle.healed', lang)} ${tMonster(monster.id, lang)} ${healed} ${t('battle.hp', lang)}!`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  const useCandle = () => {
    const itemIdx = gameState.items.findIndex(i => i.id === 'candela_protettiva' && i.quantity > 0);
    if (itemIdx === -1) return;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    
    // Bug fix: controlla se il mostro è valido
    if (!monster) {
      addLog(t('battle.no_active_monster', lang));
      return;
    }
    
    if (monster.stats.hp <= 0) {
      addLog(t('battle.exhausted', lang));
      return;
    }
    
    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      const team = deepClone(prev.team);
      // Cura tutti gli status alterati
      team[prev.selectedMonsterIndex].status = [];
      team[prev.selectedMonsterIndex].sleepTurns = undefined;
      // Aggiunge anche 10 HP come da descrizione
      const currentMonster = team[prev.selectedMonsterIndex];
      const healed = Math.min(10, currentMonster.stats.maxHp - currentMonster.stats.hp);
      currentMonster.stats.hp += healed;
      return { ...prev, items, team, isPlayerTurn: false };
    });

    addLog(`🕯️ ${tMonster(monster.id, lang)} ${t('battle.status_cured', lang)} +10 ${t('battle.hp', lang)}`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  // Nettare di Zucca: +10 HP massimi permanenti (per questa run) al mostro attivo
  const usePumpkinNectar = () => {
    const itemIdx = gameState.items.findIndex(i => i.id === 'nettare_zucca' && i.quantity > 0);
    if (itemIdx === -1) return;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    if (!monster) {
      addLog(t('battle.no_active_monster', lang));
      return;
    }
    if (monster.stats.hp <= 0) {
      addLog(t('battle.exhausted', lang));
      return;
    }

    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      const team = deepClone(prev.team);
      team[prev.selectedMonsterIndex].stats.maxHp += 10;
      team[prev.selectedMonsterIndex].stats.hp += 10;
      return { ...prev, items, team, isPlayerTurn: false };
    });

    addLog(`🍯 ${tMonster(monster.id, lang)}: ${t('battle.max_hp_up', lang)}`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  // Pozione della Non-Morte: il mostro attivo evita un KO, una volta per battaglia
  const useUndeathPotion = () => {
    const itemIdx = gameState.items.findIndex(i => i.id === 'pozione_non_morte' && i.quantity > 0);
    if (itemIdx === -1) return;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    if (!monster) {
      addLog(t('battle.no_active_monster', lang));
      return;
    }
    if (monster.stats.hp <= 0) {
      addLog(t('battle.exhausted', lang));
      return;
    }
    if (undeathProtection) {
      addLog(`💀 ${tItem('pozione_non_morte', lang)}: ${t('battle.already_active', lang)}`);
      return;
    }

    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      return { ...prev, items, isPlayerTurn: false };
    });
    setUndeathProtection(true);

    addLog(`💀 ${tMonster(monster.id, lang)}: ${tItem('pozione_non_morte', lang)}!`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  const useBansheeTears = () => {
    const itemIdx = gameState.items.findIndex(i => i.id === 'lacrime_banshee' && i.quantity > 0);
    if (itemIdx === -1) return;

    // Trova il primo mostro KO nella squadra
    const faintedMonsterIdx = gameState.team.findIndex(m => m.stats.hp <= 0);
    if (faintedMonsterIdx === -1) {
      addLog(`💧 ${t('battle.no_fainted_monster', lang)}`);
      return;
    }

    const monster = gameState.team[faintedMonsterIdx];
    
    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      const team = deepClone(prev.team);
      // Resuscita il mostro a metà HP e rimuovi status
      team[faintedMonsterIdx].stats.hp = Math.floor(team[faintedMonsterIdx].stats.maxHp / 2);
      team[faintedMonsterIdx].status = [];
      team[faintedMonsterIdx].sleepTurns = undefined;
      return { ...prev, items, team, isPlayerTurn: false };
    });

    addLog(`💧 ${tMonster(monster.id, lang)} ${t('battle.revived', lang)} ${Math.floor(monster.stats.maxHp / 2)} ${t('battle.hp', lang)}!`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  const usePPCrystal = (moveIndex: number) => {
    const itemIdx = gameState.items.findIndex(i => i.id === 'cristallo_pp' && i.quantity > 0);
    if (itemIdx === -1) return;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    
    // Bug fix: controlla se il mostro e la mossa sono validi
    if (!monster || !monster.moves || !monster.moves[moveIndex]) {
      addLog(t('battle.no_active_monster', lang));
      return;
    }
    
    const move = monster.moves[moveIndex];
    
    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      const team = deepClone(prev.team);
      team[prev.selectedMonsterIndex].moves[moveIndex].pp = Math.min(move.maxPp, move.pp + 10);
      return { ...prev, items, team, isPlayerTurn: false };
    });

    addLog(`💎 ${tMonster(monster.id, lang)}: ${tMove(move.id, lang)} ${t('battle.pp_restored', lang)}`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  const useTotalPPCrystal = () => {
    const itemIdx = gameState.items.findIndex(i => i.id === 'cristallo_pp_totale' && i.quantity > 0);
    if (itemIdx === -1) return;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    
    // Bug fix: controlla se il mostro è valido
    if (!monster) {
      addLog(t('battle.no_active_monster', lang));
      return;
    }
    
    setGameState(prev => {
      const items = deepClone(prev.items);
      items[itemIdx].quantity--;
      const team = deepClone(prev.team);
      team[prev.selectedMonsterIndex].moves = team[prev.selectedMonsterIndex].moves.map(m => ({
        ...m,
        pp: m.maxPp
      }));
      return { ...prev, items, team, isPlayerTurn: false };
    });

    addLog(`💠 ${tMonster(monster.id, lang)}: ${t('battle.all_pp_restored', lang)}`);
    setShowItemSelect(false);
    setTimeout(() => enemyTurn(), 800);
  };

  const switchMonster = (idx: number) => {
    // Bug fix: controlla se l'indice è valido
    if (idx < 0 || idx >= gameState.team.length) return;
    if (gameState.team[idx].stats.hp <= 0) return;

    // Bug fix: quando il cambio è forzato (mostro precedente esausto),
    // il nemico ha già agito: non deve attaccare di nuovo
    const wasForcedSwitch = forceMonsterSelect;

    setGameState(prev => ({ ...prev, selectedMonsterIndex: idx }));
    addLog(`${t('battle.go', lang)} ${tMonster(gameState.team[idx].id, lang)}!`);
    setShowTeamSelect(false);
    setForceMonsterSelect(false);
    if (wasForcedSwitch) {
      setGameState(prev => ({ ...prev, isPlayerTurn: true }));
      return;
    }
    setGameState(prev => ({ ...prev, isPlayerTurn: false }));
    // Controlla se la battaglia è finita prima di dare il turno al nemico
    setTimeout(() => {
      const cur = gameStateRef.current;
      if (!cur.battleOver && cur.battleEnemies.some(e => e.stats.hp > 0)) {
        enemyTurn();
      }
    }, 800);
  };

  const moveMonsterUp = (idx: number) => {
    if (idx === 0) return;
    setGameState(prev => {
      const newTeam = [...prev.team];
      const temp = newTeam[idx];
      newTeam[idx] = newTeam[idx - 1];
      newTeam[idx - 1] = temp;
      // Update selectedMonsterIndex if needed
      let newIndex = prev.selectedMonsterIndex;
      if (prev.selectedMonsterIndex === idx) newIndex = idx - 1;
      else if (prev.selectedMonsterIndex === idx - 1) newIndex = idx;
      return { ...prev, team: newTeam, selectedMonsterIndex: newIndex };
    });
  };

  const moveMonsterDown = (idx: number) => {
    if (idx === gameState.team.length - 1) return;
    setGameState(prev => {
      const newTeam = [...prev.team];
      const temp = newTeam[idx];
      newTeam[idx] = newTeam[idx + 1];
      newTeam[idx + 1] = temp;
      // Update selectedMonsterIndex if needed
      let newIndex = prev.selectedMonsterIndex;
      if (prev.selectedMonsterIndex === idx) newIndex = idx + 1;
      else if (prev.selectedMonsterIndex === idx + 1) newIndex = idx;
      return { ...prev, team: newTeam, selectedMonsterIndex: newIndex };
    });
  };

  const returnToMap = () => {
    const needNewMap = !gameState.map || gameState.map.length === 0 || gameState.currentNode >= gameState.map.length - 1;
    const nextWave = needNewMap ? gameState.currentWave + 1 : gameState.currentWave;
    const completedGym = needNewMap && gameState.battleWon &&
      gameState.map[gameState.currentNode]?.type === 'gym_leader';
    const gymHealUnlocked = hasUpgrade(persistentData.upgrades, 'checkpoint_heal');
    const waveRegenLevel = getUpgradeLevel(persistentData.upgrades, 'night_regen');
    const infiniteElixirReady = hasUpgrade(persistentData.upgrades, 'infinite_elixir') &&
      needNewMap && gameState.currentWave % 5 === 0;
    
    // Aggiorna obiettivo "raggiungi ondata 5"
    updateDailyObjective('reach_wave_5', nextWave);
    
    // Report level complete for analytics
    reportLevelComplete(`wave_${gameState.currentWave}`, gameState.currentWave);
    
    // Pubblicità interstitial: alla sconfitta del capopalestra (mappa completata)
    // oppure ogni 5 ondate, rispettando il delay minimo di Playgama (60s)
    // e il blocco dei primi 30s dall'avvio del gioco
    const now = Date.now();
    const canShowAd =
      now - lastInterstitialRef.current >= 60000 &&
      now - gameStartRef.current >= 30000;
    if (canShowAd && (needNewMap || nextWave % 5 === 0)) {
      lastInterstitialRef.current = now;
      showInterstitialAd().catch(() => {});
    }
    
    setGameState(prev => ({
      ...prev,
      team: prev.team.map(monster => {
        const updated = deepClone(monster);
        if (completedGym && gymHealUnlocked) {
          updated.stats.hp = updated.stats.hp > 0 ? updated.stats.maxHp : 0;
          updated.status = [];
          updated.sleepTurns = undefined;
          updated.moves = updated.moves.map(move => ({ ...move, pp: move.maxPp }));
        } else if (needNewMap && waveRegenLevel > 0 && updated.stats.hp > 0) {
          const regen = Math.max(1, Math.floor(updated.stats.maxHp * waveRegenLevel * 0.01));
          updated.stats.hp = Math.min(updated.stats.maxHp, updated.stats.hp + regen);
        }
        return updated;
      }).map((monster, index, team) => {
        if (!infiniteElixirReady || index !== team
          .map((item, teamIndex) => ({ item, teamIndex }))
          .filter(entry => entry.item.stats.hp > 0)
          .sort((a, b) =>
            a.item.stats.hp / a.item.stats.maxHp - b.item.stats.hp / b.item.stats.maxHp
          )[0]?.teamIndex) return monster;
        return {
          ...monster,
          stats: { ...monster.stats, hp: Math.min(monster.stats.maxHp, monster.stats.hp + 100) },
        };
      }),
      phase: 'map',
      currentWave: nextWave,
      map: needNewMap ? generateMap(nextWave) : prev.map,
      currentNode: needNewMap ? -1 : prev.currentNode,
    }));
  };

  const buyItem = (itemId: string, cost: number) => {
    setGameState(prev => {
      if (prev.candies < cost) return prev;
      const items = deepClone(prev.items);
      const item = items.find(i => i.id === itemId);
      if (!item) return prev; // Item non trovato, non fare nulla
      if (item.category === 'potion' && item.quantity >= getItemStackCapacity(itemId, persistentData.upgrades)) return prev;
      item.quantity++;
      return { ...prev, items, candies: prev.candies - cost };
    });
  };

  const healTeam = () => {
    if (gameState.healsUsed >= 2) {
      showToast(t('map.no_more_heals', lang));
      return;
    }
    
    const adsNeeded = gameState.healsUsed === 0 ? 2 : 3;
    setGameState(prev => ({
      ...prev,
      showAdModal: true,
      adType: 'heal',
      adsToWatch: adsNeeded,
      adsWatched: 0,
    }));
  };

  // Placement Playgama per tipo di ricompensa (vedi playgama-bridge-config.json)
  const AD_PLACEMENTS: Record<string, string> = {
    heal: 'heal_team',
    revive: 'revive_monster',
    coins: 'cursed_coins',
  };

  const startWatchingAd = () => {
    // Bug fix: ignora doppi click mentre un ad e' gia' in riproduzione
    if (isWatchingAd) return;

    setIsWatchingAd(true);
    setAdCountdown(3);

    // Ad simulata di riserva: usata quando l'SDK non c'e' o l'ad reale
    // non parte (nessun fill, placement non configurato, piattaforma mock).
    // Senza questo fallback il giocatore non riceveva MAI la ricompensa
    // in quei casi (bug: "guardi la pubblicita' ma non arrivano le monete").
    const runSimulatedAd = () => {
      let remaining = 3;
      const timer = setInterval(() => {
        remaining -= 1;
        setAdCountdown(Math.max(remaining, 0));
        if (remaining <= 0) {
          clearInterval(timer);
          setIsWatchingAd(false);
          finishAd(); // fuori dall'updater: la ricompensa non puo' essere data due volte
        }
      }, 1000);
    };

    // Use Playgama SDK for rewarded ads
    const placement = AD_PLACEMENTS[gameStateRef.current.adType || ''] || undefined;
    showRewardedAd(placement).then(result => {
      if (result === 'rewarded') {
        // Ad completed successfully with Playgama SDK
        setIsWatchingAd(false);
        finishAd();
      } else if (result === 'closed') {
        // Ad chiusa volontariamente prima della fine: nessun premio
        setIsWatchingAd(false);
        setGameState(prev => ({
          ...prev,
          showAdModal: false,
          adType: null,
          adsToWatch: 0,
          adsWatched: 0,
        }));
      } else {
        // 'unavailable' (no SDK) o 'failed' (ad non partita):
        // fallback all'ad simulata cosi' la ricompensa arriva comunque
        runSimulatedAd();
      }
    });
  };

  // Guarda una pubblicita' per guadagnare Monete Maledette (max giornaliero)
  const watchAdForCoins = () => {
    if (getAdCoinsLeft(persistentData) <= 0) return;
    setGameState(prev => ({
      ...prev,
      showAdModal: true,
      adType: 'coins',
      adsToWatch: 1,
      adsWatched: 0,
    }));
  };

  const finishAd = () => {
    // Ricompensa in monete: aggiorna i dati persistenti (contatore giornaliero)
    if (gameStateRef.current.adType === 'coins') {
      const today = new Date().toDateString();
      setPersistentData(prev => ({
        ...prev,
        cursedCoins: prev.cursedCoins + AD_COINS_REWARD,
        adCoinsDate: today,
        adCoinsWatched: (prev.adCoinsDate === today ? prev.adCoinsWatched : 0) + 1,
      }));
      setGameState(prev => ({
        ...prev,
        showAdModal: false,
        adType: null,
        adsToWatch: 0,
        adsWatched: 0,
      }));
      return;
    }
    setGameState(prev => {
      const newAdsWatched = prev.adsWatched + 1;
      
      if (newAdsWatched >= prev.adsToWatch) {
        // All ads watched, apply effect
        if (prev.adType === 'heal') {
          return {
            ...prev,
            team: prev.team.map(m => ({
              ...m,
              stats: { ...m.stats, hp: m.stats.maxHp },
              status: [],
              sleepTurns: undefined,
              moves: m.moves.map(mv => ({ ...mv, pp: mv.maxPp })),
            })),
            healsUsed: prev.healsUsed + 1,
            showAdModal: false,
            adType: null,
            adsToWatch: 0,
            adsWatched: 0,
          };
        } else if (prev.adType === 'revive') {
          // Revive first fainted monster (prefer strongest if multiple are fainted)
          if (prev.team.length > 0) {
            const faintedMonsters = prev.team.filter(m => m.stats.hp <= 0);
            if (faintedMonsters.length > 0) {
              // Scegli il mostro KO con il livello più alto
              const strongest = faintedMonsters.reduce((prev, current) => 
                (prev.level > current.level) ? prev : current
              );
              const teamCopy = deepClone(prev.team);
              const idx = teamCopy.findIndex(m => m.id === strongest.id);
              if (idx !== -1) {
                teamCopy[idx].stats.hp = Math.floor(teamCopy[idx].stats.maxHp * 0.5);
                teamCopy[idx].status = [];
                teamCopy[idx].sleepTurns = undefined;
                return {
                  ...prev,
                  team: teamCopy,
                  phase: 'map',
                  showAdModal: false,
                  adType: null,
                  adsToWatch: 0,
                  adsWatched: 0,
                };
              }
            }
          }
        }
      }
      
      return { ...prev, adsWatched: newAdsWatched };
    });
  };

  const reviveMonster = () => {
    // Bug fix: controlla se ci sono mostri KO da resuscitare
    const hasFaintedMonster = gameState.team.some(m => m.stats.hp <= 0);
    if (!hasFaintedMonster) {
      addLog(`💧 ${t('battle.no_fainted_monster', lang)}`);
      return;
    }

    if (hasUpgrade(persistentData.upgrades, 'gravedigger_amulet') && !amuletReviveUsed) {
      const team = deepClone(gameState.team);
      const faintedIndex = team
        .map((monster, index) => ({ monster, index }))
        .filter(entry => entry.monster.stats.hp <= 0)
        .sort((a, b) => b.monster.level - a.monster.level)[0]?.index;
      if (faintedIndex !== undefined) {
        team[faintedIndex].stats.hp = Math.max(1, Math.floor(team[faintedIndex].stats.maxHp * 0.5));
        team[faintedIndex].status = [];
        team[faintedIndex].sleepTurns = undefined;
        setAmuletReviveUsed(true);
        setGameState(prev => ({
          ...prev,
          team,
          selectedMonsterIndex: faintedIndex,
          phase: 'battle',
          battleOver: false,
          battleWon: false,
          isPlayerTurn: true,
          showAdModal: false,
          adType: null,
          battleLog: [...prev.battleLog.slice(-8), `🔮 ${tMonster(team[faintedIndex].id, lang)} ${t('battle.revived', lang)}`],
        }));
        return;
      }
    }
    
    setGameState(prev => ({
      ...prev,
      showAdModal: true,
      adType: 'revive',
      adsToWatch: 1,
      adsWatched: 0,
    }));
  };

  const getStatusName = (status: StatusEffect): string => {
    return tStatus(status, lang);
  };

  const renderAdModal = () => {
    if (!gameState.showAdModal) return null;

    return (
      <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
        <div className="bg-gradient-to-b from-purple-900 to-black rounded-xl p-6 max-w-lg w-full border-2 border-purple-600 shadow-2xl shadow-purple-500/50">
          {isWatchingAd ? (
            // Simulated ad playing
            <div className="text-center">
              <div className="bg-black rounded-lg p-8 mb-4 border-2 border-gray-600">
                <div className="text-6xl mb-4 animate-pulse">📺</div>
                <p className="text-white text-xl font-bold mb-2">{t('ad.watching', lang)}</p>
                <p className="text-gray-400 text-sm mb-4">{t('ad.wait', lang)}</p>
                <div className="w-full bg-gray-700 rounded-full h-4 mb-2">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-green-400 h-4 rounded-full transition-all duration-1000"
                    style={{ width: `${((3 - adCountdown) / 3) * 100}%` }}
                  />
                </div>
                <p className="text-yellow-400 text-2xl font-bold">{adCountdown}</p>
              </div>
              <p className="text-gray-400 text-sm">
                {t('ad.progress', lang)} {gameState.adsWatched + 1} {t('ad.of', lang)} {gameState.adsToWatch}
              </p>
            </div>
          ) : (
            // Ad waiting screen
            <>
              <h3 className="text-2xl font-bold text-orange-400 mb-4 text-center">
                {gameState.adType === 'heal' ? `💚 ${t('ad.heal_team', lang)}` : gameState.adType === 'coins' ? `💰 ${t('ad.earn_coins', lang)}` : `✨ ${t('ad.revive_monster', lang)}`}
              </h3>
              
              <div className="bg-purple-900/50 rounded-lg p-4 mb-4 border border-purple-600">
                <p className="text-white text-center mb-2">
                  {gameState.adType === 'heal' ? t('ad.to_heal', lang) : gameState.adType === 'coins' ? t('ad.to_coins', lang) : t('ad.to_revive', lang)}
                </p>
                <p className="text-yellow-400 text-center text-3xl font-bold">
                  {gameState.adType === 'coins' ? `💰 +${AD_COINS_REWARD}` : `📺 ${gameState.adsToWatch} ${t('ad.ads', lang)}`}
                </p>
              </div>
              
              <div className="text-center mb-6">
                <p className="text-green-400 text-lg font-bold">
                  ✓ {t('ad.completed', lang)}: {gameState.adsWatched} / {gameState.adsToWatch}
                </p>
                <div className="w-full bg-gray-700 rounded-full h-3 mt-2">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-green-400 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${(gameState.adsWatched / gameState.adsToWatch) * 100}%` }}
                  />
                </div>
              </div>
              
              <button
                onClick={startWatchingAd}
                className="w-full px-6 py-4 bg-gradient-to-r from-green-600 to-green-700 text-white text-xl font-bold rounded-lg hover:scale-105 transition-all border-2 border-green-400 shadow-lg shadow-green-500/30"
              >
                ▶️ {t('ad.watch', lang)} ({gameState.adsWatched + 1}/{gameState.adsToWatch})
              </button>
              
              <button
                onClick={() => setGameState(prev => ({ ...prev, showAdModal: false, adType: null, adsWatched: 0 }))}
                className="w-full mt-3 px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
              >
                ❌ {t('ad.cancel', lang)}
              </button>
            </>
          )}
        </div>
      </div>
    );
  };

  const renderMoveChoiceModal = () => {
    if (!showMoveChoice || !pendingNewMove) return null;

    const monster = gameState.team[gameState.selectedMonsterIndex];
    
    // Controlla se il mostro è valido
    if (!monster || monster.stats.hp <= 0) {
      setShowMoveChoice(false);
      setPendingNewMove(null);
      return null;
    }

    const handleReplaceMove = (moveIndex: number) => {
      // Bug fix: controlla se la mossa esiste prima di accedere alle sue proprietà
      if (!monster.moves || !monster.moves[moveIndex]) {
        console.error('Invalid move index in handleReplaceMove');
        setShowMoveChoice(false);
        setPendingNewMove(null);
        return;
      }
      
      const oldMoveId = monster.moves[moveIndex].id;
      
      setGameState(prev => {
        const team = deepClone(prev.team);
        if (team[prev.selectedMonsterIndex]) {
          team[prev.selectedMonsterIndex].moves[moveIndex] = deepClone(pendingNewMove);
        }
        return { ...prev, team };
      });
      addLog(`✨ ${tMonster(monster.id, lang)} ${t('battle.forgets', lang)} ${tMove(oldMoveId, lang)} ${t('battle.and_learns', lang)} ${tMove(pendingNewMove.id, lang)}!`);
      setShowMoveChoice(false);
      setPendingNewMove(null);
    };

    const handleSkipMove = () => {
      addLog(`${tMonster(monster.id, lang)} ${t('battle.decides_not_to_learn', lang)} ${tMove(pendingNewMove.id, lang)}.`);
      setShowMoveChoice(false);
      setPendingNewMove(null);
    };

    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <div className="bg-gradient-to-b from-purple-900 to-black rounded-xl p-6 max-w-lg w-full border-2 border-purple-600">
          <h3 className="text-2xl font-bold text-orange-400 mb-4 text-center">
            ✨ {t('battle.new_move', lang)}
          </h3>
          <p className="text-white text-center mb-4">
            {tMonster(monster.id, lang)} {t('battle.wants_to_learn', lang)} <span className="text-yellow-400 font-bold">{tMove(pendingNewMove.id, lang)}</span>
          </p>
          <p className="text-gray-300 text-sm text-center mb-6">
            {t('battle.already_has_4_moves', lang)}
          </p>
          
          <div className="grid grid-cols-1 gap-3 mb-6">
            {monster.moves?.map((move, idx) => (
              <button
                key={idx}
                onClick={() => handleReplaceMove(idx)}
                className="p-3 rounded-lg text-left bg-red-900/30 hover:bg-red-800/50 border-2 border-red-600 transition-all"
              >
                <div className="flex justify-between items-center">
                  <span className="text-white font-bold">{tMove(move.id, lang)}</span>
                  <span className="text-xs text-gray-400">{move.pp}/{move.maxPp} PP</span>
                </div>
                <div className="flex gap-2 mt-1">
                  <span className="text-xs" style={{ color: typeColors[move.type] }}>{typeEmojis[move.type]} {tType(move.type, lang)}</span>
                  <span className="text-xs text-gray-400">{t('battle.power_short', lang)}: {move.power}</span>
                  <span className="text-xs text-gray-400">{t('battle.acc_short', lang)}: {move.accuracy}%</span>
                </div>
              </button>
            )) || []}
          </div>

          <div className="border-t border-gray-600 pt-4">
            <p className="text-yellow-400 text-center mb-3 font-bold">{t('battle.new_move', lang)}</p>
            <div className="p-3 rounded-lg bg-green-900/30 border-2 border-green-600 mb-4">
              <div className="flex justify-between items-center">
                <span className="text-white font-bold">{tMove(pendingNewMove.id, lang)}</span>
                <span className="text-xs text-gray-400">{pendingNewMove.pp}/{pendingNewMove.maxPp} PP</span>
              </div>
              <div className="flex gap-2 mt-1">
                <span className="text-xs" style={{ color: typeColors[pendingNewMove.type] }}>{typeEmojis[pendingNewMove.type]} {tType(pendingNewMove.type, lang)}</span>
                <span className="text-xs text-gray-400">{t('battle.power_short', lang)}: {pendingNewMove.power}</span>
                <span className="text-xs text-gray-400">{t('battle.acc_short', lang)}: {pendingNewMove.accuracy}%</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleSkipMove}
            className="w-full px-6 py-3 bg-gray-700 text-white font-bold rounded-lg hover:bg-gray-600 transition-all"
          >
            ❌ {t('battle.dont_learn_move', lang)}
          </button>
        </div>
      </div>
    );
  };

  const renderTitle = () => (
    <div className="relative flex flex-col items-center justify-center min-h-screen overflow-hidden p-4">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-950 via-black to-orange-950">
        {/* Floating particles */}
        <div className="absolute inset-0 overflow-hidden">
          {particles.map((particle, i) => (
            <div
              key={i}
              className="absolute animate-float-particle"
              style={{
                left: `${particle.left}%`,
                top: `${particle.top}%`,
                animationDelay: `${particle.delay}s`,
                animationDuration: `${particle.duration}s`,
              }}
            >
              <div className="w-1 h-1 bg-orange-400/30 rounded-full" />
            </div>
          ))}
        </div>
        
        {/* Glowing orbs */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-purple-600/20 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-orange-600/20 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-green-600/10 rounded-full blur-2xl animate-pulse-slow" style={{ animationDelay: '4s' }} />
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-4xl">
        {/* Title Section */}
        <div className="text-center mb-8 animate-fade-in-down">
          {/* Floating Halloween Icons */}
          <div className="relative mb-4">
            <div className="absolute -top-8 -left-12 text-4xl animate-float-slow">👻</div>
            <div className="absolute -top-6 -right-12 text-4xl animate-float-slow" style={{ animationDelay: '1s' }}>🦇</div>
            <div className="absolute -bottom-4 -left-8 text-3xl animate-float-slow" style={{ animationDelay: '2s' }}>🕷️</div>
            <div className="absolute -bottom-6 -right-8 text-3xl animate-float-slow" style={{ animationDelay: '3s' }}>💀</div>

            {/* Hero: artwork originali dei mostri */}
            <div className="flex items-end justify-center gap-1 md:gap-4">
              <img
                src={getMonsterIconPath('gattojella') || ''}
                alt=""
                draggable={false}
                className="w-16 h-16 md:w-24 md:h-24 object-contain animate-float-slow drop-shadow-[0_0_20px_rgba(147,112,219,0.6)]"
                style={{ animationDelay: '1s' }}
              />
              <img
                src={getMonsterIconPath('sovranozucca') || ''}
                alt=""
                draggable={false}
                className="w-36 h-36 md:w-52 md:h-52 object-contain animate-bounce-slow drop-shadow-[0_0_45px_rgba(255,140,0,0.65)]"
              />
              <img
                src={getMonsterIconPath('criofante') || ''}
                alt=""
                draggable={false}
                className="w-16 h-16 md:w-24 md:h-24 object-contain animate-float-slow drop-shadow-[0_0_20px_rgba(135,206,235,0.6)]"
                style={{ animationDelay: '2s' }}
              />
            </div>
          </div>
          
          {/* Title with enhanced glow */}
          <h1 
            className="text-5xl md:text-8xl font-black mb-3 animate-title-glow"
            style={{ 
              textShadow: '0 0 30px #ff8c00, 0 0 60px #ff4500, 0 0 90px #ff6347',
              background: 'linear-gradient(135deg, #ff8c00, #ff4500, #ff6347)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            {t('title.halloween', lang)}
          </h1>
          <h2 
            className="text-3xl md:text-6xl font-bold mb-6 animate-title-glow"
            style={{ 
              textShadow: '0 0 20px #9370db, 0 0 40px #8a2be2',
              animationDelay: '0.5s',
            }}
          >
            <span className="text-purple-300">{t('title.monsters', lang)}</span>
          </h2>
          <p className="text-green-400 text-lg md:text-xl mb-8 italic animate-fade-in" style={{ animationDelay: '1s' }}>
            {t('title.subtitle', lang)}
          </p>
        </div>

        {/* Start Button - Enhanced */}
        <button
          onClick={startNewGame}
          className="group relative w-72 md:w-80 px-8 py-5 mb-6 text-2xl md:text-3xl font-black text-white rounded-2xl shadow-2xl transition-all duration-300 hover:scale-110 animate-fade-in-up overflow-hidden"
          style={{ animationDelay: '1.2s' }}
        >
          {/* Button background with gradient */}
          <div className="absolute inset-0 bg-gradient-to-r from-orange-600 via-red-600 to-orange-700 group-hover:from-orange-500 group-hover:via-red-500 group-hover:to-orange-600 transition-all duration-300" />
          
          {/* Animated border glow */}
          <div className="absolute inset-0 rounded-2xl border-4 border-orange-400 group-hover:border-orange-300 transition-all duration-300" style={{ boxShadow: '0 0 30px rgba(255, 140, 0, 0.6), inset 0 0 20px rgba(255, 140, 0, 0.3)' }} />
          
          {/* Shine effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
          
          <span className="relative z-10 flex items-center justify-center gap-3">
            <PlayIcon size={34} />
            <span>{t('title.start', lang)}</span>
          </span>
        </button>
        
        {/* Menu Buttons Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4 w-full max-w-4xl mb-6 animate-fade-in-up" style={{ animationDelay: '1.4s' }}>
          {([
            {
              key: 'meta_shop',
              gradient: 'from-purple-600 to-purple-900 group-hover:from-purple-500 group-hover:to-purple-800',
              border: 'border-purple-400 group-hover:border-purple-300',
              glow: 'rgba(147, 112, 219, 0.5)',
              icon: <ShopIcon size={30} />,
              label: t('title.meta_shop', lang),
              badge: 0,
              onClick: () => setGameState(prev => ({ ...prev, phase: 'meta_shop' })),
            },
            {
              key: 'daily_objectives',
              gradient: 'from-blue-600 to-blue-900 group-hover:from-blue-500 group-hover:to-blue-800',
              border: 'border-blue-400 group-hover:border-blue-300',
              glow: 'rgba(59, 130, 246, 0.5)',
              icon: <TargetIcon size={30} />,
              label: t('title.daily_objectives', lang),
              badge: [
                ...persistentData.dailyObjectives,
                ...persistentData.weeklyObjectives,
                ...persistentData.monthlyObjectives,
              ].filter(obj => obj.completed && !obj.claimed).length,
              onClick: () => {
                setChallengeTab('daily');
                setGameState(prev => ({ ...prev, phase: 'daily_objectives' }));
              },
            },
            {
              key: 'achievements',
              gradient: 'from-yellow-600 to-yellow-900 group-hover:from-yellow-500 group-hover:to-yellow-800',
              border: 'border-yellow-400 group-hover:border-yellow-300',
              glow: 'rgba(234, 179, 8, 0.5)',
              icon: <TrophyIcon size={30} />,
              label: t('title.achievements', lang),
              badge: persistentData.achievements.filter(ach => ach.unlocked && !ach.claimed).length,
              onClick: () => setGameState(prev => ({ ...prev, phase: 'achievements' })),
            },
            {
              key: 'statistics',
              gradient: 'from-cyan-600 to-cyan-900 group-hover:from-cyan-500 group-hover:to-cyan-800',
              border: 'border-cyan-400 group-hover:border-cyan-300',
              glow: 'rgba(6, 182, 212, 0.5)',
              icon: <ChartIcon size={30} />,
              label: t('title.statistics', lang),
              badge: 0,
              onClick: () => setGameState(prev => ({ ...prev, phase: 'statistics' })),
            },
            {
              key: 'settings',
              gradient: 'from-gray-600 to-gray-900 group-hover:from-gray-500 group-hover:to-gray-800',
              border: 'border-gray-400 group-hover:border-gray-300',
              glow: 'rgba(156, 163, 175, 0.5)',
              icon: <GearIcon size={30} />,
              label: t('title.settings', lang),
              badge: 0,
              onClick: () => setGameState(prev => ({ ...prev, phase: 'settings' })),
            },
          ]).map((btn) => (
            <button
              key={btn.key}
              onClick={btn.onClick}
              className="group relative px-3 py-3 min-h-[64px] text-base md:text-lg font-bold text-white rounded-xl shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/80 overflow-hidden touch-manipulation"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${btn.gradient} transition-all`} />
              <div className={`absolute inset-0 rounded-xl border-2 ${btn.border} transition-all`} style={{ boxShadow: `0 0 20px ${btn.glow}` }} />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
              <span className="relative z-10 flex flex-col items-center justify-center gap-1.5">
                <span className="flex items-center justify-center w-11 h-11 rounded-full bg-black/30 border border-white/20 shadow-inner">
                  {btn.icon}
                </span>
                <span className="text-xs md:text-sm leading-tight">{btn.label}</span>
              </span>
              {btn.badge > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full min-w-[22px] h-[22px] px-1 flex items-center justify-center animate-pulse border-2 border-red-300 z-20">
                  {btn.badge}
                </span>
              )}
            </button>
          ))}
        </div>
        
        {/* Stats Card - Enhanced */}
        <div className="relative w-full max-w-md mb-6 animate-fade-in-up" style={{ animationDelay: '1.6s' }}>
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/30 via-orange-600/30 to-purple-600/30 rounded-2xl blur-xl animate-pulse-slow" />
          <div className="relative bg-black/60 backdrop-blur-sm rounded-2xl px-6 py-4 border-2 border-purple-500/50 shadow-2xl">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <CoinIcon size={30} />
                <span className="text-yellow-400 font-black text-2xl">{persistentData.cursedCoins}</span>
              </div>
              <div className="text-right">
                <p className="text-gray-400 text-xs">{t('title.cursed_coins', lang)}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="bg-purple-900/40 rounded-lg px-3 py-2 border border-purple-600/50">
                <p className="text-gray-400 text-xs">{t('title.total_runs', lang)}</p>
                <p className="text-white font-bold text-lg">{persistentData.totalRuns}</p>
              </div>
              <div className="bg-orange-900/40 rounded-lg px-3 py-2 border border-orange-600/50">
                <p className="text-gray-400 text-xs">{t('title.best_wave', lang)}</p>
                <p className="text-white font-bold text-lg">{persistentData.bestWave}</p>
              </div>
            </div>
            {persistentData.loginStreak > 0 && (
              <div className="mt-2 text-center">
                <p className="text-orange-400 text-sm font-bold">🔥 {persistentData.loginStreak} {t('title.login_streak', lang)}</p>
              </div>
            )}
          </div>
        </div>

        {/* Pulsante Monete Gratis (pubblicita' premiata) */}
        {(() => {
          const adCoinsLeft = getAdCoinsLeft(persistentData);
          return (
            <button
              onClick={watchAdForCoins}
              disabled={adCoinsLeft <= 0}
              className="group relative w-full max-w-md mb-6 px-6 py-4 rounded-2xl font-black text-white shadow-2xl transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 overflow-hidden animate-fade-in-up"
              style={{ animationDelay: '1.7s' }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-600 via-amber-500 to-yellow-600 group-hover:from-yellow-500 group-hover:via-amber-400 group-hover:to-yellow-500 transition-all duration-300" />
              <div className="absolute inset-0 rounded-2xl border-2 border-yellow-300 group-hover:border-yellow-200 transition-all" style={{ boxShadow: '0 0 25px rgba(234, 179, 8, 0.5)' }} />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              <span className="relative z-10 flex items-center justify-center gap-3">
                <FilmIcon size={32} />
                <span className="flex flex-col items-start leading-tight">
                  <span className="text-base md:text-lg flex items-center gap-1.5">{t('title.free_coins', lang)} · <CoinIcon size={20} /> +{AD_COINS_REWARD}</span>
                  <span className="text-xs font-bold text-yellow-100/90">
                    {adCoinsLeft > 0 ? `${adCoinsLeft}/${AD_COINS_DAILY_LIMIT} ${t('ad.coins_left', lang)}` : t('ad.coins_limit', lang)}
                  </span>
                </span>
              </span>
            </button>
          );
        })()}
        
        {/* Description and Warning */}
        <div className="text-center max-w-lg mb-6 animate-fade-in" style={{ animationDelay: '1.8s' }}>
          <p className="text-purple-300 text-sm md:text-base mb-2">{t('title.description', lang)}</p>
          <p className="text-red-400 text-xs md:text-sm italic">{t('title.warning', lang)}</p>
        </div>
        
        {/* Halloween Icons Row */}
        <div className="flex gap-4 md:gap-6 text-3xl md:text-4xl animate-fade-in" style={{ animationDelay: '2s' }}>
          <span className="animate-float-slow">💀</span>
          <span className="animate-float-slow" style={{ animationDelay: '0.5s' }}>🧛</span>
          <span className="animate-float-slow" style={{ animationDelay: '1s' }}>👻</span>
          <span className="animate-float-slow" style={{ animationDelay: '1.5s' }}>🕷️</span>
          <span className="animate-float-slow" style={{ animationDelay: '2s' }}>🦇</span>
          <span className="animate-float-slow" style={{ animationDelay: '2.5s' }}>⚰️</span>
        </div>
      </div>
    </div>
  );

  const renderStarterSelect = () => {
    // Barre statistiche normalizzate rispetto al migliore dei 3 starter mostrati
    const maxStat = {
      hp: Math.max(...selectedStarters.map(m => m.stats.maxHp), 1),
      atk: Math.max(...selectedStarters.map(m => m.stats.attack), 1),
      def: Math.max(...selectedStarters.map(m => m.stats.defense), 1),
      spd: Math.max(...selectedStarters.map(m => m.stats.speed), 1),
    };
    const statBars = (m: Monster) => ([
      { label: t('starter.hp', lang), value: m.stats.maxHp, max: maxStat.hp, color: '#4ade80' },
      { label: t('starter.atk', lang), value: m.stats.attack, max: maxStat.atk, color: '#f87171' },
      { label: t('starter.def', lang), value: m.stats.defense, max: maxStat.def, color: '#60a5fa' },
      { label: t('starter.spd', lang), value: m.stats.speed, max: maxStat.spd, color: '#facc15' },
    ]);
    // Bonus run attivi dai potenziamenti del Meta Negozio
    const activeBonuses = persistentData.upgrades.filter(u => u.purchased || (u.currentLevel || 0) > 0);

    return (
      <div className="relative flex flex-col items-center justify-center min-h-screen overflow-hidden bg-gradient-to-b from-purple-950 via-gray-900 to-black p-4">
        {/* Particelle fluttuanti */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {particles.map((particle, i) => (
            <div
              key={i}
              className="absolute animate-float-particle"
              style={{ left: `${particle.left}%`, top: `${particle.top}%`, animationDelay: `${particle.delay}s`, animationDuration: `${particle.duration}s` }}
            >
              <div className="w-1 h-1 bg-purple-400/30 rounded-full" />
            </div>
          ))}
        </div>
        <div className="absolute top-10 left-10 w-32 h-32 bg-purple-600/15 rounded-full blur-3xl animate-pulse-slow pointer-events-none" />
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-orange-600/15 rounded-full blur-3xl animate-pulse-slow pointer-events-none" style={{ animationDelay: '2s' }} />

        <div className="relative z-10 flex flex-col items-center w-full max-w-5xl">
          <h2 className="text-2xl md:text-4xl font-black text-orange-400 mb-2 text-center px-4 animate-fade-in-down" style={{ textShadow: '0 0 20px rgba(255,140,0,0.5)' }}>
            {t('starter.title', lang)}
          </h2>
          <p className="text-purple-300 mb-4 md:mb-6 text-center px-4 text-sm md:text-base animate-fade-in" style={{ animationDelay: '0.2s' }}>
            {t('starter.description', lang)}
          </p>

          {activeBonuses.length > 0 && (
            <div className="mb-4 md:mb-6 px-4 py-2 bg-purple-900/40 border border-purple-600/60 rounded-full text-xs md:text-sm text-purple-200 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              ✨ {activeBonuses.length} {t('starter.run_bonuses', lang)}: {activeBonuses.map(u => u.emoji).join(' ')}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 w-full px-2">
            {selectedStarters.map((monster, idx) => (
              <button
                key={monster.id}
                onClick={() => selectStarter(idx)}
                className="p-4 md:p-6 rounded-2xl border-2 transition-all duration-300 hover:scale-105 group animate-fade-in-up"
                style={{
                  borderColor: typeColors[monster.type],
                  background: `linear-gradient(160deg, ${typeColors[monster.type]}33, #1a0a2e 70%)`,
                  boxShadow: `0 0 25px ${typeColors[monster.type]}55`,
                  animationDelay: `${0.35 + idx * 0.15}s`,
                }}
              >
                <div className="mb-2 flex justify-center transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-1">
                  <MonsterIcon monsterId={monster.id} emoji={monster.emoji} size="xl" />
                </div>
                <h3 className="text-lg md:text-xl font-black text-white mb-2">{tMonster(monster.id, lang)}</h3>
                <span className="inline-block px-3 py-1 rounded-full text-xs md:text-sm font-bold mb-3" style={{ background: typeColors[monster.type], color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,0.9)', boxShadow: `0 0 12px ${typeColors[monster.type]}88` }}>
                  {typeEmojis[monster.type]} {tType(monster.type, lang)}
                </span>
                <div className="space-y-1.5 mt-2">
                  {statBars(monster).map(s => (
                    <div key={s.label} className="flex items-center gap-2 text-xs">
                      <span className="w-8 text-left font-bold" style={{ color: s.color }}>{s.label}</span>
                      <div className="flex-1 h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${Math.max(12, (s.value / s.max) * 100)}%`, background: s.color }} />
                      </div>
                      <span className="w-7 text-right text-gray-300 font-bold">{s.value}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 text-xs text-yellow-300 bg-yellow-900/20 rounded-lg p-2 border border-yellow-700/40">
                  <p className="font-bold">✨ {tAbilityName(monster.ability, lang)}</p>
                  <p className="text-gray-400">{tAbilityDesc(monster.ability, lang)}</p>
                </div>
                <div className="mt-2 text-xs text-purple-300">
                  {monster.moves?.map(m => <p key={m.id}>• {tMove(m.id, lang)}</p>) || []}
                </div>
              </button>
            ))}
          </div>

          <button
            onClick={startNewGame}
            className="mt-5 md:mt-7 px-6 py-3 bg-purple-800/70 hover:bg-purple-700 text-purple-100 font-bold rounded-xl border-2 border-purple-500 transition-all hover:scale-105 animate-fade-in-up"
            style={{ animationDelay: '0.8s' }}
          >
            {t('starter.reroll', lang)}
          </button>
        </div>
      </div>
    );
  };

  const renderMap = () => {
    const completedCount = gameState.map.filter(n => n.completed).length;
    const totalNodes = gameState.map.length || 10;

    // Stile dei tipi di nodo: colore, gradiente e icona
    const nodeStyle: Record<MapNodeType, { emoji: string; ring: string; bg: string; text: string; glow: string }> = {
      wild:       { emoji: '👻', ring: 'border-violet-400',  bg: 'from-violet-600 to-purple-900',  text: 'text-violet-300', glow: 'rgba(167,139,250,0.55)' },
      trainer:    { emoji: '🧙', ring: 'border-sky-400',     bg: 'from-sky-600 to-blue-900',       text: 'text-sky-300',    glow: 'rgba(56,189,248,0.55)' },
      shop:       { emoji: '🏪', ring: 'border-emerald-400', bg: 'from-emerald-600 to-green-900',  text: 'text-emerald-300',glow: 'rgba(52,211,153,0.55)' },
      event:      { emoji: '❓', ring: 'border-fuchsia-400', bg: 'from-fuchsia-600 to-purple-900', text: 'text-fuchsia-300',glow: 'rgba(232,121,249,0.55)' },
      gym_leader: { emoji: '⚔️', ring: 'border-amber-400',   bg: 'from-orange-600 to-red-900',     text: 'text-amber-300',  glow: 'rgba(251,146,60,0.7)' },
    };

    const hpColor = (hp: number, maxHp: number) => {
      const r = maxHp > 0 ? hp / maxHp : 0;
      return r > 0.5 ? '#22c55e' : r > 0.2 ? '#eab308' : '#ef4444';
    };

    const renderNode = (node: MapNode, rowIdx: number) => {
      const idx = gameState.map.indexOf(node);
      const st = nodeStyle[node.type];
      const canAccess = gameState.currentNode < 0 ? idx === 0 : (gameState.map[gameState.currentNode]?.connections?.includes(idx) || false);
      const isAccessible = canAccess && !node.completed;
      const isCurrent = idx === gameState.currentNode;
      const isGym = node.type === 'gym_leader';

      return (
        <button
          key={node.id}
          onClick={() => isAccessible && handleNodeClick(idx)}
          disabled={!isAccessible}
          className={`relative flex flex-col items-center gap-1 group ${isAccessible ? 'cursor-pointer' : 'cursor-default'}`}
          style={{ animationDelay: `${0.05 * idx + 0.15 * rowIdx}s` }}
        >
          {/* Medaglione del nodo */}
          <span
            className={`relative flex items-center justify-center rounded-full border-2 transition-all duration-300 ${
              isGym ? 'w-14 h-14 md:w-[72px] md:h-[72px] text-2xl md:text-3xl' : 'w-12 h-12 md:w-16 md:h-16 text-xl md:text-2xl'
            } ${
              node.completed
                ? 'border-green-500/60 bg-gradient-to-b from-gray-700 to-gray-900 opacity-70'
                : isAccessible
                ? `${st.ring} bg-gradient-to-b ${st.bg} animate-node-pulse group-hover:scale-110 group-active:scale-95`
                : 'border-gray-700 bg-gradient-to-b from-gray-800 to-gray-950 opacity-40 grayscale'
            }`}
            style={!node.completed && isAccessible ? { boxShadow: `0 0 18px ${st.glow}` } : undefined}
          >
            <span className="emoji">{st.emoji}</span>
            {node.completed && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-green-500 border-2 border-green-200 text-white text-[10px] font-black flex items-center justify-center shadow">✓</span>
            )}
            {isCurrent && (
              <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-orange-400 text-xs animate-bounce" aria-hidden="true">📍</span>
            )}
          </span>
          <span className={`text-[10px] md:text-xs font-bold leading-none ${node.completed ? 'text-green-400/80' : isAccessible ? st.text : 'text-gray-600'}`}>
            {t(`map.${node.type}`, lang)}
          </span>
        </button>
      );
    };

    // Percorso a serpentina: riga alta 0-4 (sx->dx), riga bassa 9-5 (dx->sx)
    const rowTop = gameState.map.slice(0, 5);
    const rowBottom = gameState.map.slice(5, 10).slice().reverse();

    return (
      <div className="min-h-screen relative overflow-hidden bg-gradient-to-b from-[#1a0b2e] via-[#0d0618] to-black">
        {/* Sfondo animato: luna, pipistrelli, particelle, orbe */}
        <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
          <div className="battle-moon" />
          <span className="battle-bat" style={{ top: '12%', left: '8%', animationDelay: '0s' }}>🦇</span>
          <span className="battle-bat battle-bat-sm" style={{ top: '22%', right: '30%', animationDelay: '2s' }}>🦇</span>
          {particles.map((particle, i) => (
            <div
              key={i}
              className="absolute animate-float-particle"
              style={{ left: `${particle.left}%`, top: `${particle.top}%`, animationDelay: `${particle.delay}s`, animationDuration: `${particle.duration}s` }}
            >
              <div className="w-1 h-1 bg-purple-400/30 rounded-full" />
            </div>
          ))}
          <div className="absolute top-1/3 -left-10 w-40 h-40 bg-purple-600/15 rounded-full blur-3xl animate-pulse-slow" />
          <div className="absolute bottom-10 -right-10 w-48 h-48 bg-orange-600/10 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto p-3 md:p-6">
          {/* Header ondata */}
          <div className="text-center mb-4 md:mb-6 animate-fade-in-down">
            <h2
              className="text-4xl md:text-6xl font-black tracking-wide"
              style={{
                background: 'linear-gradient(135deg, #fb923c, #f97316, #c026d3)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                filter: 'drop-shadow(0 0 18px rgba(249,115,22,0.45))',
              }}
            >
              🌊 {t('map.wave', lang)} {gameState.currentWave}
            </h2>
            {/* Progresso nodi della wave */}
            <div className="max-w-md mx-auto mt-2 md:mt-3">
              <div className="h-2.5 md:h-3 bg-gray-900/80 rounded-full overflow-hidden border border-purple-700/50 shadow-inner">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-orange-500 via-amber-400 to-purple-500 transition-all duration-700"
                  style={{ width: `${totalNodes > 0 ? (completedCount / totalNodes) * 100 : 0}%` }}
                />
              </div>
              <p className="text-purple-300/80 text-[11px] md:text-xs mt-1 font-bold">
                {completedCount}/{totalNodes} · {t('map.nodes_completed', lang)}
              </p>
            </div>
          </div>

          {/* Risorse: dolcetti e medaglie */}
          <div className="flex justify-center gap-2 md:gap-3 mb-4 md:mb-5 animate-fade-in">
            <span className="inline-flex items-center gap-1.5 px-3 md:px-4 py-1.5 rounded-full bg-amber-950/70 border border-amber-500/50 text-amber-300 font-bold text-sm md:text-base shadow-lg shadow-amber-900/40">
              🍬 {gameState.candies} <span className="hidden md:inline font-normal text-amber-200/80 text-xs">{t('map.candies', lang)}</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 md:px-4 py-1.5 rounded-full bg-indigo-950/70 border border-indigo-500/50 text-indigo-300 font-bold text-sm md:text-base shadow-lg shadow-indigo-900/40">
              🏅 {gameState.medals.length} <span className="hidden md:inline font-normal text-indigo-200/80 text-xs">{t('map.medals', lang)}</span>
            </span>
          </div>

          {/* Squadra */}
          <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-3 md:p-4 mb-4 md:mb-5 border border-purple-700/50 shadow-xl shadow-purple-950/40 animate-fade-in-up">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs md:text-sm text-purple-300 font-black tracking-widest uppercase">🧟 {t('map.team', lang)}</span>
              <button
                onClick={() => setShowTeamOrder(!showTeamOrder)}
                className="text-xs px-3 py-1.5 min-h-[36px] bg-purple-700/80 text-white rounded-lg hover:bg-purple-600 active:scale-95 transition-all border border-purple-500/50 font-bold touch-manipulation"
              >
                {showTeamOrder ? `✓ ${t('map.done', lang)}` : `↕️ ${t('map.order', lang)}`}
              </button>
            </div>

            {showTeamOrder ? (
              <div className="space-y-2">
                {gameState.team.map((m, i) => (
                  <div key={i} className="flex items-center gap-2 bg-purple-900/40 rounded-xl px-3 py-2 border border-purple-700/40">
                    <span className="text-orange-400 font-black text-sm w-5">{i + 1}.</span>
                    <MonsterIcon monsterId={m.id} emoji={m.emoji} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-white font-bold truncate">{tMonster(m.id, lang)} Lv.{m.level}</div>
                      <div className="w-24 h-2 bg-gray-800 rounded-full overflow-hidden mt-0.5 border border-gray-700">
                        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${m.stats.maxHp > 0 ? (m.stats.hp / m.stats.maxHp) * 100 : 0}%`, background: hpColor(m.stats.hp, m.stats.maxHp) }} />
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <button
                        onClick={() => moveMonsterUp(i)}
                        disabled={i === 0}
                        className="text-xs px-2 py-1 min-w-[36px] min-h-[32px] bg-blue-700 text-white rounded-lg hover:bg-blue-600 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed touch-manipulation"
                      >
                        ▲
                      </button>
                      <button
                        onClick={() => moveMonsterDown(i)}
                        disabled={i === gameState.team.length - 1}
                        className="text-xs px-2 py-1 min-w-[36px] min-h-[32px] bg-blue-700 text-white rounded-lg hover:bg-blue-600 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed touch-manipulation"
                      >
                        ▼
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex gap-2 flex-wrap">
                {gameState.team.map((m, i) => (
                  <div key={i} className={`flex items-center gap-1.5 rounded-xl pl-1.5 pr-2.5 py-1.5 border transition-all ${m.stats.hp <= 0 ? 'bg-gray-900/60 border-gray-700 opacity-50' : 'bg-purple-900/40 border-purple-700/50 hover:border-purple-500'}`}>
                    <MonsterIcon monsterId={m.id} emoji={m.emoji} size="sm" />
                    <div className="min-w-0">
                      <div className="text-[11px] md:text-xs text-white font-bold leading-tight truncate max-w-[90px] md:max-w-none">{tMonster(m.id, lang)} <span className="text-purple-300/80 font-normal">Lv.{m.level}</span></div>
                      <div className="w-16 md:w-20 h-1.5 bg-gray-800 rounded-full overflow-hidden border border-gray-700/60">
                        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${m.stats.maxHp > 0 ? (m.stats.hp / m.stats.maxHp) * 100 : 0}%`, background: hpColor(m.stats.hp, m.stats.maxHp) }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Percorso della wave */}
          <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-4 md:p-6 border border-purple-700/50 shadow-xl shadow-purple-950/40 animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
            <h3 className="text-base md:text-xl font-black text-center mb-4 md:mb-6 tracking-wide">
              <span
                style={{
                  background: 'linear-gradient(90deg, #c084fc, #fb923c)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}
              >
                🗺️ {t('map.title', lang)}
              </span>
            </h3>

            <div className="relative">
              {/* Riga alta: nodi 0 -> 4 */}
              <div className="flex items-center">
                {rowTop.map((node, i) => (
                  <div key={node.id} className="contents">
                    {renderNode(node, 0)}
                    {i < rowTop.length - 1 && (
                      <div className={`flex-1 h-0.5 md:h-1 mx-0.5 rounded-full ${node.completed ? 'bg-gradient-to-r from-green-500/70 to-green-400/40' : 'bg-purple-800/40'}`} />
                    )}
                  </div>
                ))}
              </div>
              {/* Connettore verticale a destra tra le due righe */}
              <div className="flex justify-end pr-6 md:pr-8">
                <div className={`w-0.5 md:w-1 h-5 md:h-7 rounded-full ${rowTop.length > 0 && rowTop[rowTop.length - 1].completed ? 'bg-green-500/60' : 'bg-purple-800/40'}`} />
              </div>
              {/* Riga bassa: nodi 9 -> 5 (serpentina) */}
              <div className="flex items-center">
                {rowBottom.map((node, i) => (
                  <div key={node.id} className="contents">
                    {renderNode(node, 1)}
                    {i < rowBottom.length - 1 && (
                      <div className={`flex-1 h-0.5 md:h-1 mx-0.5 rounded-full ${node.completed ? 'bg-gradient-to-l from-green-500/70 to-green-400/40' : 'bg-purple-800/40'}`} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Inventario */}
          {gameState.items.some(i => i.quantity > 0) && (
            <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-3 md:p-4 mt-4 md:mt-5 border border-purple-700/50 shadow-xl shadow-purple-950/40 animate-fade-in-up" style={{ animationDelay: '0.25s' }}>
              <h4 className="text-xs md:text-sm font-black text-purple-300 mb-2 tracking-widest uppercase">🎒 {t('map.inventory', lang)}</h4>
              <div className="flex flex-wrap gap-1.5 md:gap-2">
                {gameState.items.filter(i => i.quantity > 0).map(item => (
                  <span key={item.id} className="bg-purple-900/50 border border-purple-700/40 rounded-full px-2.5 py-1 text-[11px] md:text-xs text-gray-200 inline-flex items-center gap-1">
                    <span className="emoji">{item.emoji}</span> {tItem(item.id, lang)} <span className="text-yellow-400 font-bold">×{item.quantity}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Cura squadra */}
          <div className="mt-4 md:mt-6 text-center animate-fade-in-up" style={{ animationDelay: '0.35s' }}>
            <button
              onClick={healTeam}
              disabled={gameState.healsUsed >= 2}
              className="group relative px-6 md:px-8 py-3 min-h-[48px] bg-gradient-to-b from-green-600 to-emerald-800 text-white rounded-2xl font-black text-sm md:text-base border-2 border-green-400/70 shadow-lg shadow-green-900/50 hover:scale-105 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100 overflow-hidden touch-manipulation"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/15 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
              <span className="relative">💚 {t('map.heal', lang)} <span className="text-green-200/80">({gameState.healsUsed}/2)</span></span>
            </button>
          </div>
        </div>
        {renderMoveChoiceModal()}
      </div>
    );
  };

  const renderBattle = () => {
    const playerMonster = gameState.team?.[gameState.selectedMonsterIndex];
    const activeEnemy = gameState.battleEnemies?.[gameState.activeEnemyIndex];
    const otherAliveEnemies = (gameState.battleEnemies || []).filter((e, idx) => idx !== gameState.activeEnemyIndex && e.stats.hp > 0);

    // Controlla se il mostro del giocatore è valido
    if (!playerMonster) {
      return (
        <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-purple-950 to-black p-4 flex items-center justify-center">
          <div className="text-center">
            <p className="text-red-400 text-xl mb-4">{t('battle.no_active_error', lang)}</p>
            <button onClick={returnToMap} className="px-6 py-3 bg-orange-700 text-white rounded-lg hover:bg-orange-600 font-bold">
              {t('battle.return_map', lang)}
            </button>
          </div>
        </div>
      );
    }

    const hpColor = (hp: number, maxHp: number) => {
      const ratio = maxHp > 0 ? hp / maxHp : 0;
      return ratio > 0.5 ? '#22c55e' : ratio > 0.2 ? '#eab308' : '#ef4444';
    };

    return (
      <div className={`min-h-[100dvh] relative ${shake && screenShakeEnabled ? 'animate-screen-shake' : ''}`} style={shake && screenShakeEnabled ? { transform: `translate(${Math.random() * intensity - intensity/2}px, ${Math.random() * intensity - intensity/2}px)` } : {}}>
        {/* Sfondo notte di Halloween: luna, pipistrelli e nebbia */}
        <div className="battle-halloween-bg" aria-hidden="true">
          <div className="battle-moon" />
          <span className="battle-bat" style={{ top: '10%', left: '6%', animationDelay: '0s' }}>🦇</span>
          <span className="battle-bat" style={{ top: '18%', right: '28%', animationDelay: '1.4s' }}>🦇</span>
          <span className="battle-bat battle-bat-sm" style={{ top: '6%', left: '42%', animationDelay: '2.6s' }}>🦇</span>
          <span className="battle-bat battle-bat-sm" style={{ top: '26%', left: '20%', animationDelay: '4s' }}>🦇</span>
          <div className="battle-fog battle-fog-1" />
          <div className="battle-fog battle-fog-2" />
        </div>

        <div className="max-w-4xl mx-auto relative z-10 p-2 md:p-4 pb-4">
          {/* Battle Animations Overlay */}
          {battleEffects && (
            <>
              <BattleAnimation type={playerAnimation} moveType={playerMoveType} isPlayer={true} />
              <BattleAnimation type={enemyAnimation} moveType={enemyMoveType} isPlayer={false} />
            </>
          )}

          {/* Banner meteo */}
          {weather !== 'normale' && (
            <div className="text-center mb-2 animate-fade-in-down">
              <span className="inline-block bg-purple-950/90 px-3 md:px-4 py-1.5 rounded-full border border-purple-500/60 text-xs md:text-sm text-purple-100 shadow-lg shadow-purple-900/50">
                {weatherInfo[weather].emoji} {t(`weather.${weather}`, lang)}
                <span className="text-purple-300/80 ml-2 text-xs">{t(`weather.${weather === 'luna_piena' ? 'spettro_boost' : weather === 'nebbia' ? 'precision_down' : 'buio_spettro_boost'}`, lang)}</span>
              </span>
            </div>
          )}

          {/* Arena di battaglia */}
          <div className="battle-arena mb-2 md:mb-3">
            {/* Nemico: in alto a sinistra la scheda, a destra il mostro */}
            {activeEnemy && activeEnemy.stats.hp > 0 && (
              <div className="flex items-center gap-2 md:gap-6 mb-3 md:mb-5">
                <div className="battle-info-card flex-1 max-w-[60%] md:max-w-xs">
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-white font-bold text-xs md:text-sm truncate">{tMonster(activeEnemy.id, lang)} <span className="text-purple-300/70 text-xs font-normal">Lv.{activeEnemy.level}</span></span>
                    <span className="text-sm md:text-base shrink-0" style={{ color: typeColors[activeEnemy.type] }}>{typeEmojis[activeEnemy.type]}</span>
                  </div>
                  <div className="battle-hp-track mt-1.5">
                    <div
                      className="battle-hp-fill"
                      style={{
                        width: `${activeEnemy.stats.maxHp > 0 ? (activeEnemy.stats.hp / activeEnemy.stats.maxHp) * 100 : 0}%`,
                        background: hpColor(activeEnemy.stats.hp, activeEnemy.stats.maxHp),
                        color: hpColor(activeEnemy.stats.hp, activeEnemy.stats.maxHp),
                      }}
                    />
                  </div>
                  <div className="text-xs text-gray-400 mt-0.5">{activeEnemy.stats.hp}/{activeEnemy.stats.maxHp} HP</div>
                  {activeEnemy.status.length > 0 && (
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {activeEnemy.status.map(s => (
                        <span key={s} className="text-xs bg-red-900/60 border border-red-700/50 px-1.5 py-0.5 rounded text-red-300">{getStatusName(s)}</span>
                      ))}
                    </div>
                  )}
                </div>
                {/* Altri nemici vivi in attesa */}
                {otherAliveEnemies.length > 0 && (
                  <div className="flex flex-col gap-1">
                    {otherAliveEnemies.map((e, i) => (
                      <div key={i} className="opacity-70 scale-75 origin-center" title={tMonster(e.id, lang)}>
                        <MonsterIcon monsterId={e.id} emoji={e.emoji} size="sm" />
                      </div>
                    ))}
                  </div>
                )}
                <div className={`relative ml-auto transition-all duration-300 ${
                  animationsEnabled ? (
                    enemyAnimation === 'attack' ? 'animate-monster-attack-left' :
                    enemyAnimation === 'hit' ? 'animate-monster-hit' :
                    enemyAnimation === 'death' ? 'animate-monster-faint' : 'animate-float-slow'
                  ) : ''
                }`}>
                  <div className="battle-pedestal" />
                  <div className="battle-monster-glow" style={{ ['--type-glow' as any]: `${typeColors[activeEnemy.type]}88` }}>
                    <MonsterIcon monsterId={activeEnemy.id} emoji={activeEnemy.emoji} size="lg" className="md:scale-125" />
                  </div>
                </div>
              </div>
            )}

            {/* Separatore spettrale */}
            <div className="flex items-center gap-2 my-1 md:my-2 opacity-60" aria-hidden="true">
              <div className="flex-1 h-px bg-gradient-to-r from-transparent via-purple-500/60 to-transparent" />
              <span className="text-orange-400/80 text-sm">🎃</span>
              <div className="flex-1 h-px bg-gradient-to-r from-transparent via-purple-500/60 to-transparent" />
            </div>

            {/* Giocatore: mostro a sinistra, scheda a destra */}
            <div className="flex items-center gap-2 md:gap-6">
              <div className={`relative transition-all duration-300 ${
                catchAnimation ? 'animate-spin' :
                animationsEnabled ? (
                  playerAnimation === 'attack' ? 'animate-monster-attack' :
                  playerAnimation === 'hit' ? 'animate-monster-hit' :
                  playerAnimation === 'death' ? 'animate-monster-faint' :
                  playerAnimation === 'heal' ? 'animate-heal-particle' : 'animate-float-slow'
                ) : ''
              }`}>
                <div className="battle-pedestal" />
                <div className="battle-monster-glow" style={{ ['--type-glow' as any]: `${typeColors[playerMonster.type]}88` }}>
                  <MonsterIcon monsterId={playerMonster.id} emoji={playerMonster.emoji} size="xl" className="md:scale-110" />
                </div>
              </div>
              <div className="battle-info-card flex-1 max-w-[62%] md:max-w-xs ml-auto">
                <div className="flex justify-between items-center gap-2">
                  <span className="text-sm md:text-base shrink-0" style={{ color: typeColors[playerMonster.type] }}>{typeEmojis[playerMonster.type]}</span>
                  <span className="text-white font-bold text-xs md:text-sm truncate">{tMonster(playerMonster.id, lang)} <span className="text-purple-300/70 text-xs font-normal">Lv.{playerMonster.level}</span></span>
                </div>
                <div className="battle-hp-track mt-1.5">
                  <div
                    className="battle-hp-fill"
                    style={{
                      width: `${playerMonster.stats.maxHp > 0 ? (playerMonster.stats.hp / playerMonster.stats.maxHp) * 100 : 0}%`,
                      background: hpColor(playerMonster.stats.hp, playerMonster.stats.maxHp),
                      color: hpColor(playerMonster.stats.hp, playerMonster.stats.maxHp),
                    }}
                  />
                </div>
                <div className="flex justify-between items-center mt-0.5">
                  <div className="text-xs text-gray-400">{playerMonster.stats.hp}/{playerMonster.stats.maxHp} HP</div>
                </div>
                <div className="w-full h-1 md:h-1.5 bg-gray-900 rounded-full overflow-hidden mt-1 border border-blue-900/50">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-500" style={{ width: `${playerMonster.expToNext > 0 ? (playerMonster.exp / playerMonster.expToNext) * 100 : 0}%` }} />
                </div>
                {playerMonster.status.length > 0 && (
                  <div className="flex gap-1 mt-1 justify-end flex-wrap">
                    {playerMonster.status.map(s => (
                      <span key={s} className="text-xs bg-purple-900/60 border border-purple-700/50 px-1.5 py-0.5 rounded text-purple-300">{getStatusName(s)}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Log di battaglia: pergamena stregata */}
          <div ref={battleLogRef} className="battle-log-scroll p-2 md:p-3 mb-2 md:mb-3 h-24 md:h-28 overflow-y-auto">
            {gameState.battleLog.map((log, idx) => (
              <p key={idx} className={`text-xs md:text-sm mb-1 ${idx === gameState.battleLog.length - 1 ? 'text-purple-100' : 'text-gray-400'}`}>{log}</p>
            ))}
          </div>

          {!gameState.battleOver ? (
            <div className="bg-black/60 rounded-xl p-2 md:p-3 border border-purple-700/60 shadow-lg shadow-purple-950/50">
              {gameState.isPlayerTurn ? (
                <>
                  {!showMoveSelect && !showItemSelect && !showTeamSelect && !forceMonsterSelect && (
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                      <button onClick={() => setShowMoveSelect(true)} className="battle-action-btn bg-gradient-to-b from-red-700 to-red-900 text-xs md:text-base">
                        <span className="text-lg md:text-xl" aria-hidden="true">⚔️</span>
                        {t('battle.attack', lang)}
                      </button>
                      <button onClick={() => setShowItemSelect(true)} className="battle-action-btn bg-gradient-to-b from-blue-700 to-blue-900 text-xs md:text-base">
                        <span className="text-lg md:text-xl" aria-hidden="true">🎒</span>
                        {t('battle.items', lang)}
                      </button>
                      <button onClick={() => setShowTeamSelect(true)} className="battle-action-btn bg-gradient-to-b from-green-700 to-green-900 text-xs md:text-base">
                        <span className="text-lg md:text-xl" aria-hidden="true">🔄</span>
                        {t('battle.switch', lang)}
                      </button>
                      {gameState.battleCatchable ? (
                        <button onClick={() => { setShowItemSelect(true); }} className="battle-action-btn bg-gradient-to-b from-purple-600 to-purple-900 text-xs md:text-base">
                          <span className="text-lg md:text-xl" aria-hidden="true">🎃</span>
                          {t('battle.capture', lang)}
                        </button>
                      ) : (
                        <button disabled className="battle-action-btn bg-gradient-to-b from-gray-700 to-gray-900 text-xs md:text-base">
                          <span className="text-lg md:text-xl" aria-hidden="true">🚫</span>
                          {t('battle.blocked', lang)}
                        </button>
                      )}
                      <button onClick={() => {
                        if (gameState.battleCatchable) {
                          const playerMonster = gameState.team[gameState.selectedMonsterIndex];
                          if (!playerMonster || playerMonster.stats.hp <= 0) {
                            addLog(t('battle.no_active_monster', lang));
                            return;
                          }
                          const playerSpeed = playerMonster.stats.speed;
                          const aliveEnemies = gameState.battleEnemies.filter(e => e.stats.hp > 0);
                          const enemySpeed = aliveEnemies.length > 0 ? (aliveEnemies[0]?.stats.speed || 10) : 10;
                          const escapeChance = Math.max(10, Math.min(90, 50 + (playerSpeed - enemySpeed) * 3));
                          if (Math.random() * 100 < escapeChance) {
                            addLog(t('battle.run_success', lang));
                            const map = deepClone(gameState.map);
                            if (map[gameState.currentNode]) {
                              map[gameState.currentNode].completed = true;
                            }
                            setGameState(prev => ({ ...prev, battleOver: true, battleWon: true, map }));
                          } else {
                            addLog(t('battle.run_fail', lang));
                            setGameState(prev => ({ ...prev, isPlayerTurn: false }));
                            setTimeout(() => enemyTurn(), 800);
                          }
                        } else {
                          addLog(t('battle.cant_escape', lang));
                        }
                      }} className="battle-action-btn bg-gradient-to-b from-amber-600 to-amber-800 text-xs md:text-base col-span-2 md:col-span-1">
                        <span className="text-lg md:text-xl" aria-hidden="true">🏃</span>
                        {t('battle.run', lang)}
                      </button>
                    </div>
                  )}

                  {forceMonsterSelect && (
                    <div className="bg-yellow-900/30 border-2 border-yellow-600 rounded-lg p-3 mb-3">
                      <p className="text-yellow-400 font-bold text-center">⚠️ {t('battle.monster_defeated_choose_another', lang)}</p>
                    </div>
                  )}

                  {showMoveSelect && (
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="text-orange-400 font-bold text-sm md:text-base">{t('battle.choose_move', lang)}</h4>
                        <button onClick={() => setShowMoveSelect(false)} className="text-gray-400 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">✕</button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {playerMonster.moves.map((move, idx) => (
                          <button
                            key={move.id}
                            onClick={() => { useMove(idx); setShowMoveSelect(false); }}
                            disabled={move.pp <= 0}
                            className="p-2 md:p-3 min-h-[48px] rounded-lg text-left transition-all hover:brightness-125 border disabled:opacity-40"
                            style={{
                              background: `${typeColors[move.type]}22`,
                              borderColor: typeColors[move.type],
                            }}
                          >
                            <div className="flex justify-between">
                              <span className="text-white font-bold text-xs md:text-sm">{tMove(move.id, lang)}</span>
                              <span className="text-xs text-gray-400">{move.pp}/{move.maxPp} PP</span>
                            </div>
                            <div className="flex gap-2 mt-1 flex-wrap">
                              <span className="text-xs" style={{ color: typeColors[move.type] }}>{typeEmojis[move.type]} {tType(move.type, lang)}</span>
                              <span className="text-xs text-gray-400">{t('battle.power_short', lang)}: {move.power}</span>
                              <span className="text-xs text-gray-400">{t('battle.acc_short', lang)}: {move.accuracy}%</span>
                            </div>
                            {move.effect && <span className="text-xs text-purple-300">💫 {getStatusName(move.effect)} ({move.effectChance}%)</span>}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {showItemSelect && (
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="text-orange-400 font-bold text-sm md:text-base">{t('battle.use_item', lang)}</h4>
                        <button onClick={() => setShowItemSelect(false)} className="text-gray-400 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">✕</button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {gameState.items.filter(i => i.quantity > 0).map(item => (
                          <button
                            key={item.id}
                            onClick={() => {
                              if (item.category === 'potion') usePotion(item.id);
                              else if (item.category === 'capture') tryCapture(item.id);
                              else if (item.id === 'candela_protettiva') useCandle();
                              else if (item.id === 'nettare_zucca') usePumpkinNectar();
                              else if (item.id === 'pozione_non_morte') useUndeathPotion();
                              else if (item.id === 'cristallo_pp_totale') useTotalPPCrystal();
                              else if (item.id === 'cristallo_pp') {
                                // Show move selection for PP crystal
                                setShowPPMoveSelect(true);
                              }
                              else if (item.id === 'lacrime_banshee') useBansheeTears();
                            }}
                            className="p-2 min-h-[48px] rounded-lg text-left bg-purple-900/50 hover:bg-purple-800/50 border border-purple-700 transition-all"
                          >
                            <span className="text-white text-xs md:text-sm">{item.emoji} {tItem(item.id, lang)}</span>
                            <span className="text-gray-400 text-xs ml-2">x{item.quantity}</span>
                            <p className="text-xs text-gray-400">{tItemDesc(item.id, lang)}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {(showTeamSelect || forceMonsterSelect) && (
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="text-orange-400 font-bold text-sm md:text-base">
                          {forceMonsterSelect ? `⚠️ ${t('battle.choose_monster', lang)}` : t('battle.switch_monster', lang)}
                        </h4>
                        {!forceMonsterSelect && (
                          <button onClick={() => setShowTeamSelect(false)} className="text-gray-400 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">✕</button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {gameState.team.map((m, idx) => (
                          <button
                            key={idx}
                            onClick={() => switchMonster(idx)}
                            disabled={m.stats.hp <= 0 || idx === gameState.selectedMonsterIndex}
                            className={`p-2 min-h-[48px] rounded-lg text-left border transition-all ${
                              m.stats.hp <= 0 ? 'opacity-40 border-gray-700' :
                              idx === gameState.selectedMonsterIndex ? 'border-orange-400 bg-orange-900/30' :
                              'border-purple-700 bg-purple-900/30 hover:bg-purple-800/50'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <MonsterIcon monsterId={m.id} emoji={m.emoji} size="md" />
                              <div>
                                <p className="text-white text-xs md:text-sm font-bold">{tMonster(m.id, lang)} Lv.{m.level}</p>
                                <p className="text-xs text-gray-400">{m.stats.hp}/{m.stats.maxHp} HP</p>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {showPPMoveSelect && (
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="text-orange-400 font-bold text-sm md:text-base">💎 {t('battle.choose_move_restore', lang)}</h4>
                        <button onClick={() => setShowPPMoveSelect(false)} className="text-gray-400 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">✕</button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {gameState.team[gameState.selectedMonsterIndex]?.moves?.map((move, idx) => (
                          <button
                            key={idx}
                            onClick={() => {
                              usePPCrystal(idx);
                              setShowPPMoveSelect(false);
                            }}
                            disabled={move.pp >= move.maxPp}
                            className="p-2 min-h-[48px] rounded-lg text-left border transition-all bg-purple-900/50 hover:bg-purple-800/50 border-purple-700 disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            <div className="flex justify-between items-center">
                              <span className="text-white font-bold text-xs md:text-sm">{tMove(move.id, lang)}</span>
                              <span className="text-xs text-gray-400">{move.pp}/{move.maxPp} PP</span>
                            </div>
                            <div className="flex gap-2 mt-1">
                              <span className="text-xs" style={{ color: typeColors[move.type] }}>{typeEmojis[move.type]} {tType(move.type, lang)}</span>
                              <span className="text-xs text-gray-400">{t('battle.power_short', lang)}: {move.power}</span>
                            </div>
                          </button>
                        )) || []}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center text-yellow-300 py-3 md:py-4 text-sm md:text-base font-bold animate-enemy-turn">
                  👻 {t('battle.enemy_turn', lang)}
                </div>
              )}
            </div>
          ) : (
            <div className="bg-black/60 rounded-xl p-3 md:p-4 border border-purple-700/60 text-center shadow-lg shadow-purple-950/50">
              {gameState.battleWon ? (
                <div className="animate-victory">
                  <p className="text-xl md:text-2xl text-green-400 font-bold mb-2 animate-fade-in animate-title-glow">{t('battle.victory', lang)}</p>
                  <p className="text-yellow-400 mb-3 md:mb-4 text-sm md:text-base animate-fade-in" style={{ animationDelay: '0.2s' }}>+{20 + gameState.currentWave * 5} {t('map.candies', lang)}</p>
                  {gameState.map[gameState.currentNode]?.type === 'gym_leader' && (
                    <p className="text-purple-300 mb-3 md:mb-4 text-sm md:text-base animate-fade-in" style={{ animationDelay: '0.4s' }}>{t('battle.medal', lang)}</p>
                  )}
                  <button onClick={returnToMap} className="px-4 md:px-6 py-2 md:py-3 min-h-[48px] bg-gradient-to-b from-orange-600 to-orange-800 text-white rounded-lg font-bold text-sm md:text-base button-hover-effect animate-fade-in" style={{ animationDelay: '0.6s' }}>
                    {t('battle.return_map', lang)}
                  </button>
                </div>
              ) : (
                <div className="animate-defeat">
                  <p className="text-xl md:text-2xl text-red-400 font-bold mb-2 animate-fade-in">{t('battle.defeat', lang)}</p>
                  <p className="text-gray-400 mb-3 md:mb-4 text-sm md:text-base animate-fade-in" style={{ animationDelay: '0.2s' }}>{t('battle.run_ended', lang)}</p>
                  <button onClick={() => setGameState(prev => ({ ...prev, phase: 'game_over' }))} className="px-4 md:px-6 py-2 md:py-3 min-h-[48px] bg-gradient-to-b from-red-700 to-red-900 text-white rounded-lg font-bold text-sm md:text-base button-hover-effect animate-fade-in" style={{ animationDelay: '0.4s' }}>
                    {t('battle.continue', lang)}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderShop = () => (
    <div className="min-h-screen bg-gradient-to-b from-purple-950 via-gray-900 to-black p-3 md:p-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-black/60 rounded-xl p-4 md:p-6 border border-orange-800">
          <h2 className="text-2xl md:text-3xl font-bold text-orange-400 mb-2 text-center">{t('shop.title', lang)}</h2>
          <p className="text-yellow-400 text-center mb-4 md:mb-6 text-sm md:text-base">{t('map.candies', lang)}: {gameState.candies}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-3">
            {[
              { id: 'pozione_sangue', key: 'potion_blood', cost: 20 },
              { id: 'super_pozione', key: 'super_potion', cost: 50 },
              { id: 'iper_pozione', key: 'iper_potion', cost: 120 },
              { id: 'elisir_spettrale', key: 'elixir', cost: 80 },
              { id: 'candela_protettiva', key: 'candle', cost: 40 },
              { id: 'lacrime_banshee', key: 'banshee_tears', cost: 200 },
              { id: 'frammento_luna', key: 'moon_fragment', cost: 150 },
              { id: 'caramella_stregata', key: 'candy', cost: 15 },
              { id: 'zucca_vuota', key: 'pumpkin', cost: 35 },
              { id: 'bara_antica', key: 'coffin', cost: 70 },
              { id: 'amuleto_maledetto', key: 'cursed_amulet', cost: 150 },
              { id: 'rete_becchino', key: 'gravedigger_net', cost: 250 },
              { id: 'sfera_re_zucche', key: 'pumpkin_king_sphere', cost: 500 },
              { id: 'cristallo_pp', key: 'pp_crystal', cost: 25 },
              { id: 'cristallo_pp_totale', key: 'pp_crystal_total', cost: 60 },
            ].map(item => {
              const inventoryItem = gameState.items.find(entry => entry.id === item.id);
              const potionItem = inventoryItem?.category === 'potion';
              const capacity = potionItem ? getItemStackCapacity(item.id, persistentData.upgrades) : Infinity;
              const full = potionItem && (inventoryItem?.quantity || 0) >= capacity;
              return (
                <button
                  key={item.id}
                  onClick={() => buyItem(item.id, item.cost)}
                  disabled={gameState.candies < item.cost || full}
                  className="p-2 md:p-3 rounded-lg bg-purple-900/50 border border-purple-700 hover:bg-purple-800/50 disabled:opacity-40 transition-all text-left"
                >
                  <p className="text-white font-bold text-xs md:text-sm">{t(`shop.${item.key}`, lang)}</p>
                  <p className="text-xs text-gray-400">{t(`shop.${item.key}_desc`, lang)}</p>
                  {potionItem && <p className="text-xs text-gray-400">{t('shop.stock', lang)}: {inventoryItem?.quantity || 0}/{capacity}</p>}
                  <p className="text-yellow-400 text-xs md:text-sm mt-1">🍬 {item.cost}</p>
                </button>
              );
            })}
          </div>

          <div className="mt-4 md:mt-6 text-center">
            <button onClick={returnToMap} className="px-4 md:px-6 py-2 md:py-3 bg-orange-700 text-white rounded-lg hover:bg-orange-600 font-bold text-sm md:text-base">
              {t('battle.return_map', lang)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderEvent = () => (
    <div className="min-h-screen bg-gradient-to-b from-purple-950 via-gray-900 to-black p-3 md:p-4 flex items-center justify-center">
      <div className="bg-black/60 rounded-xl p-6 md:p-8 border border-purple-800 max-w-md text-center">
        <div className="text-5xl md:text-6xl mb-4">❓</div>
        <p className="text-lg md:text-xl text-purple-200 mb-4 md:mb-6 px-2">
          {gameState.battleLog?.length > 0 ? gameState.battleLog[gameState.battleLog.length - 1] : 'Event completed'}
        </p>
        <button onClick={returnToMap} className="px-4 md:px-6 py-2 md:py-3 bg-orange-700 text-white rounded-lg hover:bg-orange-600 font-bold text-sm md:text-base">
          {t('event.continue', lang)}
        </button>
      </div>
    </div>
  );

  const renderGameOver = () => (
    <div className="min-h-screen bg-gradient-to-b from-red-950 via-black to-purple-950 p-3 md:p-4 flex items-center justify-center">
      <div className="text-center px-4">
        <div className="text-7xl md:text-8xl mb-4">💀</div>
        <h2 className="text-3xl md:text-4xl font-bold text-red-400 mb-4" style={{ textShadow: '0 0 20px #ef4444' }}>
          {t('gameover.title', lang)}
        </h2>
        <p className="text-gray-400 mb-2 text-sm md:text-base">{t('gameover.run_ended', lang)} {gameState.currentWave}</p>
        <p className="text-purple-300 mb-2 text-sm md:text-base">{t('gameover.medals', lang)} {gameState.medals.length} 🏅</p>
        <p className="text-yellow-400 mb-6 md:mb-8 text-sm md:text-base">{t('gameover.candies', lang)} {gameState.candies} 🍬</p>
        <div className="flex flex-col gap-3 items-center">
          <button
            onClick={reviveMonster}
            className="px-6 md:px-8 py-2 md:py-3 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-lg md:text-xl font-bold rounded-lg shadow-lg hover:scale-105 transition-all border-2 border-purple-400 mb-2"
          >
            {t('gameover.revive_ad', lang)}
          </button>
          <button
            onClick={() => setGameState({
              phase: 'title',
              team: [],
              items: deepClone(defaultItems),
              candies: 50,
              cursedCoins: 0,
              medals: [],
              currentWave: 1,
              map: [],
              currentNode: -1,
              battleEnemies: [],
              activeEnemyIndex: 0,
              battleCatchable: false,
              battleLog: [],
              selectedMonsterIndex: 0,
              isPlayerTurn: true,
              battleOver: false,
              battleWon: false,
              healsUsed: 0,
              showAdModal: false,
              adType: null,
              adsToWatch: 0,
              adsWatched: 0,
              persistentData: persistentData,
            })}
            className="px-6 md:px-8 py-2 md:py-3 bg-gradient-to-r from-orange-600 to-red-700 text-white text-lg md:text-xl font-bold rounded-lg shadow-lg hover:scale-105 transition-all border-2 border-orange-400"
          >
            {t('gameover.new_run', lang)}
          </button>
        </div>
        <div className="mt-6 md:mt-8 text-gray-500 text-xs md:text-sm italic px-2">
          {t('gameover.quote', lang)}
        </div>
      </div>
      {renderMoveChoiceModal()}
    </div>
  );

  const renderDailyObjectives = () => {
    const objectives = challengeTab === 'daily'
      ? persistentData.dailyObjectives
      : challengeTab === 'weekly'
        ? persistentData.weeklyObjectives
        : persistentData.monthlyObjectives;
    const titleKey = challengeTab === 'daily'
      ? 'title.daily_objectives'
      : challengeTab === 'weekly'
        ? 'title.weekly_challenges'
        : 'title.monthly_challenges';
    const resetKey = challengeTab === 'daily'
      ? 'objectives.reset_daily'
      : challengeTab === 'weekly'
        ? 'objectives.reset_weekly'
        : 'objectives.reset_monthly';

    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-950 via-gray-900 to-black p-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-black/60 rounded-xl p-6 border-2 border-blue-600">
            <div className="flex justify-between items-center mb-6 gap-3">
              <h2 className="text-2xl md:text-3xl font-bold text-blue-400">🎯 {t(titleKey, lang)}</h2>
              <button
                onClick={() => setGameState(prev => ({ ...prev, phase: 'title' }))}
                className="px-4 py-2 min-h-[44px] bg-gray-700 text-white rounded-lg hover:bg-gray-600"
              >
                ← {t('metashop.back', lang)}
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-5" role="tablist">
              {(['daily', 'weekly', 'monthly'] as ChallengePeriod[]).map(period => (
                <button
                  key={period}
                  role="tab"
                  aria-selected={challengeTab === period}
                  onClick={() => setChallengeTab(period)}
                  className={`px-2 py-3 min-h-[44px] rounded-lg border font-bold text-sm md:text-base transition-colors ${
                    challengeTab === period
                      ? 'bg-blue-700 border-blue-400 text-white'
                      : 'bg-gray-900 border-gray-700 text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  {t(`objectives.tab_${period}`, lang)}
                  {objectives.length > 0 && (
                    <span className="ml-1 text-xs">
                      ({(period === 'daily'
                        ? persistentData.dailyObjectives
                        : period === 'weekly'
                          ? persistentData.weeklyObjectives
                          : persistentData.monthlyObjectives
                      ).filter(objective => objective.completed && !objective.claimed).length})
                    </span>
                  )}
                </button>
              ))}
            </div>

            <div className="space-y-4">
              {objectives.map(objective => (
                <div
                  key={objective.id}
                  className={`p-4 rounded-lg border-2 ${
                    objective.completed
                      ? 'bg-green-900/30 border-green-600'
                      : 'bg-purple-900/30 border-purple-600'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2 gap-3">
                    <h3 className="text-white font-bold text-base md:text-lg">
                      {dailyObjectiveTranslations[lang]?.[objective.description]
                        || dailyObjectiveTranslations.en[objective.description]
                        || objective.description.replace(/_/g, ' ')}
                    </h3>
                    <span className="text-yellow-400 font-bold inline-flex items-center gap-1 whitespace-nowrap">
                      <CoinIcon size={18} /> {objective.reward}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 bg-gray-800 rounded-full h-4 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                        style={{ width: `${Math.min(100, objective.target > 0 ? (objective.current / objective.target) * 100 : 0)}%` }}
                      />
                    </div>
                    <span className="text-white font-bold text-sm">{objective.current}/{objective.target}</span>
                  </div>
                  {objective.completed && !objective.claimed && (
                    <div className="mt-3 flex items-center justify-between">
                      <p className="text-green-400 text-sm font-bold">✓ {t('ui.completed', lang)}</p>
                      <button
                        onClick={() => claimChallengeReward(challengeTab, objective.id)}
                        className="px-4 py-2 min-h-[44px] bg-gradient-to-r from-green-600 to-green-700 text-white font-bold rounded-lg hover:scale-105 active:scale-95 transition-all border-2 border-green-400 shadow-lg shadow-green-500/30 inline-flex items-center gap-1.5 touch-manipulation"
                      >
                        <CoinIcon size={18} /> {t('ui.claim', lang)}
                      </button>
                    </div>
                  )}
                  {objective.completed && objective.claimed && (
                    <p className="text-gray-400 text-sm mt-2 font-bold">✓ {t('ui.claimed', lang)}</p>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-900/30 rounded-lg border border-blue-600">
              <p className="text-blue-300 text-sm text-center">{t(resetKey, lang)}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderAchievements = () => (
    <div className="min-h-screen bg-gradient-to-b from-purple-950 via-gray-900 to-black p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-black/60 rounded-xl p-6 border-2 border-yellow-600">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-yellow-400">🏆 {t('title.achievements', lang)}</h2>
            <button
              onClick={() => setGameState(prev => ({ ...prev, phase: 'title' }))}
              className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
            >
              ← {t('metashop.back', lang)}
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {persistentData.achievements.map((achievement, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border-2 ${
                  achievement.unlocked
                    ? 'bg-yellow-900/30 border-yellow-600'
                    : 'bg-gray-900/30 border-gray-600 opacity-60'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-white font-bold text-lg">
                    {achievement.unlocked ? '🏆' : '🔒'} {achievementTranslations[lang]?.[achievement.id]?.name || achievement.name.replace(/_/g, ' ')}
                  </h3>
                  <span className="text-yellow-400 font-bold inline-flex items-center gap-1"><CoinIcon size={18} /> {achievement.reward}</span>
                </div>
                
                <p className="text-gray-300 text-sm">{achievementTranslations[lang]?.[achievement.id]?.description || achievement.description.replace(/_/g, ' ')}</p>
                
                {achievement.unlocked && !achievement.claimed && (
                  <div className="mt-3 flex items-center justify-between">
                    <p className="text-yellow-400 text-sm font-bold">✓ {t('ui.unlocked', lang)}</p>
                    <button
                      onClick={() => claimAchievementReward(achievement.id)}
                      className="px-4 py-2 min-h-[44px] bg-gradient-to-r from-green-600 to-green-700 text-white font-bold rounded-lg hover:scale-105 active:scale-95 transition-all border-2 border-green-400 shadow-lg shadow-green-500/30 inline-flex items-center gap-1.5 touch-manipulation"
                    >
                      <CoinIcon size={18} /> {t('ui.claim', lang)}
                    </button>
                  </div>
                )}
                {achievement.unlocked && achievement.claimed && (
                  <p className="text-gray-400 text-sm mt-2 font-bold">✓ {t('ui.claimed', lang)}</p>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-yellow-900/30 rounded-lg border border-yellow-600">
            <p className="text-yellow-300 text-sm text-center">
              {t('achievements.info', lang)}
            </p>
            <p className="text-yellow-400 text-center mt-2 font-bold">
              {persistentData.achievements.filter(a => a.unlocked).length}/{persistentData.achievements.length} {t('achievements.unlocked_count', lang)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <ScreenTransition isTransitioning={isTransitioning}>
      {(() => {
        switch (gameState.phase) {
          case 'title': return renderTitle();
          case 'starter_select': return renderStarterSelect();
          case 'map': return renderMap();
          case 'battle': return renderBattle();
          case 'shop': return renderShop();
          case 'event': return renderEvent();
          case 'game_over': return renderGameOver();
          case 'meta_shop': return (
            <MetaShop
              persistentData={persistentData}
              lang={lang}
              onPurchase={purchaseUpgrade}
              onWatchAdForCoins={watchAdForCoins}
              adCoinsLeft={getAdCoinsLeft(persistentData)}
              adCoinsReward={AD_COINS_REWARD}
              onBack={() => {
                setIsTransitioning(true);
                setTimeout(() => {
                  setGameState(prev => ({ ...prev, phase: 'title' }));
                  setIsTransitioning(false);
                }, 300);
              }}
            />
          );
          case 'daily_objectives': return renderDailyObjectives();
          case 'achievements': return renderAchievements();
          case 'statistics': return (
            <Statistics
              persistentData={persistentData}
              lang={lang}
              onBack={() => {
                setIsTransitioning(true);
                setTimeout(() => {
                  setGameState(prev => ({ ...prev, phase: 'title' }));
                  setIsTransitioning(false);
                }, 300);
              }}
            />
          );
          case 'settings': return (
            <Settings
              lang={lang}
              onLangChange={setLang}
              onBack={() => {
                setIsTransitioning(true);
                setTimeout(() => {
                  setGameState(prev => ({ ...prev, phase: 'title' }));
                  setIsTransitioning(false);
                }, 300);
              }}
            />
          );
          default: return renderTitle();
        }
      })()}
      {/* Modale pubblicita' globale: disponibile in ogni fase (cura, rivivi, monete) */}
      {renderAdModal()}
    </ScreenTransition>
  );
}
